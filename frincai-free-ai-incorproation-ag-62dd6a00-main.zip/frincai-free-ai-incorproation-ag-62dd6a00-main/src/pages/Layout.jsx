

import React, { useState, useEffect } from 'react';
import { User as UserEntity } from '@/api/entities';
import { Message } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { LogOut, LayoutDashboard, Mail, Settings, Building } from 'lucide-react';
import { Link, useLocation }
  from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import Logo from './components/Logo';

const AuthHeader = ({ user, unreadCount }) => {
  const handleLogout = async () => {
    await UserEntity.logout();
    window.location.href = createPageUrl('Homepage');
  };

  // Add null check for user
  if (!user) {
    return null;
  }

  return (
    <header className="bg-[var(--background-alt)] border-b border-[var(--border)] sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to={createPageUrl('Homepage')} className="flex items-center gap-2">
            <Logo className="w-7 h-7 text-[var(--primary)]" />
            <span className="text-xl font-bold text-[var(--primary)]">
              frinc.ai
            </span>
        </Link>
        <div className="flex items-center gap-4">
          <Link to={createPageUrl('Inbox')}>
            <Button variant="ghost" size="icon" className="relative text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--secondary)]">
                <Mail className="h-5 w-5" />
                {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
                    </span>
                )}
            </Button>
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                <Avatar className="h-10 w-10 bg-[var(--secondary)] border-2 border-[var(--border)]">
                  <AvatarFallback className="text-[var(--text-secondary)]">{user.full_name ? user.full_name.split(' ').map(n => n[0]).join('') : 'U'}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-[var(--popover)] border-[var(--border)] text-[var(--popover-foreground)]" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{user.full_name || 'User'}</p>
                  <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-[var(--border)]" />
              <Link to={createPageUrl('Dashboard')}>
                <DropdownMenuItem className="focus:bg-[var(--accent)]">
                  <LayoutDashboard className="mr-2 h-4 w-4" />
                  <span>Dashboard</span>
                </DropdownMenuItem>
              </Link>
              <Link to={createPageUrl('Settings')}>
                <DropdownMenuItem className="focus:bg-[var(--accent)]">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
              </Link>
              {user?.role === 'admin' && (
                <>
                  <Link to={createPageUrl('Admin')}>
                    <DropdownMenuItem className="focus:bg-[var(--accent)]">
                      <Building className="mr-2 h-4 w-4" />
                      <span>Admin Dashboard</span>
                    </DropdownMenuItem>
                  </Link>
                  <Link to={createPageUrl('AdminStateData')}>
                    <DropdownMenuItem className="focus:bg-[var(--accent)]">
                      <Building className="mr-2 h-4 w-4" />
                      <span>State Data Admin</span>
                    </DropdownMenuItem>
                  </Link>
                </>
              )}
              <DropdownMenuSeparator className="bg-[var(--border)]"/>
              <DropdownMenuItem onClick={handleLogout} className="focus:bg-[var(--accent)]">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
};

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const location = useLocation();
  
  const publicPages = ['Homepage', 'Test', 'About'];

  useEffect(() => {
    const applyTheme = () => {
        const storedTheme = localStorage.getItem('app-theme') || 'fun';
        document.documentElement.className = '';
        document.documentElement.classList.add(`theme-${storedTheme}`);
    };
    applyTheme();
    
    const fetchUserAndMessages = async () => {
      try {
        const currentUser = await UserEntity.me();
        setUser(currentUser);
        if (currentUser) {
          const messages = await Message.filter({ recipient_email: currentUser.email, is_read: false });
          setUnreadCount(messages.length);
        }
      } catch (error) {
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    fetchUserAndMessages();
  }, [location.pathname]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[var(--background-alt)] flex items-center justify-center relative overflow-hidden">
        <style>{`
          :root {
            --background: hsl(210 40% 98%);
            --background-alt: hsl(210 40% 96.1%);
            --text-primary: hsl(222.2 47.4% 11.2%);
            --text-secondary: hsl(215.4 16.3% 46.9%);
            --primary: hsl(221.2 83.2% 53.3%);
            --primary-foreground: hsl(210 40% 98%);
            --secondary: hsl(210 40% 96.1%);
            --border: hsl(214.3 31.8% 91.4%);
            --popover: hsl(0 0% 100%);
            --popover-foreground: hsl(222.2 47.4% 11.2%);
            --accent: hsl(210 40% 88%);
            --card: hsl(0 0% 100%);
          }
          .theme-dark {
            --background: hsl(222.2 84% 4.9%);
            --background-alt: hsl(222.2 84% 4.9%);
            --text-primary: hsl(210 40% 98%);
            --text-secondary: hsl(215 20.2% 65.1%);
            --primary: hsl(210 40% 98%);
            --primary-foreground: hsl(222.2 84% 4.9%);
            --secondary: hsl(217.2 32.6% 17.5%);
            --border: hsl(217.2 32.6% 17.5%);
            --popover: hsl(224 71.4% 4.1%);
            --popover-foreground: hsl(210 40% 98%);
            --accent: hsl(217.2 32.6% 17.5%);
            --card: hsl(222.2 84% 4.9%);
          }
          .theme-fun {
            --background: hsl(40 50% 96%);
            --background-alt: hsl(40 50% 93%);
            --text-primary: hsl(25 45% 25%);
            --text-secondary: hsl(25 35% 45%);
            --primary: hsl(24 98% 52%);
            --primary-foreground: hsl(0 0% 100%);
            --secondary: hsl(185 50% 90%);
            --border: hsl(30 20% 85%);
            --popover: hsl(40 50% 93%);
            --popover-foreground: hsl(25 45% 25%);
            --accent: hsl(185 55% 85%);
            --card: hsl(40 30% 98%);
          }
          .theme-ai {
            --background: hsl(215 30% 10%);
            --background-alt: hsl(215 30% 8%);
            --text-primary: hsl(195 100% 95%);
            --text-secondary: hsl(195 30% 70%);
            --primary: hsl(180 100% 50%);
            --primary-foreground: hsl(215 30% 5%);
            --secondary: hsl(215 30% 15%);
            --border: hsl(215 30% 20%);
            --popover: hsl(215 30% 5%);
            --popover-foreground: hsl(195 100% 95%);
            --accent: hsl(215 30% 15%);
            --card: hsl(215 30% 12%);
          }
          .theme-bling {
            --background: hsl(44 80% 96%);
            --background-alt: hsl(44 100% 94%);
            --text-primary: hsl(25 45% 20%);
            --text-secondary: hsl(25 35% 40%);
            --primary: hsl(43 100% 45%);
            --primary-foreground: hsl(25 45% 10%);
            --secondary: hsl(44 100% 90%);
            --border: hsl(44 100% 85%);
            --popover: hsl(44 100% 98%);
            --popover-foreground: hsl(25 45% 20%);
            --accent: hsl(44 100% 85%);
            --card: hsl(0 0% 100%);
          }
          .theme-bling .spinner {
            border-color: hsl(43 100% 45%);
            box-shadow: 0 0 20px rgba(255, 193, 7, 0.4));
          }
          .theme-bling-only {
            display: none;
          }
          .theme-bling .theme-bling-only {
            display: block;
          }
        `}</style>
        
        {/* Background Grid */}
        <div className="absolute inset-0 opacity-40 pointer-events-none z-0">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="loadingGrid" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
                <path d="M 80 0 L 0 0 0 80" fill="none" stroke="var(--primary)" strokeWidth="0.8"/>
                 <g transform="translate(40, 40)" stroke="var(--primary)" strokeWidth="1.5" fill="none" opacity="0.7">
                    <circle cx="7" cy="8" r="3" />
                    <circle cx="7" cy="8" r="1.5" fill="currentColor" />
                    <circle cx="17" cy="8" r="3" />
                    <circle cx="17" cy="8" r="1.5" fill="currentColor" />
                    <path d="M 8 15 Q 12 19 16 15" strokeLinecap="round"/>
                </g>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#loadingGrid)" />
          </svg>
        </div>

        {/* Bling Mode Dollar Signs */}
        <div className="absolute inset-0 pointer-events-none z-0 theme-bling-only">
          <div className="absolute top-[15%] left-[20%] text-8xl font-bold text-yellow-400/20 animate-pulse select-none" style={{ animationDelay: '0s', filter: 'drop-shadow(0 0 15px rgba(255, 215, 0, 0.4))' }}>$</div>
          <div className="absolute top-[60%] right-[15%] text-6xl font-bold text-yellow-500/15 animate-pulse select-none" style={{ animationDelay: '2s', filter: 'drop-shadow(0 0 12px rgba(255, 215, 0, 0.3))' }}>$</div>
          <div className="absolute bottom-[25%] left-[10%] text-10xl font-bold text-yellow-300/10 animate-pulse select-none" style={{ animationDelay: '4s', filter: 'drop-shadow(0 0 20px rgba(255, 215, 0, 0.5))' }}>$</div>
          <div className="absolute top-[35%] right-[30%] text-7xl font-bold text-yellow-400/25 animate-pulse select-none" style={{ animationDelay: '1s', filter: 'drop-shadow(0 0 18px rgba(255, 215, 0, 0.4))' }}>$</div>
        </div>
        
        {/* Central Loading Component */}
        <div className="relative z-10 flex flex-col items-center">
            <div className="spinner w-16 h-16 border-4 border-[var(--primary)] border-t-transparent rounded-full animate-spin mx-auto mb-6" />
            <h3 className="text-xl font-bold text-[var(--text-primary)] mb-2">
              frinc.ai
            </h3>
            <p className="text-[var(--text-secondary)] animate-pulse">Initializing AI systems...</p>
        </div>
      </div>
    );
  }
  
  if (!publicPages.includes(currentPageName) && !user) {
    window.location.href = createPageUrl('Homepage');
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-slate-500">Redirecting to homepage...</p>
        </div>
      </div>
    );
  }
  
  // For dashboard and other authenticated pages, don't show the header anymore
  // The dashboard now has its own integrated header
  if (user && !publicPages.includes(currentPageName)) {
    return (
      <div className="min-h-screen bg-[var(--background-alt)]">
        <style>{`
          :root {
            --background: hsl(210 40% 98%);
            --background-alt: hsl(210 40% 96.1%);
            --text-primary: hsl(222.2 47.4% 11.2%);
            --text-secondary: hsl(215.4 16.3% 46.9%);
            --primary: hsl(221.2 83.2% 53.3%);
            --primary-foreground: hsl(210 40% 98%);
            --secondary: hsl(210 40% 96.1%);
            --border: hsl(214.3 31.8% 91.4%);
            --popover: hsl(0 0% 100%);
            --popover-foreground: hsl(222.2 47.4% 11.2%);
            --accent: hsl(210 40% 88%);
            --card: hsl(0 0% 100%);
          }
          .theme-dark {
            --background: hsl(222.2 84% 4.9%);
            --background-alt: hsl(222.2 84% 4.9%);
            --text-primary: hsl(210 40% 98%);
            --text-secondary: hsl(215 20.2% 65.1%);
            --primary: hsl(210 40% 98%);
            --primary-foreground: hsl(222.2 84% 4.9%);
            --secondary: hsl(217.2 32.6% 17.5%);
            --border: hsl(217.2 32.6% 17.5%);
            --popover: hsl(224 71.4% 4.1%);
            --popover-foreground: hsl(210 40% 98%);
            --accent: hsl(217.2 32.6% 17.5%);
            --card: hsl(222.2 84% 4.9%);
          }
          .theme-fun {
            --background: hsl(40 50% 96%);
            --background-alt: hsl(40 50% 93%);
            --text-primary: hsl(25 45% 25%);
            --text-secondary: hsl(25 35% 45%);
            --primary: hsl(24 98% 52%);
            --primary-foreground: hsl(0 0% 100%);
            --secondary: hsl(185 50% 90%);
            --border: hsl(30 20% 85%);
            --popover: hsl(40 50% 93%);
            --popover-foreground: hsl(25 45% 25%);
            --accent: hsl(185 55% 85%);
            --card: hsl(40 30% 98%);
          }
          .theme-ai {
            --background: hsl(215 30% 10%);
            --background-alt: hsl(215 30% 8%);
            --text-primary: hsl(195 100% 95%);
            --text-secondary: hsl(195 30% 70%);
            --primary: hsl(180 100% 50%);
            --primary-foreground: hsl(215 30% 5%);
            --secondary: hsl(215 30% 15%);
            --border: hsl(215 30% 20%);
            --popover: hsl(215 30% 5%);
            --popover-foreground: hsl(195 100% 95%);
            --accent: hsl(215 30% 15%);
            --card: hsl(215 30% 12%);
          }
          .theme-bling {
            --background: hsl(44 80% 96%);
            --background-alt: hsl(44 100% 94%);
            --text-primary: hsl(25 45% 20%);
            --text-secondary: hsl(25 35% 40%);
            --primary: hsl(43 100% 45%);
            --primary-foreground: hsl(25 45% 10%);
            --secondary: hsl(44 100% 90%);
            --border: hsl(44 100% 85%);
            --popover: hsl(44 100% 98%);
            --popover-foreground: hsl(25 45% 20%);
            --accent: hsl(44 100% 85%);
            --card: hsl(0 0% 100%);
          }
        `}</style>
        <main>{children}</main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--background-alt)]">
      {/* Only show AuthHeader for non-Homepage pages when user is logged in */}
      {user && currentPageName !== 'Homepage' && <AuthHeader user={user} unreadCount={unreadCount} />}
      <main>{children}</main>
    </div>
  );
}

