import React from 'react';
import Logo from '../components/Logo';

export default function LogoDisplayPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-900 flex flex-col items-center justify-center p-8 text-center">
      <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent mb-4">
        Your frinc.ai Logo
      </h1>
      <p className="text-slate-400 mb-8 max-w-lg">
        Below is a high-resolution version of your logo. To save it, **right-click on the image** and select **"Save Image As..."**. This will save it as an SVG file.
      </p>
      <div className="bg-slate-800/50 p-12 rounded-2xl border border-slate-700 shadow-2xl shadow-cyan-500/10">
        <Logo className="w-96 h-96 text-cyan-400" />
      </div>
       <p className="text-slate-500 mt-8 text-sm">
        An SVG file is a vector image, which means you can make it any size without losing quality. You can use free online tools to convert it to PNG or JPG if needed.
      </p>
    </div>
  );
}