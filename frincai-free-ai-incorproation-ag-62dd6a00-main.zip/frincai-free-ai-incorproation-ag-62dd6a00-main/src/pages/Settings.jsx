import React, { useState, useEffect } from 'react';
import { User as UserEntity } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';

export default function SettingsPage() {
    const [user, setUser] = useState(null);
    const [fullName, setFullName] = useState('');
    const [isSaving, setIsSaving] = useState(false);
    const [saveMessage, setSaveMessage] = useState('');

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const currentUser = await UserEntity.me();
                setUser(currentUser);
                setFullName(currentUser.full_name || '');
            } catch (error) {
                console.error("User not found, should be handled by layout redirect.");
            }
        };
        fetchUser();
    }, []);

    const handleSave = async (e) => {
        e.preventDefault();
        setIsSaving(true);
        setSaveMessage('');
        try {
            await UserEntity.updateMyUserData({ full_name: fullName });
            setSaveMessage('Your information has been updated successfully!');
            // Also update user state locally
            setUser({...user, full_name: fullName});
        } catch (error) {
            setSaveMessage('An error occurred while saving. Please try again.');
            console.error("Failed to update user data:", error);
        } finally {
            setIsSaving(false);
            setTimeout(() => setSaveMessage(''), 3000);
        }
    };

    if (!user) {
        return <div className="text-center p-10">Loading user settings...</div>;
    }

    return (
        <div className="container mx-auto p-4 sm:p-6 md:p-8">
            <div className="max-w-2xl mx-auto">
                <Card>
                    <CardHeader>
                        <CardTitle>Account Settings</CardTitle>
                        <CardDescription>Manage your personal information.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSave} className="space-y-6">
                            <div className="space-y-2">
                                <Label htmlFor="email">Email</Label>
                                <Input id="email" type="email" value={user.email} disabled />
                                <p className="text-sm text-slate-500">Your email address cannot be changed.</p>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="fullName">Full Name</Label>
                                <Input 
                                    id="fullName" 
                                    type="text" 
                                    value={fullName}
                                    onChange={(e) => setFullName(e.target.value)}
                                    placeholder="Enter your full name"
                                />
                            </div>
                            <div className="flex items-center justify-between">
                                <Button type="submit" disabled={isSaving}>
                                    {isSaving ? 'Saving...' : 'Save Changes'}
                                </Button>
                                {saveMessage && (
                                    <p className="text-sm text-green-600">{saveMessage}</p>
                                )}
                            </div>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}