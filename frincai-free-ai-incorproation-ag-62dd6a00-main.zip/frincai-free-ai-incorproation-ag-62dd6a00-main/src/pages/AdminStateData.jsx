
import React, { useState, useEffect } from 'react';
import { StateData } from '@/api/entities';
import { User as UserEntity } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, Edit, Trash2, Download, FileSpreadsheet } from 'lucide-react';
import StateDataForm from '../components/admin/StateDataForm';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdminStateData() {
  const [user, setUser] = useState(null);
  const [states, setStates] = useState([]);
  const [filteredStates, setFilteredStates] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingState, setEditingState] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isEditingLoading, setIsEditingLoading] = useState(false); // New state for indicating a specific state is being loaded for editing

  // useEffect for initial setup and loading states
  useEffect(() => {
    checkAccess();
    loadStates(); // Call loadStates, which is defined outside useEffect to be accessible by other handlers
  }, []);

  // useEffect for filtering states based on search term
  useEffect(() => {
    if (searchTerm) {
      setFilteredStates(states.filter(state =>
        state.state_name.toLowerCase().includes(searchTerm.toLowerCase())
      ));
    } else {
      setFilteredStates(states);
    }
  }, [states, searchTerm]);

  const checkAccess = async () => {
    try {
      const currentUser = await UserEntity.me();
      if (currentUser.role !== 'admin') {
        throw new Error('Access denied');
      }
      setUser(currentUser);
    } catch (error) {
      window.location.href = '/';
    }
  };

  const loadStates = async () => {
    setLoading(true);
    try {
      // Fetch all state data records, including potential duplicates
      const allStatesData = await StateData.list('-updated_date');

      // --- FIX: De-duplicate the data to ensure one record per state ---
      const uniqueStatesMap = new Map();
      allStatesData.forEach(state => {
        // If we haven't seen this state, or if the current record is newer than the one we have, update the map.
        if (!uniqueStatesMap.has(state.state_name) || new Date(state.updated_date) > new Date(uniqueStatesMap.get(state.state_name).updated_date)) {
          uniqueStatesMap.set(state.state_name, state);
        }
      });

      // Convert the map of unique states back to an array and sort it alphabetically
      const finalStates = Array.from(uniqueStatesMap.values()).sort((a, b) => a.state_name.localeCompare(b.state_name));
      
      setStates(finalStates);
      // The filteredStates will be updated automatically by the other useEffect hook.

    } catch (error) {
      console.error('Failed to load or de-duplicate states:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (formData) => {
    try {
      if (editingState) {
        await StateData.update(editingState.id, formData);
      } else {
        await StateData.create(formData);
      }
      setShowForm(false);
      setEditingState(null);
      loadStates(); // Reload states after save/create
    } catch (error) {
      console.error('Failed to save state data:', error);

      // More detailed error messaging
      let errorMessage = 'Failed to save state data. ';

      if (error.message) {
        errorMessage += `Error: ${error.message}`;
      } else if (error.details) {
        errorMessage += `Details: ${error.details}`;
      } else {
        errorMessage += 'Please check all required fields and try again.';
      }

      // Common issues to check
      errorMessage += '\n\nCommon issues:\n';
      errorMessage += '• State name is required and must be selected\n';
      errorMessage += '• Number fields (fees, step numbers) should be valid numbers or left empty\n';
      errorMessage += '• URLs should be complete and valid\n';
      errorMessage += '• Screenshot uploads must be completed before saving';

      alert(errorMessage);
    }
  };

  const handleEdit = async (stateId) => {
    setIsEditingLoading(true); // Set loading state while fetching specific state data
    try {
      const stateToEdit = await StateData.get(stateId); // Fetch the complete state data from the database
      setEditingState(stateToEdit);
      setShowForm(true);
    } catch (error) {
      console.error('Failed to load state for editing:', error);
      alert('Failed to load state data for editing. Please try again.');
      setEditingState(null); // Clear editing state if loading failed
      setShowForm(false); // Do not show form if data cannot be loaded
    } finally {
      setIsEditingLoading(false); // Reset loading state
    }
  };

  const handleDelete = async (stateId) => {
    if (confirm('Are you sure you want to delete this state data?')) {
      try {
        await StateData.delete(stateId);
        loadStates(); // Reload states after delete
      } catch (error) {
        console.error('Failed to delete state:', error);
        alert('Failed to delete state data. Please try again.');
      }
    }
  };

  const exportData = () => {
    const dataStr = JSON.stringify(states, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `state-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  if (loading || isEditingLoading) { // Combine initial loading and specific state loading for a unified loading screen
    return (
      <div className="min-h-screen bg-[var(--background-alt)] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-4 border-[var(--primary)] border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-[var(--text-secondary)]">
            {loading ? 'Loading state data...' : 'Loading state for editing...'}
          </p>
        </div>
      </div>
    );
  }

  if (showForm) {
    return (
      <div className="min-h-screen bg-[var(--background-alt)]">
        <StateDataForm
          initialData={editingState}
          onSave={handleSave}
          onCancel={() => {
            setShowForm(false);
            setEditingState(null);
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--background-alt)] p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <Card className="bg-[var(--background)] border-[var(--border)]">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <CardTitle className="text-2xl font-bold text-[var(--text-primary)]">
                  State Data Administration
                </CardTitle>
                <p className="text-[var(--text-secondary)] mt-1">
                  Manage incorporation data for all 50 US states
                </p>
              </div>
              <div className="flex gap-3">
                <Button
                  onClick={exportData}
                  variant="outline"
                  className="text-[var(--text-primary)] border-[var(--border)] hover:bg-[var(--accent)]"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export Database
                </Button>
                <Button
                  onClick={() => setShowForm(true)}
                  className="bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-90"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add State Data
                </Button>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Search and Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="md:col-span-3 bg-[var(--background)] border-[var(--border)]">
            <CardContent className="pt-6">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-[var(--text-secondary)]" />
                <Input
                  placeholder="Search states..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)]"
                />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[var(--background)] border-[var(--border)]">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-[var(--primary)]">{states.length}</div>
                <p className="text-xs text-[var(--text-secondary)]">States Configured</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* States Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence>
            {filteredStates.map((state) => (
              <motion.div
                key={state.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="bg-[var(--background)] border-[var(--border)] hover:border-[var(--primary)] transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg text-[var(--text-primary)]">
                        {state.state_name}
                      </CardTitle>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleEdit(state.id)} // Pass state.id to handleEdit
                          className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] h-8 w-8 p-0"
                          disabled={isEditingLoading} // Disable button while a state is being loaded for editing
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDelete(state.id)}
                          className="text-[var(--text-secondary)] hover:text-red-500 h-8 w-8 p-0"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0 space-y-3">
                    <div className="flex flex-wrap gap-2">
                      {state.incorporation_website_url && (
                        <Badge variant="secondary" className="text-xs bg-[var(--secondary)] text-[var(--text-primary)]">
                          Website
                        </Badge>
                      )}
                      {state.fees?.normal_processing && (
                        <Badge variant="secondary" className="text-xs bg-[var(--secondary)] text-[var(--text-primary)]">
                          Fees
                        </Badge>
                      )}
                      {state.name_search?.screenshots?.length > 0 && (
                        <Badge variant="secondary" className="text-xs bg-[var(--secondary)] text-[var(--text-primary)]">
                          Name Search
                        </Badge>
                      )}
                      {state.company_registration?.screenshots?.length > 0 && (
                        <Badge variant="secondary" className="text-xs bg-[var(--secondary)] text-[var(--text-primary)]">
                          Registration
                        </Badge>
                      )}
                    </div>

                    <div className="text-sm text-[var(--text-secondary)]">
                      {state.fees?.normal_processing && (
                        <div className="flex justify-between">
                          <span>LLC Fee:</span>
                          <span className="font-medium text-[var(--text-primary)]">
                            ${state.fees.normal_processing.llc_fee || 'N/A'}
                          </span>
                        </div>
                      )}
                      {state.fees?.normal_processing && (
                        <div className="flex justify-between">
                          <span>Corp Fee:</span>
                          <span className="font-medium text-[var(--text-primary)]">
                            ${state.fees.normal_processing.inc_fee || 'N/A'}
                          </span>
                        </div>
                      )}
                    </div>

                    {state.fees?.expedite_options?.length > 0 && (
                      <div className="text-xs text-[var(--text-secondary)]">
                        <span className="text-[var(--primary)] font-medium">
                          {state.fees.expedite_options.length} expedite option(s)
                        </span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredStates.length === 0 && searchTerm && (
          <Card className="bg-[var(--background)] border-[var(--border)]">
            <CardContent className="text-center py-12">
              <Search className="w-12 h-12 text-[var(--text-secondary)] mx-auto mb-4" />
              <h3 className="text-lg font-medium text-[var(--text-primary)] mb-2">No states found</h3>
              <p className="text-[var(--text-secondary)]">
                Try adjusting your search term or add data for "{searchTerm}".
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
