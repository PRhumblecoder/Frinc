import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import { Rocket, ShieldCheck, Sparkles } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold text-slate-800 mb-4">
          What is <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">frinc.ai</span>?
        </h1>
        <p className="max-w-3xl mx-auto text-lg text-slate-600 mb-12">
          frinc.ai is your AI incorporation agent, empowering you to launch your U.S. business, quickly, and completely free. Say goodbye to expensive fees and complex paperwork – we give you the power to form your company yourself, on your terms, from anywhere.
        </p>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-12">
          <div className="bg-white/60 backdrop-blur-sm p-8 rounded-xl shadow-lg border border-slate-200/50">
            <Sparkles className="w-12 h-12 text-indigo-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-slate-800 mb-2">AI-Powered Guidance</h2>
            <p className="text-slate-600">
              Our AI advisor analyzes your business needs to recommend the optimal state and legal structure, helping you save on taxes and maximize privacy.
            </p>
          </div>
          <div className="bg-white/60 backdrop-blur-sm p-8 rounded-xl shadow-lg border border-slate-200/50">
            <Rocket className="w-12 h-12 text-purple-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-slate-800 mb-2">Fast & Free Formation</h2>
            <p className="text-slate-600">
              Launch your LLC, C-Corp, or S-Corp completely free of charge. Our streamlined process gets your company registered quickly and efficiently.
            </p>
          </div>
          <div className="bg-white/60 backdrop-blur-sm p-8 rounded-xl shadow-lg border border-slate-200/50">
            <ShieldCheck className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-slate-800 mb-2">Secure & Simple</h2>
            <p className="text-slate-600">
              Your data is secure with us. Manage your company documents, track status, and stay compliant all from one simple dashboard.
            </p>
          </div>
        </div>
        
        <Link to={createPageUrl('Homepage')}>
          <Button size="lg" className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white rounded-full px-10 py-6 text-xl font-bold shadow-lg hover:shadow-xl transition-all duration-300 border-0">
            Get Started
          </Button>
        </Link>
      </div>
    </div>
  );
}