
import React, { useState, useEffect, useCallback } from 'react';
import { Company } from '@/api/entities';
import { User as UserEntity } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusCircle, Rocket, Building, Briefcase, LogOut, LayoutDashboard, Mail, Settings, UserCheck, Zap, ShieldCheck, Palette } from 'lucide-react';
import { createPageUrl } from '@/utils';
import LaunchChatFlow from '../components/launch/LaunchChatFlow';
import Homepage from './Homepage';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Link } from 'react-router-dom';
import CompanyCard from '../components/companies/CompanyCard';
import Logo from '../components/Logo';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import StateFilingSimulation from '../components/launch/StateFilingSimulation';
import TextualSimulation from '../components/launch/TextualSimulation';
import LaunchIntroModal from '../components/launch/LaunchIntroModal';
import { Input } from '@/components/ui/input'; // Import Input component

export default function Dashboard() {
  const [companies, setCompanies] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  // New state for search query
  const [searchQuery, setSearchQuery] = useState('');
  // New state variables for launch flow
  const [launchingCompany, setLaunchingCompany] = useState(null);
  const [isLaunchModalOpen, setIsLaunchModalOpen] = useState(false);
  const [simulatingCompany, setSimulatingCompany] = useState(null);
  const [geminiSimulatingCompany, setGeminiSimulatingCompany] = useState(null);
  const [proLaunchCompany, setProLaunchCompany] = useState(null); // New state for pro launch
  const [introModalCompany, setIntroModalCompany] = useState(null); // New state for intro modal
  
  const [companyToEdit, setCompanyToEdit] = useState(null);
  const [companyToDelete, setCompanyToDelete] = useState(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [currentTheme, setCurrentTheme] = useState('fun');

  useEffect(() => {
    const storedTheme = localStorage.getItem('app-theme') || 'fun';
    setCurrentTheme(storedTheme);
    document.documentElement.className = ''; // Clear existing theme classes
    document.documentElement.classList.add(`theme-${storedTheme}`);
  }, []);

  const handleThemeChange = (theme) => {
    setCurrentTheme(theme);
    localStorage.setItem('app-theme', theme);
    document.documentElement.className = ''; // Clear existing theme classes
    document.documentElement.classList.add(`theme-${theme}`);
  };

  // Helper functions to load specific data sets
  const loadCompanies = async (currentUser) => {
    if (!currentUser) return [];
    try {
      const userCompanies = await Company.filter({ created_by: currentUser.email }, '-created_date');
      setCompanies(userCompanies);
      return userCompanies;
    } catch (error) {
      console.error("Failed to load user companies:", error);
      return [];
    }
  };

  const loadMessages = async (currentUser) => {
    if (!currentUser) return;
    try {
      const { Message } = await import('@/api/entities');
      const messages = await Message.filter({ recipient_email: currentUser.email, is_read: false });
      setUnreadCount(messages.length);
    } catch (error) {
      console.error("Failed to load unread messages:", error);
    }
  };

  // Function to refresh all dashboard-related data (companies and messages)
  const refreshDashboardData = useCallback(async () => {
    if (user) {
      await loadCompanies(user);
      await loadMessages(user);
    }
  }, [user]); // Re-create if user object changes

  useEffect(() => {
    const initialize = async () => {
      setLoading(true);
      try {
        const currentUser = await UserEntity.me();
        setUser(currentUser);
        
        // Check URL parameters for auto-launch or create-and-launch scenarios
        const urlParams = new URLSearchParams(window.location.search);
        const launchCompanyId = urlParams.get('launch_company');
        const createAndLaunch = urlParams.get('create_and_launch');
        
        let companyToAutoLaunch = null;

        // Handle creating company from localStorage after signup (e.g., redirect from signup flow)
        if (createAndLaunch === 'true') {
          const pendingData = localStorage.getItem('pendingCompanyData');
          if (pendingData) {
            try {
              const companyData = JSON.parse(pendingData);
              const newCompany = await Company.create(companyData);
              localStorage.removeItem('pendingCompanyData'); // Clean up pending data
              companyToAutoLaunch = newCompany;
              window.history.replaceState({}, '', createPageUrl('Dashboard')); // Clean URL
            } catch (error) {
              console.error('Error creating company from pending data:', error);
            }
          }
        }
        // Handle direct launch from URL parameter (e.g., from a shared link or internal redirect)
        else if (launchCompanyId) {
          // Attempt to find the company by ID, ensuring it belongs to the current user
          const companiesById = await Company.filter({ id: launchCompanyId, created_by: currentUser.email });
          const companyToLaunch = companiesById.length > 0 ? companiesById[0] : null;
          if (companyToLaunch) {
            companyToAutoLaunch = companyToLaunch;
            window.history.replaceState({}, '', createPageUrl('Dashboard')); // Clean URL
          }
        }
        
        // Always load the latest list of companies and messages for the dashboard display
        await loadCompanies(currentUser);
        await loadMessages(currentUser);

        // If a company was identified for auto-launch, trigger the intro modal instead of the textual simulation
        if (companyToAutoLaunch) {
          setIntroModalCompany(companyToAutoLaunch);
        }

      } catch (error) {
        console.error('Error initializing dashboard:', error);
        // In a real application, you might redirect to a login page or show a global error message here.
      } finally {
        setLoading(false);
      }
    };
    
    initialize();
  }, []); // Empty dependency array ensures this effect runs only once on mount

  const handleEditCompany = (company) => {
    setCompanyToEdit(company);
  };

  const handleDeleteCompany = async () => {
    if (companyToDelete) {
      await Company.delete(companyToDelete.id);
      setCompanyToDelete(null);
      refreshDashboardData(); // Refresh companies list after deletion
    }
  };

  const handleProLaunch = (company) => {
    setProLaunchCompany(company);
  };
  
  const handleConfirmProLaunch = () => {
    console.log("Confirmed Pro Launch for:", proLaunchCompany);
    // Here you would typically redirect to a payment page
    // For now, we'll just close the modal
    setProLaunchCompany(null);
    alert("Pro Launch checkout is not yet implemented. This would redirect to a payment page.");
  };

  const handleLogout = async () => {
    await UserEntity.logout();
    window.location.href = createPageUrl('Homepage');
  };

  const filteredCompanies = companies.filter(company => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    
    // Search in company name and legal ending
    if (company.company_name?.toLowerCase().includes(query) || 
        company.legal_ending?.toLowerCase().includes(query)) {
      return true;
    }
    
    // Search in organizer information
    const organizer = company.organizer || {};
    if (organizer.firstName?.toLowerCase().includes(query) ||
        organizer.lastName?.toLowerCase().includes(query) ||
        organizer.streetAddress?.toLowerCase().includes(query) ||
        organizer.city?.toLowerCase().includes(query) ||
        organizer.state?.toLowerCase().includes(query)) {
      return true;
    }
    
    // Search in owners information
    const owners = company.owners || [];
    if (owners.some(owner => 
      owner.firstName?.toLowerCase().includes(query) ||
      owner.lastName?.toLowerCase().includes(query) ||
      owner.streetAddress?.toLowerCase().includes(query) ||
      owner.city?.toLowerCase().includes(query) ||
      owner.state?.toLowerCase().includes(query)
    )) {
      return true;
    }
    
    // Search in managers information
    const managers = company.managers || [];
    if (managers.some(manager => 
      manager.firstName?.toLowerCase().includes(query) ||
      manager.lastName?.toLowerCase().includes(query) ||
      manager.streetAddress?.toLowerCase().includes(query) ||
      manager.city?.toLowerCase().includes(query) ||
      manager.state?.toLowerCase().includes(query)
    )) {
      return true;
    }
    
    return false;
  });

  if (loading) {
    return (
      <div className="container mx-auto p-4 md:p-8 text-center text-[var(--text-secondary)]">
        Loading your companies...
      </div>
    );
  }

  // Render LaunchChatFlow modal if `isLaunchModalOpen` is true and `launchingCompany` is set
  if (isLaunchModalOpen && launchingCompany) {
    return (
      <LaunchChatFlow 
        company={launchingCompany} 
        onComplete={() => {
          setLaunchingCompany(null);
          setIsLaunchModalOpen(false);
          refreshDashboardData(); // Refresh data after launch flow completes (e.g., company status updates)
        }}
        onClose={() => {
          setLaunchingCompany(null);
          setIsLaunchModalOpen(false);
        }}
      />
    );
  }

  if (simulatingCompany) {
    return (
        <StateFilingSimulation 
            company={simulatingCompany}
            onComplete={() => setSimulatingCompany(null)}
            onClose={() => setSimulatingCompany(null)}
        />
    );
  }

  if (geminiSimulatingCompany) {
    return (
        <TextualSimulation 
            company={geminiSimulatingCompany}
            onClose={() => setGeminiSimulatingCompany(null)}
        />
    );
  }

  return (
    <div className="min-h-screen bg-[var(--background)] text-[var(--text-primary)] relative">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-20 pointer-events-none z-0">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="dashboardGrid" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="hsl(var(--primary) / 0.1)" strokeWidth="0.5"/>
              <circle cx="30" cy="30" r="1.5" fill="hsl(var(--primary) / 0.1)" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#dashboardGrid)" />
        </svg>
      </div>
      
      {/* Unified Header and Content */}
      <div className="relative z-10 container mx-auto px-4 py-4 md:py-8">
        {/* Header Section */}
        <div className="container mx-auto px-4 py-4 md:py-6 border-b border-[var(--border)]">
          <div className="flex justify-between items-center">
            {/* Left: Welcome Message */}
            <div className="flex items-center gap-2 md:gap-4">
              <Link to={createPageUrl('Homepage')} className="flex items-center gap-2">
                <Logo className="w-6 h-6 md:w-7 md:h-7 text-[var(--primary)]" />
                <span className="text-lg md:text-xl font-bold text-[var(--primary)]">frinc.ai</span>
              </Link>
              <h1 className="text-lg md:text-2xl font-bold text-[var(--text-primary)] hidden sm:block">Welcome, {user?.full_name}</h1>
            </div>
            
            {/* Right: User Menu (removed New Company button) */}
            <div className="flex items-center gap-2 md:gap-4">
               <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--secondary)] h-8 w-8 md:h-10 md:w-10">
                    <Palette className="h-4 w-4 md:h-5 md:w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-[var(--popover)] border-[var(--border)] text-[var(--popover-foreground)]" align="end">
                  <DropdownMenuLabel>Theme</DropdownMenuLabel>
                  <DropdownMenuSeparator className="bg-[var(--border)]" />
                  <DropdownMenuRadioGroup value={currentTheme} onValueChange={handleThemeChange}>
                    <DropdownMenuRadioItem value="fun" className="focus:bg-[var(--accent)]">Fun</DropdownMenuRadioItem>
                    <DropdownMenuRadioItem value="light" className="focus:bg-[var(--accent)]">Light</DropdownMenuRadioItem>
                    <DropdownMenuRadioItem value="dark" className="focus:bg-[var(--accent)]">Dark</DropdownMenuRadioItem>
                    <DropdownMenuRadioItem value="ai" className="focus:bg-[var(--accent)]">AI</DropdownMenuRadioItem>
                    <DropdownMenuRadioItem value="bling" className="focus:bg-[var(--accent)]">Bling</DropdownMenuRadioItem>
                  </DropdownMenuRadioGroup>
                </DropdownMenuContent>
              </DropdownMenu>

              <Link to={createPageUrl('Inbox')}>
                <Button variant="ghost" size="icon" className="relative text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--secondary)] h-8 w-8 md:h-10 md:w-10">
                    <Mail className="h-4 w-4 md:h-5 md:w-5" />
                    {unreadCount > 0 && (
                        <span className="absolute top-0 right-0 md:top-1 md:right-1 flex h-2 w-2 md:h-3 md:w-3">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 md:h-3 w-3 bg-cyan-500"></span>
                        </span>
                    )}
                </Button>
              </Link>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 md:h-10 md:w-10 rounded-full">
                    <Avatar className="h-8 w-8 md:h-10 md:w-10 bg-[var(--secondary)] border-2 border-[var(--border)]">
                      <AvatarFallback className="text-[var(--text-secondary)] text-xs md:text-sm">{user?.full_name ? user.full_name.split(' ').map(n => n[0]).join('') : 'U'}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-[var(--popover)] border-[var(--border)] text-[var(--popover-foreground)]" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user?.full_name}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator className="bg-[var(--border)]" />
                  <Link to={createPageUrl('Dashboard')}>
                    <DropdownMenuItem className="focus:bg-[var(--accent)]">
                      <LayoutDashboard className="mr-2 h-4 w-4" />
                      <span>Dashboard</span>
                    </DropdownMenuItem>
                  </Link>
                  <Link to={createPageUrl('Settings')}>
                    <DropdownMenuItem className="focus:bg-[var(--accent)]">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                  </Link>
                  <DropdownMenuSeparator className="bg-[var(--border)]"/>
                  <DropdownMenuItem onClick={handleLogout} className="focus:bg-[var(--accent)] cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="container mx-auto px-4 py-4 md:py-8">
          <div className="flex justify-between items-center mb-4 md:mb-6">
            <h2 className="text-2xl md:text-3xl font-bold text-[var(--text-primary)]">My Companies</h2>
          </div>

          {/* Start Company Button */}
          <div className="mb-4">
            <Link to={createPageUrl('Homepage')}>
              <Button className="bg-[var(--primary)] text-[var(--primary-foreground)] rounded-xl flex items-center gap-2 text-sm md:text-base px-4 py-2 hover:bg-[var(--primary)]/30 hover:text-[var(--primary-foreground)] transition-all duration-200">
                <PlusCircle className="h-4 w-4 md:h-5 md:w-5" />
                <span>Start Company</span>
              </Button>
            </Link>
          </div>

          {/* Search Field */}
          <div className="mb-6">
            <Input
              placeholder="Search companies by name, owner, organizer, manager, or address..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] max-w-md"
            />
          </div>

          <AlertDialog open={!!companyToDelete} onOpenChange={(open) => !open && setCompanyToDelete(null)}>
            <AlertDialogContent className="bg-[var(--card)] border-[var(--border)] text-[var(--text-primary)]">
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure you want to delete this company?</AlertDialogTitle>
                <AlertDialogDescription className="text-[var(--text-secondary)]">
                  This action cannot be undone. This will permanently delete "{companyToDelete?.company_name}, {companyToDelete?.legal_ending}" and remove all associated data.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="bg-[var(--secondary)] text-[var(--text-primary)] border-[var(--border)] hover:bg-[var(--accent)]">Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={handleDeleteCompany}
                  className="bg-[var(--destructive)] text-[var(--destructive-foreground)] hover:opacity-30"
                >
                  Yes, Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          
          <AlertDialog open={!!proLaunchCompany} onOpenChange={(open) => !open && setProLaunchCompany(null)}>
            <AlertDialogContent className="bg-[var(--card)] border-[var(--border)] text-[var(--text-primary)]">
              <AlertDialogHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-[var(--primary)] text-[var(--primary-foreground)] rounded-lg flex items-center justify-center">
                    <UserCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <AlertDialogTitle className="text-xl">Launch with a Pro - $99</AlertDialogTitle>
                    <AlertDialogDescription className="text-[var(--text-secondary)]">
                      Let our experts handle the entire filing process for "{proLaunchCompany?.company_name}".
                    </AlertDialogDescription>
                  </div>
                </div>
              </AlertDialogHeader>
              <div className="py-4 space-y-3 text-[var(--text-secondary)]">
                  <div className="flex items-start gap-3">
                      <Zap className="w-5 h-5 text-[var(--primary)] mt-1"/>
                      <div>
                        <h4 className="font-semibold text-[var(--text-primary)]">Save Time & Effort</h4>
                        <p>We handle all the paperwork and state submissions, saving you hours of complex work.</p>
                      </div>
                  </div>
                  <div className="flex items-start gap-3">
                      <ShieldCheck className="w-5 h-5 text-[var(--primary)] mt-1"/>
                      <div>
                        <h4 className="font-semibold text-[var(--text-primary)]">Ensure Accuracy & Compliance</h4>
                        <p>Our experts guarantee your filing is done correctly, avoiding costly rejections and delays.</p>
                      </div>
                  </div>
              </div>
              <AlertDialogFooter>
                <AlertDialogCancel 
                  onClick={() => {
                    setIntroModalCompany(proLaunchCompany);
                    setProLaunchCompany(null);
                  }}
                  className="bg-[var(--secondary)] text-[var(--text-primary)] border-[var(--border)] hover:bg-[var(--accent)]"
                >Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={handleConfirmProLaunch}
                  className="bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)]/30 hover:text-[var(--primary-foreground)] transition-all duration-200"
                >
                  Proceed to Payment
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {filteredCompanies.length === 0 ? (
            <div className="text-center py-12 md:py-20 bg-[var(--card)] border-2 border-dashed border-[var(--border)] rounded-xl">
              {searchQuery ? (
                <>
                  <h3 className="text-lg md:text-xl font-semibold text-[var(--text-primary)]">No companies found</h3>
                  <p className="text-[var(--text-secondary)] mt-2 mb-4 px-4">
                    No companies match your search "{searchQuery}". Try a different search term.
                  </p>
                  <Button 
                    onClick={() => setSearchQuery('')}
                    variant="outline"
                    className="mr-4 border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]"
                  >
                    Clear Search
                  </Button>
                </>
              ) : (
                <>
                  <h3 className="text-lg md:text-xl font-semibold text-[var(--text-primary)]">No companies yet!</h3>
                  <p className="text-[var(--text-secondary)] mt-2 mb-4 px-4">
                    Start your business journey with our AI agent.
                  </p>
                </>
              )}
              <Link to={createPageUrl('Homepage')}>
                <Button className="bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)]/30 hover:text-[var(--primary-foreground)] transition-all duration-200">
                   Create {searchQuery ? 'New' : 'First'} Company
                </Button>
              </Link>
            </div>
          ) : (
            <div className="grid gap-4 md:gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {filteredCompanies.map((company) => (
                <CompanyCard
                  key={company.id}
                  company={company}
                  onLaunch={() => {
                      setLaunchingCompany(company); // Set the company to be launched
                      setIsLaunchModalOpen(true); // Open the launch modal
                  }}
                  onLaunchGemini={() => setIntroModalCompany(company)} // Changed to open intro modal
                  onLaunchPro={() => handleProLaunch(company)} // New prop for Pro launch
                  onEdit={() => handleEditCompany(company)}
                  onDelete={() => setCompanyToDelete(company)}
                />
              ))}
            </div>
          )}

          {companyToEdit && (
            <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
                <div className="relative w-full max-w-sm h-full max-h-[700px]">
                    <Homepage 
                        isModal={true} 
                        companyToEdit={companyToEdit}
                        onSaveComplete={() => {
                            setCompanyToEdit(null);
                            refreshDashboardData(); // Refresh data after company is saved/edited
                        }}
                        onClose={() => setCompanyToEdit(null)}
                    />
                </div>
            </div>
          )}
        </div>
      </div>
      {introModalCompany && (
        <LaunchIntroModal
            company={introModalCompany}
            onClose={() => setIntroModalCompany(null)}
            onStartDIY={() => {
                setGeminiSimulatingCompany(introModalCompany);
                setIntroModalCompany(null);
            }}
            onGoPro={() => {
                setProLaunchCompany(introModalCompany);
                setIntroModalCompany(null);
            }}
        />
      )}
    </div>
  );
}
