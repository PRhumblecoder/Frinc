import Layout from "./Layout.jsx";

import Test from "./Test";

import Dashboard from "./Dashboard";

import Settings from "./Settings";

import About from "./About";

import Homepage from "./Homepage";

import Inbox from "./Inbox";

import LogoDisplay from "./LogoDisplay";

import AdminStateData from "./AdminStateData";

import Admin from "./Admin";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Test: Test,
    
    Dashboard: Dashboard,
    
    Settings: Settings,
    
    About: About,
    
    Homepage: Homepage,
    
    Inbox: Inbox,
    
    LogoDisplay: LogoDisplay,
    
    AdminStateData: AdminStateData,
    
    Admin: Admin,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Test />} />
                
                
                <Route path="/Test" element={<Test />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/About" element={<About />} />
                
                <Route path="/Homepage" element={<Homepage />} />
                
                <Route path="/Inbox" element={<Inbox />} />
                
                <Route path="/LogoDisplay" element={<LogoDisplay />} />
                
                <Route path="/AdminStateData" element={<AdminStateData />} />
                
                <Route path="/Admin" element={<Admin />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}