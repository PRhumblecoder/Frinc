import React, { useState, useEffect } from 'react';
import { Test } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { motion, AnimatePresence } from 'framer-motion';

export default function TestPage() {
    const [tests, setTests] = useState([]);
    const [newName, setNewName] = useState('');
    const [loading, setLoading] = useState(true);

    const loadTests = async () => {
        setLoading(true);
        const testRecords = await Test.list('-created_date');
        setTests(testRecords);
        setLoading(false);
    };

    useEffect(() => {
        loadTests();
    }, []);

    const handleCreate = async (e) => {
        e.preventDefault();
        if (!newName.trim()) return;
        await Test.create({ name: newName });
        setNewName('');
        loadTests();
    };
    
    const handleDelete = async (id) => {
        await Test.delete(id);
        loadTests();
    }

    return (
        <div className="min-h-screen bg-gray-50 p-4 sm:p-6 md:p-8">
            <div className="max-w-2xl mx-auto">
                <Card>
                    <CardHeader>
                        <CardTitle className="text-2xl font-bold">Test Records</CardTitle>
                        <CardDescription>Create and manage test records for your application.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleCreate} className="flex gap-2 mb-6">
                            <Input
                                placeholder="Enter a new record name..."
                                value={newName}
                                onChange={(e) => setNewName(e.target.value)}
                                className="flex-grow"
                            />
                            <Button type="submit">Add Record</Button>
                        </form>
                        
                        <div className="space-y-3">
                            {loading ? (
                                <p className="text-center text-gray-500">Loading records...</p>
                            ) : (
                                <AnimatePresence>
                                    {tests.map(test => (
                                        <motion.div
                                            key={test.id}
                                            layout
                                            initial={{ opacity: 0, y: -20 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            exit={{ opacity: 0, x: -50 }}
                                            className="flex items-center justify-between p-3 bg-white border rounded-lg shadow-sm"
                                        >
                                            <span className="text-gray-800">{test.name}</span>
                                            <Button variant="ghost" size="sm" onClick={() => handleDelete(test.id)}>
                                                Delete
                                            </Button>
                                        </motion.div>
                                    ))}
                                </AnimatePresence>
                            )}
                             {!loading && tests.length === 0 && (
                                <p className="text-center text-gray-400 py-4">No test records found. Add one above to get started.</p>
                            )}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}