
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User as UserEntity } from '@/api/entities';
import { StateData } from '@/api/entities';
import { Company } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart3, 
  Users, 
  Building, 
  MapPin, 
  Search, 
  Eye, 
  Plus, 
  Download, 
  Edit,
  Ban,
  ArrowUpDown,
  FileText,
  Shield
} from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function AdminPage() {
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState({
    states: 0,
    users: 0,
    companies: 0
  });
  const [activeView, setActiveView] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  
  // Data states
  const [states, setStates] = useState([]);
  const [users, setUsers] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [userCompanies, setUserCompanies] = useState({});
  
  // Search and filtering
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState('');
  const [sortDirection, setSortDirection] = useState('asc');
  
  // Modals
  const [blockUserModal, setBlockUserModal] = useState(null);
  const [selectedUserCompanies, setSelectedUserCompanies] = useState(null);

  useEffect(() => {
    checkAccess();
    loadStats();
  }, []);

  const checkAccess = async () => {
    try {
      const currentUser = await UserEntity.me();
      if (currentUser.role !== 'admin') {
        throw new Error('Access denied');
      }
      setUser(currentUser);
    } catch (error) {
      window.location.href = '/';
    }
  };

  const loadStats = async () => {
    try {
      const [statesData, usersData, companiesData] = await Promise.all([
        StateData.list(),
        UserEntity.list(),
        Company.list()
      ]);
      
      setStats({
        states: statesData.length,
        users: usersData.length,
        companies: companiesData.length
      });
      
      setStates(statesData);
      setUsers(usersData);
      setCompanies(companiesData);
      
      // Calculate company counts per user
      const companyCountsPerUser = {};
      companiesData.forEach(company => {
        const createdBy = company.created_by;
        if (companyCountsPerUser[createdBy]) {
          companyCountsPerUser[createdBy].count++;
          companyCountsPerUser[createdBy].companies.push(company);
        } else {
          companyCountsPerUser[createdBy] = { count: 1, companies: [company] };
        }
      });
      setUserCompanies(companyCountsPerUser);
      
    } catch (error) {
      console.error('Failed to load stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBlockUser = async (userToBlock) => {
    try {
      await UserEntity.update(userToBlock.id, { blocked: true });
      setBlockUserModal(null);
      loadStats(); // Refresh data
      alert(`User ${userToBlock.email} has been blocked.`);
    } catch (error) {
      console.error('Failed to block user:', error);
      alert('Failed to block user. Please try again.');
    }
  };

  const exportData = (data, filename) => {
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const sortData = (data, field) => {
    if (!field) return data;
    
    return [...data].sort((a, b) => {
      let aVal = a[field];
      let bVal = b[field];
      
      if (typeof aVal === 'string') {
        aVal = aVal.toLowerCase();
        bVal = bVal.toLowerCase();
      }
      
      if (sortDirection === 'asc') {
        return aVal > bVal ? 1 : -1;
      } else {
        return aVal < bVal ? 1 : -1;
      }
    });
  };

  const filterData = (data, searchTerm) => {
    if (!searchTerm) return data;
    
    return data.filter(item => 
      Object.values(item).some(value => 
        value && value.toString().toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-8">
        <Shield className="w-8 h-8 text-[var(--primary)]" />
        <div>
          <h1 className="text-3xl font-bold text-[var(--text-primary)]">Admin Dashboard</h1>
          <p className="text-[var(--text-secondary)]">Manage your frinc.ai platform</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* States Card */}
        <Card className="bg-[var(--background)] border-[var(--border)]">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-2xl font-bold text-[var(--primary)]">{stats.states}</CardTitle>
              <p className="text-[var(--text-secondary)]">States in Database</p>
            </div>
            <MapPin className="w-8 h-8 text-[var(--primary)] opacity-70" />
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              onClick={() => setActiveView('states')}
              variant="outline" 
              className="w-full text-[var(--text-primary)] border-[var(--border)] hover:bg-[var(--accent)]"
            >
              <Eye className="w-4 h-4 mr-2" />
              View All States
            </Button>
            <div className="flex gap-2">
              <Button 
                onClick={() => window.location.href = '/AdminStateData'}
                size="sm" 
                className="flex-1 bg-[var(--primary)] text-[var(--primary-foreground)]"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add State
              </Button>
              <Button 
                onClick={() => exportData(states, 'states')}
                size="sm" 
                variant="outline"
                className="flex-1"
              >
                <Download className="w-4 h-4 mr-1" />
                Export
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Users Card */}
        <Card className="bg-[var(--background)] border-[var(--border)]">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-2xl font-bold text-[var(--primary)]">{stats.users}</CardTitle>
              <p className="text-[var(--text-secondary)]">Registered Users</p>
            </div>
            <Users className="w-8 h-8 text-[var(--primary)] opacity-70" />
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              onClick={() => setActiveView('users')}
              variant="outline" 
              className="w-full text-[var(--text-primary)] border-[var(--border)] hover:bg-[var(--accent)]"
            >
              <Eye className="w-4 h-4 mr-2" />
              View All Users
            </Button>
          </CardContent>
        </Card>

        {/* Companies Card */}
        <Card className="bg-[var(--background)] border-[var(--border)]">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-2xl font-bold text-[var(--primary)]">{stats.companies}</CardTitle>
              <p className="text-[var(--text-secondary)]">Companies Created</p>
            </div>
            <Building className="w-8 h-8 text-[var(--primary)] opacity-70" />
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              onClick={() => setActiveView('companies')}
              variant="outline" 
              className="w-full text-[var(--text-primary)] border-[var(--border)] hover:bg-[var(--accent)]"
            >
              <Eye className="w-4 h-4 mr-2" />
              View All Companies
            </Button>
            <Button 
              onClick={() => exportData(companies, 'companies')}
              variant="outline"
              className="w-full"
            >
              <Download className="w-4 h-4 mr-2" />
              Export Companies
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderStatesTable = () => {
    const filteredData = filterData(states, searchTerm);
    const sortedData = sortData(filteredData, sortField);

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setActiveView('dashboard')}
            variant="ghost"
            className="text-[var(--text-primary)]"
          >
            ← Back to Dashboard
          </Button>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-[var(--text-secondary)]" />
              <Input
                placeholder="Search states..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Button onClick={() => window.location.href = '/AdminStateData'}>
              <Plus className="w-4 h-4 mr-2" />
              Add State
            </Button>
          </div>
        </div>

        <Card className="bg-[var(--background)] border-[var(--border)]">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('state_name')}
                >
                  State Name <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
                <TableHead className="text-[var(--text-primary)]">Website</TableHead> {/* Added text color */}
                <TableHead className="text-[var(--text-primary)]">LLC Fee</TableHead> {/* Added text color */}
                <TableHead className="text-[var(--text-primary)]">Corp Fee</TableHead> {/* Added text color */}
                <TableHead className="text-[var(--text-primary)]">Actions</TableHead> {/* Added text color */}
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedData.map((state) => (
                <TableRow key={state.id}>
                  <TableCell className="font-medium text-[var(--text-primary)]">{state.state_name}</TableCell> {/* Added text color */}
                  <TableCell className="text-[var(--text-primary)]"> {/* Added text color */}
                    {state.incorporation_website_url ? 
                      <Badge variant="secondary">Yes</Badge> : 
                      <Badge variant="outline">No</Badge>
                    }
                  </TableCell>
                  <TableCell className="text-[var(--text-primary)]">${state.fees?.normal_processing?.llc_fee || 'N/A'}</TableCell> {/* Added text color */}
                  <TableCell className="text-[var(--text-primary)]">${state.fees?.normal_processing?.inc_fee || 'N/A'}</TableCell> {/* Added text color */}
                  <TableCell>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => window.location.href = `/AdminStateData?edit=${state.id}`}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </div>
    );
  };

  const renderUsersTable = () => {
    const filteredData = filterData(users, searchTerm);
    const sortedData = sortData(filteredData, sortField);

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setActiveView('dashboard')}
            variant="ghost"
            className="text-[var(--text-primary)]"
          >
            ← Back to Dashboard
          </Button>
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-[var(--text-secondary)]" />
            <Input
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
        </div>

        <Card className="bg-[var(--background)] border-[var(--border)]">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('email')}
                >
                  Email <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('full_name')}
                >
                  Name <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('role')}
                >
                  Role <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
                <TableHead className="text-[var(--text-primary)]">Companies</TableHead> {/* Added text color */}
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('created_date')}
                >
                  Joined <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
                <TableHead className="text-[var(--text-primary)]">Actions</TableHead> {/* Added text color */}
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedData.map((userData) => (
                <TableRow key={userData.id}>
                  <TableCell className="font-medium text-[var(--text-primary)]">{userData.email}</TableCell> {/* Added text color */}
                  <TableCell className="text-[var(--text-primary)]">{userData.full_name || 'N/A'}</TableCell> {/* Added text color */}
                  <TableCell className="text-[var(--text-primary)]"> {/* Added text color */}
                    <Badge variant={userData.role === 'admin' ? 'default' : 'secondary'}>
                      {userData.role}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-[var(--text-primary)]"> {/* Added text color */}
                    <div className="flex items-center gap-2">
                      <span>{userCompanies[userData.email]?.count || 0}</span>
                      {userCompanies[userData.email]?.count > 0 && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setSelectedUserCompanies(userCompanies[userData.email].companies)}
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-[var(--text-secondary)]"> {/* Changed to text-secondary */}
                    {new Date(userData.created_date).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-red-500 hover:text-red-600"
                      onClick={() => setBlockUserModal(userData)}
                    >
                      <Ban className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </div>
    );
  };

  const renderCompaniesTable = () => {
    const filteredData = filterData(companies, searchTerm);
    const sortedData = sortData(filteredData, sortField);

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setActiveView('dashboard')}
            variant="ghost"
            className="text-[var(--text-primary)]"
          >
            ← Back to Dashboard
          </Button>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-[var(--text-secondary)]" />
              <Input
                placeholder="Search companies..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Button onClick={() => exportData(companies, 'companies')}>
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        <Card className="bg-[var(--background)] border-[var(--border)]">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('company_name')}
                >
                  Company Name <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('state')}
                >
                  State <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('company_type')}
                >
                  Type <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('status')}
                >
                  Status <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('created_by')}
                >
                  Created By <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
                <TableHead 
                  className="cursor-pointer text-[var(--text-primary)]" // Added text color
                  onClick={() => handleSort('created_date')}
                >
                  Created <ArrowUpDown className="w-4 h-4 inline ml-1" />
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedData.map((company) => (
                <TableRow key={company.id}>
                  <TableCell className="font-medium text-[var(--text-primary)]">{company.company_name}</TableCell> {/* Added text color */}
                  <TableCell className="text-[var(--text-primary)]">{company.state}</TableCell> {/* Added text color */}
                  <TableCell className="text-[var(--text-primary)]"> {/* Added text color */}
                    <Badge variant="outline">{company.company_type.toUpperCase()}</Badge>
                  </TableCell>
                  <TableCell className="text-[var(--text-primary)]"> {/* Added text color */}
                    <Badge variant={company.status === 'completed' ? 'default' : 'secondary'}>
                      {company.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-[var(--text-primary)]">{company.created_by}</TableCell> {/* Added text color */}
                  <TableCell className="text-[var(--text-secondary)]">{new Date(company.created_date).toLocaleDateString()}</TableCell> {/* Changed to text-secondary */}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[var(--background-alt)] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-4 border-[var(--primary)] border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-[var(--text-secondary)]">Loading admin dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--background-alt)] p-6">
      <div className="max-w-7xl mx-auto">
        {activeView === 'dashboard' && renderDashboard()}
        {activeView === 'states' && renderStatesTable()}
        {activeView === 'users' && renderUsersTable()}
        {activeView === 'companies' && renderCompaniesTable()}
      </div>

      {/* Block User Modal */}
      <Dialog open={!!blockUserModal} onOpenChange={() => setBlockUserModal(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Block User</DialogTitle>
            <DialogDescription>
              Are you sure you want to block {blockUserModal?.email}? This will prevent them from logging into the app.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBlockUserModal(null)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => handleBlockUser(blockUserModal)}
            >
              Block
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* User Companies Modal */}
      <Dialog open={!!selectedUserCompanies} onOpenChange={() => setSelectedUserCompanies(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>User's Companies</DialogTitle>
          </DialogHeader>
          <div className="max-h-96 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-[var(--text-primary)]">Company Name</TableHead> {/* Added text color */}
                  <TableHead className="text-[var(--text-primary)]">State</TableHead> {/* Added text color */}
                  <TableHead className="text-[var(--text-primary)]">Type</TableHead> {/* Added text color */}
                  <TableHead className="text-[var(--text-primary)]">Status</TableHead> {/* Added text color */}
                  <TableHead className="text-[var(--text-primary)]">Created</TableHead> {/* Added text color */}
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedUserCompanies?.map((company) => (
                  <TableRow key={company.id}>
                    <TableCell className="text-[var(--text-primary)]">{company.company_name}</TableCell> {/* Added text color */}
                    <TableCell className="text-[var(--text-primary)]">{company.state}</TableCell> {/* Added text color */}
                    <TableCell className="text-[var(--text-primary)]">{company.company_type.toUpperCase()}</TableCell> {/* Added text color */}
                    <TableCell className="text-[var(--text-primary)]"> {/* Added text color */}
                      <Badge variant={company.status === 'completed' ? 'default' : 'secondary'}>
                        {company.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-[var(--text-secondary)]">{new Date(company.created_date).toLocaleDateString()}</TableCell> {/* Changed to text-secondary */}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
