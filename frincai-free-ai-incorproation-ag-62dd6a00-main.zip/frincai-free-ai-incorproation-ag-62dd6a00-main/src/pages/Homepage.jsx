
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Palette, Sun, Moon, Smile, Bot, Sparkles, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { User as UserEntity } from '@/api/entities';
import { Company } from '@/api/entities';
import { createPageUrl } from '@/utils';
import Logo from '../components/Logo';
import { InvokeLLM } from '@/api/integrations';

// Import screen components for modal flow
import WelcomeScreen from '../components/homepage/WelcomeScreen';
import MenuScreen from '../components/homepage/MenuScreen';
import InfoScreen from '../components/homepage/InfoScreen';
import StateSelector from '../components/homepage/flow/StateSelector';
import TypeSelector from '../components/homepage/flow/TypeSelector';
import NameScreen from '../components/homepage/flow/NameScreen';
import OwnersList from '../components/homepage/flow/OwnersList';
import OwnerForm from '../components/homepage/flow/OwnerForm';
import ManagersList from '../components/homepage/flow/ManagersList';
import StateAdvisorFlow from '../components/homepage/advisor/StateAdvisorFlow';
import TypeAdvisorFlow from '../components/homepage/advisor/TypeAdvisorFlow';

// Import new chat components
import ChatMessage from '../components/chat/ChatMessage';
import SuggestedReplies from '../components/chat/SuggestedReplies';
import TextInput from '../components/chat/TextInput';

// Corrected and complete list of US states
const US_STATES = [
  'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
];
const COMPANY_TYPES = [
  { id: 'llc', name: 'LLC', description: 'Limited Liability Company' },
  { id: 'inc', name: 'INC', description: 'Corporation' },
  { id: 'scorp', name: 'S.Corp', description: 'S Corporation' }
];
const LLC_ENDINGS = ['LLC', 'L.L.C.', 'Limited Liability Company'];
const CORP_ENDINGS = ['Corporation', 'Incorporated', 'Company', 'Limited', 'Corp.', 'Inc.', 'Co.', 'Ltd.'];
// OFFICER_TITLES constant removed as it's no longer used for owner/manager titles

export default function Homepage({ isModal = false, companyToEdit = null, onSaveComplete = () => {}, onClose = () => {} }) {
  // --- STATE FOR MODAL/OLD FLOW ---
  const [currentScreen, setCurrentScreen] = useState('welcome');
  const [previousScreen, setPreviousScreen] = useState('welcome');
  const [selectedState, setSelectedState] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [legalEnding, setLegalEnding] = useState('');
  const [owners, setOwners] = useState([]);
  const [managers, setManagers] = useState([]); // This state will now effectively always be empty in the old flow
  const [currentOwnerIndex, setCurrentOwnerIndex] = useState(-1); // Only for old flow owner editing
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [stateSearch, setStateSearch] = useState('');
  const [isFlowActive, setIsFlowActive] = useState(false);
  const [helpFlowStep, setHelpFlowStep] = useState(1);
  const [helpFlowData, setHelpFlowData] = useState({ businessDescription: '', residency: '', physicalLocation: '', priorities: [] });
  const [stateAdvisorResult, setStateAdvisorResult] = useState(null);
  const [isStateAdvisorLoading, setIsStateAdvisorLoading] = useState(false);
  const [stateAdvisorLoadingMessageIndex, setStateAdvisorLoadingMessageIndex] = useState(0);
  const stateAdvisorLoadingMessages = ["Analyzing your business needs...","Cross-referencing state regulations...","Evaluating tax implications...","Finalizing recommendations..."];
  // currentPerson is now used by both flows and can represent an owner or manager
  const [currentPerson, setCurrentPerson] = useState({ firstName: '', middleName: '', lastName: '', streetAddress: '', suite: '', city: '', state: '', zipCode: '', country: 'USA', ownershipPercent: '', isManager: false });
  const [organizer, setOrganizer] = useState(null); // New state for organizer
  const [personToMakeManager, setPersonToMakeManager] = useState(null); // New state for manager title selection

  // --- STATE FOR NEW CHAT INTERFACE ---
  const [user, setUser] = useState(null);
  const [theme, setTheme] = useState('fun');
  const [stage, setStage] = useState('START'); // Default to START, allowing welcome screen to show.
  const [messages, setMessages] = useState([]);
  const [suggestedReplies, setSuggestedReplies] = useState([]);
  const [isAiTyping, setIsAiTyping] = useState(false);
  const chatContainerRef = useRef(null);

  const [companyData, setCompanyData] = useState({
      state: '',
      type: '',
      name: '',
      ending: ''
  });

  const [chatOwners, setChatOwners] = useState([]);
  const [chatManagers, setChatManagers] = useState([]); // New state for chat managers
  const [currentPersonIndex, setCurrentPersonIndex] = useState(-1); // Used for chat flow person editing (owner/manager index)
  const [isEditingManager, setIsEditingManager] = useState(false); // Flag for chat flow OwnerForm usage (true if editing a manager)
  const [isEditingOrganizer, setIsEditingOrganizer] = useState(false); // New flag for organizer

  // New states for state validation fix (as per outline)
  const [stateInput, setStateInput] = useState('');
  const [showStateSuggestions, setShowStateSuggestions] = useState(false);

  // New state for typing animation
  const [typedSubtitle, setTypedSubtitle] = useState('');
  const [isSubtitleTyping, setIsSubtitleTyping] = useState(false);

  // New functions for state validation fix (as per outline)
  const handleStateInputChange = (e) => {
    const value = e.target.value;
    setStateInput(value); // Update local state for input field value
    setStateSearch(value); // Also update stateSearch, used by StateSelector
    setShowStateSuggestions(value.length > 0); // Control visibility of suggestions
  };

  const handleStateSelect = (state) => {
    setStateInput(state); // Set the input field to the selected state
    setSelectedState(state); // Update the main selected state for the old flow
    setCompanyData(prev => ({ ...prev, state: state })); // Update company data for chat flow
    setShowStateSuggestions(false); // Hide suggestions after selection
  };

  // Filtered states for suggestions, used in conjunction with stateInput
  const filteredStates = US_STATES.filter(state =>
    state.toLowerCase().includes(stateInput.toLowerCase())
  );

  const handleStateAdvisorAnalysis = async () => {
    setHelpFlowStep(5);
    setIsStateAdvisorLoading(true);
    setStateAdvisorLoadingMessageIndex(0); // Reset to first message

    // Start cycling through loading messages
    const loadingInterval = setInterval(() => {
      setStateAdvisorLoadingMessageIndex(prevIndex => (prevIndex + 1) % stateAdvisorLoadingMessages.length);
    }, 2000);

    const prompt = `You are an expert US business formation and tax advisor. A user needs a state of incorporation recommendation. User's Information: - Business Description: "${helpFlowData.businessDescription}" - State of Residency: "${helpFlowData.residency}" - Physical Business Location: "${helpFlowData.physicalLocation}" - Top Priorities: ${helpFlowData.priorities.join(', ')}. It is crucial that you give significantly higher weight to these user-stated priorities when calculating the overall_score and sorting the results. For example, if 'Low Setup Cost' is a priority, states with lower filing fees like New Mexico or Colorado should be scored more favorably for that factor and it should heavily influence the final overall score. Please evaluate the top US states for incorporation (like Delaware, Wyoming, Nevada, New Mexico, Florida, and the user's home state if provided) based on these factors: - Owners' Privacy - Fundraising Potential - Low Setup Cost - Low Maintenance Cost. Return a detailed comparison and recommendations. The entire response must be a single JSON object matching the provided schema. Give a score from 1 to 10 for each factor for each recommended state. Sort the recommendations by overall_score descending.`;

    const schema = {
      type: "object",
      properties: {
        "top_recommended_states": {
          "type": "array",
          "description": "A list of top recommended states, sorted by overall score.",
          "items": {
            "type": "object",
            "properties": {
              "state_name": { "type": "string" }, "summary": { "type": "string" }, "overall_score": { "type": "number" }, "owners_privacy_score": { "type": "number" }, "fundraising_score": { "type": "number" }, "income_tax_score": { "type": "number", "description": "Deprecated - will be removed soon. Retained for backward compatibility. Please use setup_cost_score and maintenance_cost_score instead." }, "sales_tax_score": { "type": "number", "description": "Deprecated - will be removed soon. Retained for backward compatibility. Please use setup_cost_score and maintenance_cost_score instead." }, "setup_cost_score": { "type": "number" }, "maintenance_cost_score": { "type": "number" }
            },
            required: ["state_name", "summary", "overall_score", "owners_privacy_score", "fundraising_score", "income_tax_score", "sales_tax_score", "setup_cost_score", "maintenance_cost_score"]
          }
        },
        "analysis_summary": { "type": "string", "description": "A brief summary of the overall recommendation, explaining the top choice." }
      },
      required: ["top_recommended_states", "analysis_summary"]
    };

    try {
      const result = await InvokeLLM({ prompt, response_json_schema: schema });
      result.top_recommended_states.sort((a, b) => b.overall_score - a.overall_score);
      setStateAdvisorResult(result);
    } catch (error) {
      console.error("State Advisor analysis failed:", error);
      setStateAdvisorResult({ error: "Sorry, the AI analysis failed. Please try again." });
    } finally {
      clearInterval(loadingInterval); // Stop cycling messages
      setIsStateAdvisorLoading(false);
    }
  };

  const handleStateAdvisorStartOver = () => {
    setHelpFlowData({ businessDescription: '', residency: '', physicalLocation: '', priorities: [] });
    setStateAdvisorResult(null);
    setHelpFlowStep(1);
  };

  // --- THEME AND USER LOGIC (SHARED) ---
  useEffect(() => {
    const storedTheme = localStorage.getItem('app-theme') || 'fun';
    setTheme(storedTheme);
    checkUser();
  }, []);

  useEffect(() => {
    document.documentElement.className = '';
    document.documentElement.classList.add(`theme-${theme}`);
    localStorage.setItem('app-theme', theme);
  }, [theme]);

  const checkUser = useCallback(async () => {
    try {
      const currentUser = await UserEntity.me();
      setUser(currentUser);
    } catch (e) {
      setUser(null);
    }
  }, []);

  // Add typing animation for subtitle
  useEffect(() => {
    if (!isModal) {
      const subtitle = "AI incorporation agent";
      let i = 0;
      setIsSubtitleTyping(true);
      
      // Add a small delay before starting to type
      const startDelay = setTimeout(() => {
        const typingInterval = setInterval(() => {
          if (i < subtitle.length) {
            setTypedSubtitle(subtitle.slice(0, i + 1));
            i++;
          } else {
            clearInterval(typingInterval);
            setIsSubtitleTyping(false);
          }
        }, 80); // Typing speed in milliseconds

        return () => clearInterval(typingInterval);
      }, 1000); // 1 second delay before starting

      return () => clearTimeout(startDelay);
    }
  }, [isModal]);

  // --- CHAT INTERFACE LOGIC ---

  // Memoize addMessage to prevent unnecessary re-renders in effects
  const addMessage = useCallback((sender, text, options = {}) => {
    setMessages(prev => [...prev, { sender, text, ...options }]);
  }, []);

  // Initial conversation start for chat interface (non-modal)
  useEffect(() => {
    if (!isModal) {
      setSuggestedReplies(["Let's start!", "How does it work?"]);
      setStage('START');
      setIsAiTyping(false);
    }
  }, [isModal]);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleEdit = (stageToEdit, personIndex, isManagerEdit = false) => {
    // Logic for editing owners specifically in chat flow
    if (stageToEdit === 'OWNER_EDIT' && !isManagerEdit) {
        if (chatOwners[personIndex]) {
            setCurrentPersonIndex(personIndex);
            setIsEditingManager(false);
            setIsEditingOrganizer(false); // Ensure this is false
            setCurrentPerson({ ...chatOwners[personIndex], isManager: false }); // Ensure isManager is explicitly false
            setCurrentScreen('owner_form');
        } else {
            console.warn(`Could not find owner with index: ${personIndex}`);
        }
        return;
    }
    // Logic for editing managers specifically in chat flow
    if (stageToEdit === 'MANAGER_EDIT' && isManagerEdit) {
        if (chatManagers[personIndex]) {
            setCurrentPersonIndex(personIndex);
            setIsEditingManager(true);
            setIsEditingOrganizer(false); // Ensure this is false
            setCurrentPerson({ ...chatManagers[personIndex], isManager: true }); // Ensure isManager is explicitly true
            setCurrentScreen('owner_form'); // Reusing owner_form for manager editing
        } else {
            console.warn(`Could not find manager with index: ${personIndex}`);
        }
        return;
    }

    // Find the index of the message to be edited by searching from the end for robustness
    let messageIndexToRevertTo = -1;
    for (let i = messages.length - 1; i >= 0; i--) {
        const msg = messages[i];
        if (msg.sender === 'user' && msg.stage === stageToEdit && msg.isEditable) { // Changed to 'user' sender
            messageIndexToRevertTo = i;
            break;
        }
    }

    if (messageIndexToRevertTo === -1) {
        console.warn(`Could not find editable message for stage: ${stageToEdit}`);
        return;
    }

    // Revert messages to the point just before the editable AI message
    const revertedMessages = messages.slice(0, messageIndexToRevertTo);
    setMessages(revertedMessages);

    setIsAiTyping(true);

    setTimeout(() => {
      let aiMessage, replies, nextStage;

      switch(stageToEdit) {
        case 'STATE_SELECT':
          aiMessage = "Okay, let's pick a different state. Which state would you like to incorporate in?";
          replies = ['Select from a list', 'Use AI State Advisor'];
          nextStage = 'CHOOSE_STATE_METHOD';
          // Reset all company data related to state and subsequent choices
          setCompanyData({ state: '', type: '', name: '', ending: '' });
          setChatOwners([]); // Also reset owners if state is changed
          setChatManagers([]); // Also reset managers if state is changed
          setOrganizer(null); // Reset organizer too if state changes
          break;
        case 'TYPE_SELECT':
          // Preserve state, but reset type and subsequent
          aiMessage = `Sure thing. What type of company would you like to form in ${companyData.state}?`;
          replies = [...COMPANY_TYPES.map(t => t.name), 'AI Type Advisor'];
          nextStage = 'TYPE_SELECT';
          setCompanyData(prev => ({ ...prev, type: '', name: '', ending: '' }));
          setChatOwners([]); // Also reset owners if type is changed
          setChatManagers([]);
          setOrganizer(null);
          break;
        case 'NAME_INPUT_PENDING': // Allow editing company name
          aiMessage = "Alright, let's change the company name. What would you like to call it?";
          addMessage('ai', "Just enter the business name without any legal ending (like LLC or Inc) - I'll ask you to choose that in the next step.");
          replies = []; // Clear suggestions for text input
          nextStage = 'NAME_INPUT_PENDING';
          // Preserve state, type. Reset name and subsequent.
          setCompanyData(prev => ({ ...prev, name: '', ending: '' }));
          setChatOwners([]);
          setChatManagers([]);
          setOrganizer(null);
          break;
        case 'ENDING_SELECT':
          // Preserve state, type, name, but reset ending
          aiMessage = `No problem. Let's choose a different legal ending for ${companyData.name}.`;
          const endings = companyData.type === 'llc' ? LLC_ENDINGS : CORP_ENDINGS;
          replies = endings;
          nextStage = 'ENDING_SELECT';
          setCompanyData(prev => ({ ...prev, ending: '' }));
          // No need to reset owners/managers or organizer here, as ending choice doesn't invalidate person data usually.
          break;
        default:
          setIsAiTyping(false);
          return;
      }

      addMessage('ai', aiMessage);
      setSuggestedReplies(replies);
      setStage(nextStage);
      setIsAiTyping(false);
    }, 800);
  };

  const startConversation = () => {
    setMessages([]);
    setSuggestedReplies(["Let's start!", "How does it work?"]);
    setStage('START');
    setIsAiTyping(false);
    // When restarting, close any open advisor or form overlays and clear data
    setCurrentScreen('welcome');
    setCompanyData({ state: '', type: '', name: '', ending: '' });
    setChatOwners([]);
    setChatManagers([]);
    setOrganizer(null);
    // Add the initial AI messages when restarting the conversation
    // This is explicitly called here as the useEffect no longer adds messages directly
    addMessage('ai', "Hi! I'm your AI incorporation agent. I can help you start your U.S. company quickly and easily.");
    addMessage('ai', "Choose how you'd like to proceed:");
  };

  const handleReply = (reply) => {
    // addMessage('user', typeof reply === 'string' ? reply : reply.label); // REMOVED to prevent duplication
    setSuggestedReplies([]);
    setIsAiTyping(true);

    setTimeout(() => {
      processReply(reply);
    }, 1000);
  };

  const processReply = (reply) => {
    const userMessageText = typeof reply === 'string' ? reply : reply.label;

    switch (stage) {
      case 'START':
        addMessage('user', userMessageText);
        setIsAiTyping(false);
        if (reply === "Let's start!") {
          addMessage('ai', "Great! First, select your state of incorporation from the options below. If you are not sure, use our AI state advisor to get help.");
          setSuggestedReplies(['Select from a list', 'Use AI State Advisor']);
          setStage('CHOOSE_STATE_METHOD');
        } else { // "How does it work?"
          addMessage('ai', "I'm an AI agent that makes starting a US company simple. I'll guide you through the process and handle the paperwork. My service is free—you only pay mandatory state fees. Ready to begin?");
          setSuggestedReplies(["Yes, let's begin!"]);
          setStage('HOW_IT_WORKS_CONFIRM');
        }
        break;

      case 'HOW_IT_WORKS_CONFIRM':
        addMessage('user', userMessageText);
        setIsAiTyping(false);
        addMessage('ai', "Excellent! So, select your state of incorporation from the options below. If you are not sure, use our AI state advisor to get help.");
        setSuggestedReplies(['Select from a list', 'Use AI State Advisor']);
        setStage('CHOOSE_STATE_METHOD');
        break;

      case 'CHOOSE_STATE_METHOD':
        addMessage('user', userMessageText);
        setIsAiTyping(false);
        if (reply === 'Select from a list') {
          addMessage('ai', "Sounds good. Please choose a state from the options below.");
          setSuggestedReplies([...US_STATES, 'Use AI State Advisor']);
          setStage('STATE_SELECT');
        } else if (reply === 'Use AI State Advisor') {
          addMessage('ai', "Great choice! The AI State Advisor will help me understand your business needs and recommend the perfect state. Let me open that for you now.");
          setSuggestedReplies(['Start AI Advisor', 'Select from List']);
          setStage('STATE_ADVISOR_CONFIRM');
        }
        break;

      case 'STATE_ADVISOR_CONFIRM':
        addMessage('user', userMessageText);
        if (reply === 'Start AI Advisor') {
          setIsAiTyping(true);
          setTimeout(() => {
            setCurrentScreen('state_advisor');
            setIsAiTyping(false);
          }, 1000);
        } else if (reply === 'Select from List') {
          setIsAiTyping(false);
          addMessage('ai', "No problem. Please choose a state from the options below.");
          setSuggestedReplies([...US_STATES, 'Use AI State Advisor']);
          setStage('STATE_SELECT');
        }
        break;

      case 'STATE_SELECT':
        if (reply === 'Use AI State Advisor') {
          addMessage('user', userMessageText);
          setIsAiTyping(false);
          addMessage('ai', "Great choice! The AI State Advisor will help me understand your business needs and recommend the perfect state. Let me open that for you now.");
          setSuggestedReplies(['Start AI Advisor', 'Select from List']);
          setStage('STATE_ADVISOR_CONFIRM');
        } else if (US_STATES.includes(reply)) {
          setCompanyData(prev => ({ ...prev, state: reply }));
          addMessage('user', userMessageText, { stage: 'STATE_SELECT', isEditable: true });
          setIsAiTyping(false);
          addMessage('ai', `Awesome, ${reply} is a great choice. Now, what type of company are you forming?`);
          setSuggestedReplies([...COMPANY_TYPES.map(t => t.name), 'AI Type Advisor']);
          setStage('TYPE_SELECT');
        }
        break;

      case 'TYPE_SELECT':
        if (reply === 'AI Type Advisor') {
          addMessage('user', userMessageText);
          setIsAiTyping(false);
          addMessage('ai', "Perfect! The AI Type Advisor will analyze your business needs and recommend the best entity type for you. Let me open that now.");
          setSuggestedReplies(['Start AI Advisor', 'Select from List']);
          setStage('TYPE_ADVISOR_CONFIRM');
        } else {
          const selectedType = COMPANY_TYPES.find(t => t.name === reply);
          if (selectedType) {
            setCompanyData(prev => ({ ...prev, type: selectedType.id }));
            addMessage('user', userMessageText, { stage: 'TYPE_SELECT', isEditable: true });
            setIsAiTyping(false);
            addMessage('ai', `Perfect. Next, let's choose a name for your new ${reply}. What would you like to call it?`);
            addMessage('ai', "Just enter the business name without any legal ending (like LLC or Inc) - I'll ask you to choose that in the next step.");
            setSuggestedReplies([]); // Clear suggestions to show text input
            setStage('NAME_INPUT_PENDING');
          } else {
            setIsAiTyping(false);
            addMessage('ai', "Sorry, I didn't understand that. Please select a company type from the options provided.");
            setSuggestedReplies([...COMPANY_TYPES.map(t => t.name), 'AI Type Advisor']);
            setStage('TYPE_SELECT');
          }
        }
        break;

      case 'TYPE_ADVISOR_CONFIRM':
        addMessage('user', userMessageText);
        if (reply === 'Start AI Advisor') {
          setIsAiTyping(true);
          setTimeout(() => {
            setCurrentScreen('type_advisor');
            setIsAiTyping(false);
          }, 1000);
        } else if (reply === 'Select from List') {
          setIsAiTyping(false);
          addMessage('ai', "No problem. What type of company are you forming?");
          setSuggestedReplies([...COMPANY_TYPES.map(t => t.name), 'AI Type Advisor']);
          setStage('TYPE_SELECT');
        }
        break;

      case 'NAME_INPUT_PENDING':
        // Accept any text input as the company name
        setCompanyData(prev => ({ name: reply, state: companyData.state, type: companyData.type })); // Ensure companyData is not lost
        addMessage('user', userMessageText, { stage: 'NAME_INPUT_PENDING', isEditable: true }); // Add editability for name input
        setIsAiTyping(false);
        addMessage('ai', "Got it. And what legal ending should we use?");
        const endings = companyData.type === 'llc' ? LLC_ENDINGS : CORP_ENDINGS;
        setSuggestedReplies(endings);
        setStage('ENDING_SELECT');
        break;

      case 'ENDING_SELECT':
        setCompanyData(prev => ({...prev, ending: reply}));
        addMessage('user', userMessageText, { stage: 'ENDING_SELECT', isEditable: true });
        setIsAiTyping(false);
        addMessage('ai', "Fantastic! Here's a summary of your new company:");
        setTimeout(() => {
          const summary = `**${companyData.name}, ${reply}**\n- **State:** ${companyData.state}\n- **Type:** ${companyData.type.toUpperCase()}`;
          addMessage('ai', summary);

          // Add state fee information
          const stateFees = {
            'Delaware': { llc: 90, inc: 89, normalTime: '5-7 days', expediteFee: 50, expediteTime: '1-2 days' },
            'Wyoming': { llc: 100, inc: 100, normalTime: '3-5 days', expediteFee: 50, expediteTime: '1 day' },
            'Nevada': { llc: 425, inc: 425, normalTime: '7-10 days', expediteFee: 125, expediteTime: '2-3 days' },
            'New Mexico': { llc: 50, inc: 100, normalTime: '10-15 days', expediteFee: 25, expediteTime: '3-5 days' },
            'Florida': { llc: 125, inc: 70, normalTime: '7-10 days', expediteFee: 35, expediteTime: '2-3 days' },
            'Texas': { llc: 300, inc: 300, normalTime: '5-7 days', expediteFee: 25, expediteTime: '1-2 days' },
            'California': { llc: 70, inc: 100, normalTime: '5-7 days', expediteFee: 15, expediteTime: '1-2 days' },
            'New York': { llc: 200, inc: 125, normalTime: '5-7 days', expediteFee: 25, expediteTime: '1-2 days' },
            'Alabama': { llc: 100, inc: 100, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'Alaska': { llc: 250, inc: 250, normalTime: '10-15 days', expediteFee: 100, expediteTime: '3-5 days' },
            'Arizona': { llc: 50, inc: 60, normalTime: '5-7 days', expediteFee: 35, expediteTime: '1-2 days' },
            'Arkansas': { llc: 45, inc: 50, normalTime: '7-10 days', expediteFee: 25, expediteTime: '2-3 days' },
            'Colorado': { llc: 50, inc: 50, normalTime: '5-7 days', expediteFee: 25, expediteTime: '1-2 days' },
            'Connecticut': { llc: 120, inc: 250, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'Georgia': { llc: 100, inc: 100, normalTime: '5-7 days', expediteFee: 25, expediteTime: '1-2 days' },
            'Hawaii': { llc: 50, inc: 50, normalTime: '10-15 days', expediteFee: 25, expediteTime: '3-5 days' },
            'Idaho': { llc: 100, inc: 100, normalTime: '7-10 days', expediteFee: 20, expediteTime: '2-3 days' },
            'Illinois': { llc: 150, inc: 150, normalTime: '10-15 days', expediteFee: 100, expediteTime: '3-5 days' },
            'Indiana': { llc: 95, inc: 95, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'Iowa': { llc: 50, inc: 50, normalTime: '5-7 days', expediteFee: 25, expediteTime: '1-2 days' },
            'Kansas': { llc: 160, inc: 165, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'Kentucky': { llc: 40, inc: 40, normalTime: '7-10 days', expediteFee: 25, expediteTime: '2-3 days' },
            'Louisiana': { llc: 100, inc: 75, normalTime: '10-15 days', expediteFee: 50, expediteTime: '3-5 days' },
            'Maine': { llc: 175, inc: 145, normalTime: '10-15 days', expediteFee: 50, expediteTime: '3-5 days' },
            'Maryland': { llc: 100, inc: 120, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'Massachusetts': { llc: 500, inc: 275, normalTime: '10-15 days', expediteFee: 100, expediteTime: '3-5 days' },
            'Michigan': { llc: 50, inc: 60, normalTime: '7-10 days', expediteFee: 25, expediteTime: '2-3 days' },
            'Minnesota': { llc: 135, inc: 135, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'Mississippi': { llc: 50, inc: 50, normalTime: '7-10 days', expediteFee: 25, expediteTime: '2-3 days' },
            'Missouri': { llc: 50, inc: 58, normalTime: '5-7 days', expediteFee: 25, expediteTime: '1-2 days' },
            'Montana': { llc: 35, inc: 35, normalTime: '7-10 days', expediteFee: 25, expediteTime: '2-3 days' },
            'Nebraska': { llc: 100, inc: 60, normalTime: '7-10 days', expediteFee: 25, expediteTime: '2-3 days' },
            'Nevada': { llc: 100, inc: 100, normalTime: '7-10 days', expediteFee: 25, expediteTime: '2-3 days' },
            'New Jersey': { llc: 125, inc: 125, normalTime: '7-10 days', expediteFee: 25, expediteTime: '2-3 days' },
            'New York': { llc: 200, inc: 125, normalTime: '5-7 days', expediteFee: 25, expediteTime: '1-2 days' },
            'North Carolina': { llc: 125, inc: 125, normalTime: '5-7 days', expediteFee: 50, expediteTime: '1-2 days' },
            'North Dakota': { llc: 135, inc: 100, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'Ohio': { llc: 99, inc: 99, normalTime: '5-7 days', expediteFee: 100, expediteTime: '1-2 days' },
            'Oklahoma': { llc: 100, inc: 100, normalTime: '7-10 days', expediteFee: 25, expediteTime: '1-2 days' },
            'Oregon': { llc: 100, inc: 100, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'Pennsylvania': { llc: 125, inc: 125, normalTime: '7-10 days', expediteFee: 30, expediteTime: '2-3 days' },
            'Rhode Island': { llc: 150, inc: 230, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'South Carolina': { llc: 110, inc: 110, normalTime: '5-7 days', expediteFee: 25, expediteTime: '1-2 days' },
            'South Dakota': { llc: 150, inc: 150, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'Tennessee': { llc: 300, inc: 100, normalTime: '5-7 days', expediteFee: 25, expediteTime: '1-2 days' },
            'Utah': { llc: 54, inc: 54, normalTime: '5-7 days', expediteFee: 20, expediteTime: '1-2 days' },
            'Vermont': { llc: 125, inc: 125, normalTime: '7-10 days', expediteFee: 25, expediteTime: '2-3 days' },
            'Virginia': { llc: 100, inc: 50, normalTime: '7-10 days', expediteFee: 50, expediteTime: '2-3 days' },
            'Washington': { llc: 180, inc: 180, normalTime: '5-7 days', expediteFee: 50, expediteTime: '1-2 days' },
            'West Virginia': { llc: 100, inc: 50, normalTime: '7-10 days', expediteFee: 25, expediteTime: '2-3 days' },
            'Wisconsin': { llc: 130, inc: 100, normalTime: '5-7 days', expediteFee: 25, expediteTime: '1-2 days' }
          };

          const stateInfo = stateFees[companyData.state];
          if (stateInfo) {
            const feeType = companyData.type === 'llc' ? 'llc' : 'inc';
            const feeInfo = `**State Fee:** $${stateInfo[feeType]}\n**Normal Service Time:** ${stateInfo.normalTime}\n**Expedite Fee:** $${stateInfo.expediteFee}\n**Expedite Service Time:** ${stateInfo.expediteTime}`;
            addMessage('ai', feeInfo);
          }

          // Next, let's add the information for the company organizer. This is the person who is filing the documents.
          addMessage('ai', "Next, let's add the information for the company organizer. This is the person who is filing the documents.");
          setSuggestedReplies(['Add Organizer']);
          setStage('ORGANIZER_INTRO');
        }, 800);
        break;

      case 'ORGANIZER_INTRO':
        addMessage('user', userMessageText);
        setIsAiTyping(false);
        addMessage('ai', "Please fill out the organizer's information.");
        setCurrentPersonIndex(-1); // No specific index for a new organizer
        setIsEditingManager(false);
        setIsEditingOrganizer(true); // Flag to indicate organizer editing
        setCurrentPerson({
          firstName: '', middleName: '', lastName: '', streetAddress: '', suite: '',
          city: '', state: '', zipCode: '', country: 'USA'
        });
        setCurrentScreen('owner_form'); // Reuse owner_form for now
        setStage('ADDING_ORGANIZER'); // Transition to a waiting stage
        break;

      case 'ADDING_ORGANIZER':
        addMessage('user', userMessageText);
        setIsAiTyping(false);
        if (userMessageText === 'Add Another Owner') {
            setCurrentPersonIndex(-1); // New owner
            setIsEditingManager(false);
            setIsEditingOrganizer(false); // Ensure this is false
            setCurrentPerson({
              firstName: '', middleName: '', lastName: '', streetAddress: '', suite: '',
              city: '', state: '', zipCode: '', country: 'USA', ownershipPercent: '', isManager: false
            });
            addMessage('ai', 'Please provide the information for the new owner.');
            setCurrentScreen('owner_form');
        } else if (userMessageText === 'Continue to Managers') {
            setStage('MANAGERS_INTRO');
            addMessage('ai', "Great! Now let's set up the company managers. These are the people who will make day-to-day business decisions.");
            setSuggestedReplies(['Add Manager', 'Use Owners as Managers', 'Skip Managers']);
        }
        break;

      case 'OWNERS_INTRO':
        addMessage('user', userMessageText);
        setIsAiTyping(false);
        if (reply.startsWith('Add') && reply.endsWith('as Owner')) {
            addMessage('ai', `Great. Let's add ${organizer.firstName}. What percentage of the company do they own?`);
            setSuggestedReplies([]); // Clear for text input
            setStage('AWAITING_ORGANIZER_OWNERSHIP');

        } else if (reply === 'Add other owner') {
            setCurrentPersonIndex(-1); // New owner
            setIsEditingManager(false);
            addMessage('ai', 'Please provide the information for the new owner.');
            setCurrentScreen('owner_form');
            setStage('ADDING_ORGANIZER'); // Re-uses the form screen
        } else if (reply === 'Skip to Managers') {
            addMessage('ai', "Alright, skipping owners for now. Now, let's add the company managers. Who will manage the company?");
            setSuggestedReplies(['Add a Manager', 'Skip and Finalize']);
            setStage('ASK_ADD_MANAGER');
        }
        break;

      case 'AWAITING_ORGANIZER_OWNERSHIP':
        addMessage('user', userMessageText);
        const ownershipValue = parseFloat(userMessageText);

        const currentTotal = chatOwners.reduce((acc, owner) => acc + (parseFloat(owner.ownershipPercent) || 0), 0);
        const remainingOwnership = 100 - currentTotal;
        
        if (isNaN(ownershipValue) || ownershipValue <= 0 || ownershipValue > 100) {
            setIsAiTyping(false);
            addMessage('ai', "Please enter a valid ownership percentage between 0.01 and 100.");
            setSuggestedReplies([]);
            setStage('AWAITING_ORGANIZER_OWNERSHIP');
        } else if (ownershipValue > remainingOwnership) {
            setIsAiTyping(false);
            addMessage('ai', `The ownership percentage cannot exceed the remaining ${remainingOwnership}%.`);
            setSuggestedReplies([]);
            setStage('AWAITING_ORGANIZER_OWNERSHIP');
        } else {
            // Valid percentage
            const newOwner = { ...organizer, ownershipPercent: ownershipValue.toString(), isManager: false };
            const updatedOwners = [...chatOwners, newOwner];
            setChatOwners(updatedOwners);
            
            setIsAiTyping(false);
            addMessage('user', `**${newOwner.firstName} ${newOwner.lastName}**\n${newOwner.ownershipPercent}% Ownership`, {
                stage: 'OWNER_EDIT',
                isEditable: true,
                personIndex: updatedOwners.length - 1,
                isManager: false
            });

            const newTotal = currentTotal + ownershipValue;
            const ownerSummary = updatedOwners.map(o => `${o.firstName.toUpperCase()} ${o.lastName.toUpperCase()} : ${o.ownershipPercent}%`).join('  ');
            addMessage('ai', `**Current Owners:** ${ownerSummary}`);
            if (newTotal === 100) {
                addMessage('ai', "🎉 Total ownership is 100%! Let's move on to the managers.");
                setSuggestedReplies(['Continue to Managers']);
                setStage('OWNERS_COMPLETE');
            } else {
                addMessage('ai', `Total ownership is now ${newTotal}%. You can add more owners or continue.`);
                setSuggestedReplies(['Add Another Owner', 'Continue to Managers']);
                setStage('OWNERS_COMPLETE'); // Go to complete stage to decide next step
            }
        }
        break;

      case 'OWNERS_COMPLETE':
        addMessage('user', userMessageText);
        setIsAiTyping(false);
        if (userMessageText === 'Add Managers' || userMessageText === 'Continue to Managers') {
            setStage('MANAGERS_INTRO');
            const managerMessage = `Perfect! You have ${chatOwners.length} owner${chatOwners.length > 1 ? 's' : ''} with 100% ownership.\n\nNow let's add company managers. You can select an existing owner to also be a manager, add a new person, or skip this step entirely.`;
            addMessage('ai', managerMessage);
            
            const managerNames = new Set(chatManagers.map(m => `${m.firstName} ${m.lastName}`));
            const availableOwners = chatOwners.filter(o => !managerNames.has(`${o.firstName} ${o.lastName}`));
            const managerReplies = availableOwners.map(owner => `Add ${owner.firstName} ${owner.lastName} as Manager`);
            
            managerReplies.push('Add non-owner manager');
            managerReplies.push('Skip and Finalize');
            setSuggestedReplies(managerReplies);
        } else if (userMessageText === 'Add Another Owner') { // This reply text should ideally be consistent with 'Add other owner'
            addMessage('ai', "Let's add another owner to the company.");
            setCurrentPersonIndex(-1);
            setIsEditingManager(false);
            setIsEditingOrganizer(false);
            setCurrentPerson({
              firstName: '', middleName: '', lastName: '', streetAddress: '', suite: '',
              city: '', state: '', zipCode: '', country: 'USA', ownershipPercent: '', isManager: false
            });
            setCurrentScreen('owner_form');
        } else if (userMessageText.startsWith('Add ') && userMessageText.includes('as Owner')) {
            // User selected to add organizer as owner from OWNERS_COMPLETE (after 100% reached or not)
            addMessage('ai', `Great, let's add ${organizer.firstName} as an owner. Please specify their ownership percentage.`);
            addMessage('ai', "Please enter a number between 0.01 and 100.");
            setSuggestedReplies([]);
            setStage('AWAITING_ORGANIZER_OWNERSHIP');
        }
        break;

      case 'MANAGERS_INTRO': // New stage for manager introduction
        addMessage('user', userMessageText);
        setIsAiTyping(false);
        if (userMessageText.startsWith('Add ') && userMessageText.endsWith(' as Manager')) {
            const ownerNameToAdd = userMessageText.replace('Add ', '').replace(' as Manager', '').replace(' (Owner)', ''); // remove (Owner) if present
            const ownerData = chatOwners.find(o => `${o.firstName} ${o.lastName}` === ownerNameToAdd);
            if (ownerData) {
                if (companyData.type === 'inc' || companyData.type === 'scorp') {
                    setPersonToMakeManager(ownerData);
                    addMessage('ai', `Since this is a corporation, what title should ${ownerData.firstName} have?`);
                    const corporationTitles = ['President', 'Vice President', 'Secretary', 'Treasurer', 'CEO', 'CFO', 'COO'];
                    setSuggestedReplies(corporationTitles);
                    setStage('AWAITING_MANAGER_TITLE');
                } else { // It's an LLC
                    const newManager = { ...ownerData, isManager: true, titles: [] };
                    const updatedManagers = [...chatManagers, newManager]; // Correctly update state for immediate display
                    setChatManagers(updatedManagers);
                    addMessage('ai', `Done! I've added ${ownerData.firstName} ${ownerData.lastName} as a manager.`);
                    
                    const managersListText = updatedManagers.map((manager, index) => `${index + 1}. **${manager.firstName} ${manager.lastName}**`).join('\n');
                    addMessage('ai', `**Current Managers:**\n${managersListText}`);
                    setSuggestedReplies(['Add another manager', 'No more managers']);
                    setStage('MANAGERS_COMPLETE');
                }
            }
        } else if (userMessageText === 'Add non-owner manager') { // Corrected from 'Add other owner'
            setCurrentPersonIndex(-1); // New manager
            setIsEditingManager(true);
            setIsEditingOrganizer(false); // Ensure this is false
            addMessage('ai', 'Please provide the information for the new manager.');
            setCurrentPerson({
                firstName: '', middleName: '', lastName: '', streetAddress: '', suite: '',
                city: '', state: '', zipCode: '', country: 'USA', ownershipPercent: '0', isManager: true
            });
            setCurrentScreen('owner_form');
            setStage('ADDING_MANAGER'); // Corrected stage name
        } else if (userMessageText === 'Skip and Finalize') {
            addMessage('ai', "Got it, we'll skip managers for now.");
            addMessage('ai', "I'm ready to help you launch your company. Let's register it and get it opened!");
            const finalizeButtonText = user ? 'Launch Company' : 'Sign up & Launch Company';
            setSuggestedReplies([finalizeButtonText]);
            setStage('FINALIZE');
        } else {
            addMessage('ai', "Sorry, I didn't understand that. Please choose an option for managers.");

            const managerNames = new Set(chatManagers.map(m => `${m.firstName} ${m.lastName}`));
            const availableOwners = chatOwners.filter(o => !managerNames.has(`${o.firstName} ${o.lastName}`));
            const managerReplies = availableOwners.map(owner => `Add ${owner.firstName} ${owner.lastName} as Manager`);

            managerReplies.push('Add non-owner manager');
            managerReplies.push('Skip and Finalize');
            setSuggestedReplies(managerReplies);
            // Stay in MANAGERS_INTRO if invalid reply
        }
        break;

      case 'AWAITING_MANAGER_TITLE':
        addMessage('user', userMessageText);
        const selectedTitle = userMessageText;
        if (personToMakeManager && selectedTitle) {
            const newManager = { ...personToMakeManager, isManager: true, titles: [selectedTitle] };
            const updatedManagers = [...chatManagers, newManager];
            setChatManagers(updatedManagers);
            setPersonToMakeManager(null); // Clear the temporary state
            
            setIsAiTyping(false);
            addMessage('ai', `${personToMakeManager.firstName} ${personToMakeManager.lastName} has been added as ${selectedTitle}.`);
            
            const managersListText = updatedManagers.map((manager, index) => `${index + 1}. **${manager.firstName} ${manager.lastName}**${manager.titles && manager.titles.length > 0 ? ` (${manager.titles.join(', ')})` : ''}`).join('\n');
            addMessage('ai', `**Current Managers:**\n${managersListText}`);
            
            setSuggestedReplies(['Add another manager', 'No more managers']);
            setStage('MANAGERS_COMPLETE');
        } else {
            setIsAiTyping(false);
            addMessage('ai', "Sorry, something went wrong. Let's try adding a manager again.");
            // Revert to manager intro
            const managerNames = new Set(chatManagers.map(m => `${m.firstName} ${m.lastName}`));
            const availableOwners = chatOwners.filter(o => !managerNames.has(`${o.firstName} ${o.lastName}`));
            const managerReplies = availableOwners.map(owner => `Add ${owner.firstName} ${owner.lastName} as Manager`);
            managerReplies.push('Add non-owner manager', 'Skip and Finalize');
            setSuggestedReplies(managerReplies);
            setStage('MANAGERS_INTRO');
        }
        break;


      case 'ASK_ADD_MANAGER':
        addMessage('user', userMessageText);
        setIsAiTyping(false);
        if (userMessageText === 'Add a Manager') {
            addMessage('ai', "Let's add the manager's information.");
            setCurrentPersonIndex(-1);
            setIsEditingManager(true);
            setIsEditingOrganizer(false); // Ensure this is false
            setCurrentPerson({
                firstName: '', middleName: '', lastName: '', streetAddress: '', suite: '',
                city: '', state: '', zipCode: '', country: 'USA', ownershipPercent: '0', isManager: true
            });
            setCurrentScreen('owner_form');
            setStage('ADDING_MANAGER');
        } else { // 'Skip and Finalize'
            addMessage('ai', "Got it, we'll skip managers as well.");
            addMessage('ai', "I'm ready to help you launch your company. Let's register it and get it opened!");
            const finalizeButtonText = user ? 'Launch Company' : 'Sign up & Launch Company';
            setSuggestedReplies([finalizeButtonText]);
            setStage('FINALIZE');
        }
        break;

      case 'ADDING_MANAGER':
        // This stage is active while the form is open/being processed.
        // No direct `addMessage` or `setSuggestedReplies` here from user reply,
        // as the form submission handles the state transition.
        break;

      case 'MANAGERS_COMPLETE':
        addMessage('user', userMessageText); // From 'Add Another Manager' or 'Continue to Finalize'
        setIsAiTyping(false);
        if (userMessageText === 'Add another manager') {
          addMessage('ai', "Let's add another manager. You can select an existing owner or add a new person:");

          // Filter out owners who are already managers
          const managerNames = new Set(chatManagers.map(m => `${m.firstName} ${m.lastName}`));
          const availableOwners = chatOwners.filter(o => !managerNames.has(`${o.firstName} ${o.lastName}`));
          const ownerOptions = availableOwners.map((owner) => `Add ${owner.firstName} ${owner.lastName} as Manager`);

          const allManagerOptions = [...ownerOptions, 'Add non-owner manager', 'No more managers'];
          setSuggestedReplies(allManagerOptions);
          setStage('MANAGERS_INTRO'); // Go back to MANAGERS_INTRO for selection
        } else if (userMessageText === 'No more managers') {
          addMessage('ai', "Perfect! I'm ready to help you launch your company. Let's register it and get it opened!");
          const finalizeButtonText = user ? 'Launch Company' : 'Sign up & Launch Company';
          setSuggestedReplies([finalizeButtonText]);
          setStage('FINALIZE');
        } else {
            addMessage('ai', "Sorry, I didn't understand that. Please choose to add another manager or finalize.");
            setSuggestedReplies(['Add another manager', 'No more managers']);
            // Stay in MANAGERS_COMPLETE stage if reply wasn't understood
        }
        break;

      case 'FINALIZE':
        addMessage('user', userMessageText);
        handleSaveCompanyFromChat();
        break;
    }
  };

  const handleSaveCompanyFromChat = async () => {
      if (!organizer) {
          setIsAiTyping(false);
          addMessage('ai', "We're almost there! Before we can launch, you need to provide the organizer's information.");
          setSuggestedReplies(['Add Organizer']);
          setStage('ORGANIZER_INTRO');
          return;
      }

      setIsAiTyping(false);
      addMessage('ai', "Saving your company profile...");
      setIsAiTyping(true);
      try {
          const companyToSave = {
            company_name: companyData.name,
            legal_ending: companyData.ending,
            state: companyData.state,
            company_type: companyData.type,
            organizer: organizer,
            owners: chatOwners,
            managers: chatManagers, // Use chatManagers state
            status: 'draft'
          };

          if (user) {
              const newCompany = await Company.create(companyToSave);
              setIsAiTyping(false);
              addMessage('ai', "Done! I'm redirecting you to your new dashboard now.");
              setTimeout(() => {
                 window.location.href = createPageUrl('Dashboard') + '?launch_company=' + newCompany.id;
              }, 2000);
          } else {
              localStorage.setItem('pendingCompanyData', JSON.stringify(companyToSave));
              setIsAiTyping(false);
              addMessage('ai', "Profile saved! To continue, you'll need an account. I'm redirecting you to the login page now.");
              setTimeout(async () => {
                await UserEntity.loginWithRedirect(window.location.origin + createPageUrl('Dashboard') + '?create_and_launch=true');
              }, 2000);
          }

      } catch (error) {
          console.error("Error saving company:", error);
          setIsAiTyping(false);
          addMessage('ai', "Uh oh, something went wrong while saving. Please try again in a moment.");
      }
      setIsAiTyping(false);
  };

  // --- OLD FLOW LOGIC (FOR MODAL) ---
  const handleSaveCompany = async () => {
    try {
      const companyData = { company_name: companyName, legal_ending: legalEnding, state: selectedState, company_type: selectedType, owners: owners, managers: managers, status: 'draft' };
      if (companyToEdit) {
        await Company.update(companyToEdit.id, companyData);
        onSaveComplete();
      } else {
        if (user) {
          const newCompany = await Company.create(companyData);
          window.location.href = createPageUrl('Dashboard') + '?launch_company=' + newCompany.id;
        } else {
          localStorage.setItem('pendingCompanyData', JSON.stringify(companyData));
          await UserEntity.loginWithRedirect(window.location.origin + createPageUrl('Dashboard') + '?create_and_launch=true');
        }
      }
    } catch (error) { console.error('Error saving company:', error); }
  };
  const getFlagUrl = (stateName) => {
    const stateCode={'Alabama':'AL','Alaska':'AK','Arizona':'AZ','Arkansas':'AR','California':'CA','Colorado':'CO','Connecticut':'CT','Delaware':'DE','Florida':'FL','Georgia':'GA','Hawaii':'HI','Idaho':'ID','Illinois':'IL','Indiana':'IN','Iowa':'IA','Kansas':'KS','Kentucky':'KY','Louisiana':'LA','Maine':'ME','Maryland':'MD','Massachusetts':'MA','Michigan':'MI','Minnesota':'MN','Mississippi':'MS','Missouri':'MO','Montana':'MT','Nebraska':'NE','Nevada':'NV','New Hampshire':'NH','New Jersey':'NJ','New Mexico':'NM','New York':'NY','North Carolina':'NC','North Dakota':'ND','Ohio':'OH','Oklahoma':'OK','Oregon':'OR','Pennsylvania':'PA','Rhode Island':'RI','South Carolina':'SC','South Dakota':'SD','Tennessee':'TX','Texas':'TX','Utah':'UT','Vermont':'VT','Virginia':'VA','Washington':'WA','West Virginia':'WV','Wisconsin':'WI','Wyoming':'WY'};
    const code=stateCode[stateName];return code?`https://flagsapi.com/US-${code}/flat/64.png`:null;
  };
  const handleSaveOwner = (ownerData) => {
    let updatedOwners;
    if (currentOwnerIndex > -1) {
      updatedOwners = [...owners];
      updatedOwners[currentOwnerIndex] = ownerData;
    } else {
      updatedOwners = [...owners, ownerData];
    }
    setOwners(updatedOwners);
    setCurrentScreen('owners_list');
    setCurrentOwnerIndex(-1);
  };
  const handleEditOwner = (index) => { setCurrentPerson({ ...owners[index], isManager: false }); setCurrentOwnerIndex(index); setCurrentScreen('owner_form'); };
  const handleAddNewOwner = () => { setCurrentPerson({ firstName: '', middleName: '', lastName: '', streetAddress: '', suite: '', city: '', state: '', zipCode: '', country: 'USA', ownershipPercent: '', isManager: false }); setCurrentOwnerIndex(-1); setCurrentScreen('owner_form'); };
  const handleDeleteOwner = (index) => { const updatedOwners = owners.filter((_, i) => i !== index); setOwners(updatedOwners); };
  const navigateTo = (screen) => { setPreviousScreen(currentScreen); setCurrentScreen(screen); setIsMenuOpen(false); };

  const renderOldContent = () => {
    if (isMenuOpen) return <MenuScreen onBack={() => setIsMenuOpen(false)} onNavigate={navigateTo} onUser={user} onLogout={() => UserEntity.logout().then(() => window.location.reload())} />;
    switch (currentScreen) {
      case 'welcome': return <WelcomeScreen onStart={() => setCurrentScreen('states')} />;
      // Used the US_STATES constant for consistency
      // The StateSelector component now uses the new handleStateInputChange and current stateInput for search
      case 'states': return <StateSelector onBack={() => setCurrentScreen('welcome')} onStateSelect={(state) => { setSelectedState(state); setCurrentScreen('types'); }} onAIAdvisor={() => setCurrentScreen('state_advisor')} selectedState={selectedState} stateSearch={stateSearch} onSearchChange={handleStateInputChange} usStates={US_STATES} />;
      case 'types': return <TypeSelector onBack={() => setCurrentScreen('states')} onTypeSelect={(type) => { setSelectedType(type); setCurrentScreen('name'); }} onAIAdvisor={() => setCurrentScreen('type_advisor')} selectedState={selectedState} selectedType={selectedType} companyTypes={COMPANY_TYPES} />;
      case 'name': return <NameScreen onBack={() => setCurrentScreen('types')} onSubmit={() => setCurrentScreen('owners_list')} selectedState={selectedState} selectedType={selectedType} companyName={companyName} onNameChange={setCompanyName} legalEnding={legalEnding} onLegalEndingChange={setLegalEnding} llcEndings={LLC_ENDINGS} corpEndings={CORP_ENDINGS} />;
      case 'owners_list': return <OwnersList onBack={() => setCurrentScreen('name')} onContinue={() => setCurrentScreen('managers_list')} owners={owners} onEditOwner={handleEditOwner} onDeleteOwner={handleDeleteOwner} onAddNewOwner={handleAddNewOwner} companyName={companyName} />;
      // Removed selectedType and officerTitles props
      case 'owner_form': return <OwnerForm onBack={() => setCurrentScreen('owners_list')} onSave={handleSaveOwner} ownerData={currentPerson} isManager={currentPerson.isManager || false} />;
      case 'managers_list': return <ManagersList onBack={() => setCurrentScreen('owners_list')} onContinue={handleSaveCompany} managers={managers} companyName={companyName} user={user} />;
      case 'state_advisor': return <StateAdvisorFlow onBack={() => setCurrentScreen('welcome')} onComplete={(state) => {setSelectedState(state); setCurrentScreen('types');}} helpFlowStep={helpFlowStep} setHelpFlowStep={setHelpFlowStep} helpFlowData={helpFlowData} onDataChange={setHelpFlowData} onRunAnalysis={handleStateAdvisorAnalysis} isLoading={isStateAdvisorLoading} loadingMessageIndex={stateAdvisorLoadingMessageIndex} analysisResult={stateAdvisorResult} handleStartOver={handleStateAdvisorStartOver} />;
      case 'type_advisor': return <TypeAdvisorFlow onBack={() => setCurrentScreen('types')} onComplete={({ state, type }) => { setSelectedState(state); setSelectedType(type); setCurrentScreen('name'); }} state={selectedState} existingData={stateAdvisorResult ? helpFlowData : null} />;
      default: return <InfoScreen currentScreen={currentScreen} onBack={() => setCurrentScreen(previousScreen)} />;
    }
  };

  // --- RENDER LOGIC ---
  if (isModal) {
    return (
      <div className="relative w-full h-full">
        <Button variant="ghost" size="icon" onClick={onClose} className="absolute top-0 right-0 z-[60] bg-white/20 backdrop-blur-sm border border-slate-200/20 hover:bg-white/30 rounded-full h-8 w-8 text-white hover:text-white transition-all">
          <X className="h-5 w-5" />
        </Button>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full h-full bg-[var(--card)] rounded-2xl flex flex-col overflow-hidden">
          <div className="relative w-full text-center pt-8 pb-3 border-b border-[var(--border)] flex-shrink-0">
            <div className="flex items-center justify-center gap-2">
              <Logo className="w-5 h-5 text-[var(--text-primary)]" />
              <span className="text-base font-bold text-[var(--text-primary)]">frinc.ai Launch Agent</span>
            </div>
          </div>
          <div className="flex-1 flex flex-col min-h-0">
            <AnimatePresence mode="wait">{renderOldContent()}</AnimatePresence>
          </div>
        </motion.div>
      </div>
    );
  }

  // --- NEW CHAT INTERFACE RENDER ---
  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden bg-[var(--background-alt)] text-[var(--text-primary)]">
      <style>{`
        :root { --background: hsl(210 40% 98%); --foreground: hsl(222.2 47.4% 11.2%); --card: hsl(210 40% 98%); --card-foreground: hsl(210 40% 96.1%); --popover: hsl(210 40% 98%); --popover-foreground: hsl(222.2 47.4% 11.2%); --primary: hsl(221.2 83.2% 53.3%); --primary-foreground: hsl(210 40% 98%); --secondary: hsl(210 40% 96.1%); --secondary-foreground: hsl(222.2 47.4% 11.2%); --muted: hsl(210 40% 96.1%); --muted-foreground: hsl(215.4 16.3% 35%); --accent: hsl(210 40% 88%); --accent-foreground: hsl(222.2 47.4% 11.2%); --destructive: hsl(0 84.2% 60.2%); --destructive-foreground: hsl(210 40% 98%); --border: hsl(214.3 31.8% 91.4%); --input: hsl(214.3 31.8% 91.4%); --ring: hsl(222.2 84% 4.9%); --radius: 0.75rem; --background-alt: hsl(210 40% 96.1%); --text-primary: hsl(222.2 47.4% 11.2%); --text-secondary: hsl(215.4 16.3% 35%); }
        .theme-dark { --background: hsl(222.2 84% 4.9%); --foreground: hsl(210 40% 98%); --card: hsl(222.2 84% 4.9%); --card-foreground: hsl(222.2 84% 4.9%); --popover: hsl(222.2 84% 4.9%); --popover-foreground: hsl(210 40% 98%); --primary: hsl(210 40% 98%); --primary-foreground: hsl(222.2 47.4% 11.2%); --secondary: hsl(217.2 32.6% 17.5%); --secondary-foreground: hsl(210 40% 98%); --muted: hsl(217.2 32.6% 17.5%); --muted-foreground: hsl(215 20.2% 65.1%); --accent: hsl(217.2 32.6% 22.5%); --accent-foreground: hsl(210 40% 98%); --destructive: hsl(0 62.8% 30.6%); --destructive-foreground: hsl(210 40% 98%); --border: hsl(217.2 32.6% 25%); --input: hsl(217.2 32.6% 17.5%); --ring: hsl(212.7 26.8% 83.9%); --background-alt: hsl(222.2 84% 4.9%); --text-primary: hsl(210 40% 98%); --text-secondary: hsl(215 20.2% 65.1%); }
        .theme-fun { --background: hsl(40 50% 96%); --foreground: hsl(25 45% 25%); --card: hsl(40 30% 98%); --card-foreground: hsl(40 50% 93%); --popover: hsl(40 50% 93%); --popover-foreground: hsl(25 45% 25%); --primary: hsl(24 98% 52%); --primary-foreground: hsl(0 0% 100%); --secondary: hsl(185 50% 90%); --secondary-foreground: hsl(185 40% 30%); --muted: hsl(185 50% 90%); --muted-foreground: hsl(25 35% 45%); --accent: hsl(185 55% 85%); --accent-foreground: hsl(185 40% 30%); --destructive: hsl(0 80% 60%); --destructive-foreground: hsl(0 0% 100%); --border: hsl(30 20% 85%); --input: hsl(30 20% 85%); --ring: hsl(24 98% 52%); --radius: 1.2rem; --background-alt: hsl(40 50% 93%); --text-primary: hsl(25 45% 25%); --text-secondary: hsl(25 35% 45%); }
        .theme-ai { --background: hsl(215 30% 10%); --foreground: hsl(195 100% 95%); --card: hsl(215 30% 12%); --card-foreground: hsl(215 30% 15%); --popover: hsl(215 30% 10%); --popover-foreground: hsl(195 100% 95%); --primary: hsl(180 100% 50%); --primary-foreground: hsl(215 30% 5%); --secondary: hsl(215 30% 20%); --secondary-foreground: hsl(195 100% 95%); --muted: hsl(215 30% 20%); --muted-foreground: hsl(195 30% 70%); --accent: hsl(180 100% 50% / 0.2); --accent-foreground: hsl(195 100% 95%); --destructive: hsl(0 80% 60%); --destructive-foreground: hsl(195 100% 95%); --border: hsl(180 100% 50% / 0.3); --input: hsl(215 30% 20%); --ring: hsl(180 100% 50%); --radius: 0.5rem; --background-alt: hsl(215 30% 8%); --text-primary: hsl(195 100% 95%); --text-secondary: hsl(195 30% 70%); }
        .theme-bling { --background: hsl(45 75% 97%); --background-alt: hsl(45 75% 95%); --text-primary: hsl(35 65% 25%); --text-secondary: hsl(35 45% 45%); --primary: hsl(45 100% 51%); --primary-foreground: hsl(45 85% 10%); --secondary: hsl(45 85% 92%); --secondary-foreground: hsl(45 45% 25%); --muted: hsl(45 85% 95%); --muted-foreground: hsl(35 35% 50%); --popover: hsl(0 0% 100%); --popover-foreground: hsl(35 65% 25%); --accent: hsl(45 85% 90%); --accent-foreground: hsl(45 85% 10%); --destructive: hsl(0 85% 60%); --destructive-foreground: hsl(0 0% 100%); --border: hsl(45 60% 85%); --input: hsl(45 85% 90%); --ring: hsl(45 100% 51%); --radius: 1rem; }
      `}</style>

      {/* Background Grid - Themed for each mode */}
      <div className="absolute inset-0 opacity-30 pointer-events-none z-0">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="homepageGrid" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
              <path d="M 80 0 L 0 0 0 80" fill="none" stroke="var(--primary)" strokeWidth="1" opacity="0.3"/>
              <g transform="translate(40, 40)" stroke="var(--primary)" strokeWidth="1.5" fill="none" opacity="0.5">
                  <circle cx="7" cy="8" r="3" />
                  <circle cx="7" cy="8" r="1.5" fill="currentColor" />
                  <circle cx="17" cy="8" r="3" />
                  <circle cx="17" cy="8" r="1.5" fill="currentColor" />
                  <path d="M 8 15 Q 12 19 16 15" strokeLinecap="round"/>
              </g>
            </pattern>
            {/* Fun theme special pattern */}
            <pattern id="funPattern" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
              <path d="M 80 0 L 0 0 0 80" fill="none" stroke="hsl(24 98% 52%)" strokeWidth="1" opacity="0.3"/>
              <g transform="translate(40, 40)" stroke="hsl(24 98% 52%)" strokeWidth="1.5" fill="none" opacity="0.5">
                  <circle cx="7" cy="8" r="3" />
                  <circle cx="7" cy="8" r="1.5" fill="currentColor" />
                  <circle cx="17" cy="8" r="3" />
                  <circle cx="17" cy="8" r="1.5" fill="currentColor" />
                  <path d="M 8 15 Q 12 19 16 15" strokeLinecap="round"/>
              </g>
            </pattern>
            {/* AI theme circuit pattern */}
            <pattern id="aiPattern" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
              <path d="M 80 0 L 0 0 0 80" fill="none" stroke="hsl(180 100% 50%)" strokeWidth="0.5" opacity="0.4"/>
              <path d="M 40 0 L 40 80 M 0 40 L 80 40" fill="none" stroke="hsl(180 100% 50%)" strokeWidth="0.3" opacity="0.3"/>
              <g transform="translate(40, 40)" stroke="hsl(180 100% 50%)" strokeWidth="1" fill="none" opacity="0.4">
                  <circle cx="7" cy="8" r="3" />
                  <circle cx="7" cy="8" r="1.5" fill="currentColor" />
                  <circle cx="17" cy="8" r="3" />
                  <circle cx="17" cy="8" r="1.5" fill="currentColor" />
                  <path d="M 8 15 Q 12 19 16 15" strokeLinecap="round"/>
              </g>
              <rect x="37" y="37" width="6" height="6" fill="none" stroke="hsl(180 100% 50%)" strokeWidth="0.5" opacity="0.4" />
            </pattern>
            {/* Bling theme dollar pattern */}
            <pattern id="blingPattern" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <path d="M 100 0 L 0 0 0 100" fill="none" stroke="hsl(43 100% 45%)" strokeWidth="1.2" opacity="0.6"/>
              <g transform="translate(50, 50)" stroke="hsl(43 100% 45%)" strokeWidth="1" fill="none" opacity="0.6">
                  <circle cx="7" cy="8" r="3" />
                  <circle cx="7" cy="8" r="1.5" fill="currentColor" />
                  <circle cx="17" cy="8" r="3" />
                  <circle cx="17" cy="8" r="1.5" fill="currentColor" />
                  <path d="M 8 15 Q 12 19 16 15" strokeLinecap="round"/>
              </g>
              <text x="25" y="35" fontFamily="Arial" fontSize="14" fill="hsl(43 100% 45%)" opacity="0.4" fontWeight="bold">$</text>
              <text x="75" y="85" fontFamily="Arial" fontSize="10" fill="hsl(43 100% 45%)" opacity="0.3" fontWeight="bold">$</text>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#homepageGrid)" className="theme-light theme-dark" />
          <rect width="100%" height="100%" fill="url(#funPattern)" className="theme-fun-only" style={{display: 'none'}} />
          <rect width="100%" height="100%" fill="url(#aiPattern)" className="theme-ai-only" style={{display: 'none'}} />
          <rect width="100%" height="100%" fill="url(#blingPattern)" className="theme-bling-only" style={{display: 'none'}} />
        </svg>
      </div>

      {/* Theme-specific additional styles */}
      <style>{`
        .theme-fun .theme-fun-only { display: block !important; }
        .theme-fun #homepageGrid { display: none; }

        .theme-ai .theme-ai-only { display: block !important; }
        .theme-ai #homepageGrid { display: none; }

        .theme-bling .theme-bling-only { display: block !important; }
        .theme-bling #homepageGrid { display: none; }
      `}</style>

      <div className="w-full max-w-2xl h-[85vh] flex flex-col bg-[var(--background)] shadow-2xl border border-[var(--border)] relative overflow-hidden z-10">
        <AnimatePresence>
            {isMenuOpen && (
                <motion.div
                    key="menu-screen-overlay"
                    className="absolute inset-0 z-30"
                    initial={{ x: '-100%' }}
                    animate={{ x: 0 }}
                    exit={{ x: '-100%' }}
                    transition={{ duration: 0.3, ease: 'easeInOut' }}
                >
                    <MenuScreen
                        onBack={() => setIsMenuOpen(false)}
                        onNavigate={navigateTo}
                        user={user}
                        onLogout={() => UserEntity.logout().then(() => window.location.reload())}
                    />
                </motion.div>
            )}
        </AnimatePresence>

        <AnimatePresence>
            {['about', 'support', 'legal'].includes(currentScreen) && !isModal && (
                 <motion.div
                    key="info-screen-overlay"
                    className="absolute inset-0 z-20"
                    initial={{ x: '100%' }}
                    animate={{ x: 0 }}
                    exit={{ x: '100%' }}
                    transition={{ duration: 0.3, ease: 'easeInOut' }}
                 >
                    <InfoScreen
                        currentScreen={currentScreen}
                        onBack={() => {
                            setPreviousScreen(currentScreen);
                            setCurrentScreen('welcome');
                        }}
                    />
                </motion.div>
            )}
            {/* New: State Advisor Flow Overlay for Chat UI */}
            {currentScreen === 'state_advisor' && !isModal && (
                <motion.div
                    key="state-advisor-overlay"
                    className="absolute inset-0 z-20"
                    initial={{ y: '100%' }} // Animate from bottom for a modal-like feel over chat
                    animate={{ y: 0 }}
                    exit={{ y: '100%' }}
                    transition={{ duration: 0.3, ease: 'easeInOut' }}
                >
                    <StateAdvisorFlow
                        onBack={() => {
                            setCurrentScreen('welcome'); // Close advisor, return to chat
                            addMessage('ai', "No problem. How would you like to choose your state?");
                            setSuggestedReplies(['Select from a list', 'Use AI State Advisor']);
                            setStage('CHOOSE_STATE_METHOD'); // Reset chat flow
                        }}
                        onComplete={(state) => {
                            // Simulate user input for the chat flow
                            addMessage('user', `I select ${state}`);
                            setSuggestedReplies([]); // Clear suggested replies immediately
                            setIsAiTyping(true); // AI starts typing

                            setTimeout(() => {
                                setCompanyData(prev => ({ ...prev, state: state })); // Update company data for chat
                                setCurrentScreen('welcome'); // Close advisor, return to chat
                                addMessage('ai', `Excellent choice! ${state} is a great state for your business based on our AI analysis.`);
                                addMessage('ai', `Now, let's select the type of company you want to form in ${state}.`);
                                setSuggestedReplies([...COMPANY_TYPES.map(t => t.name), 'AI Type Advisor']);
                                setStage('TYPE_SELECT'); // Continue chat flow
                                setIsAiTyping(false); // AI finishes typing
                            }, 1000); // Simulate AI thinking time
                        }}
                        helpFlowStep={helpFlowStep}
                        setHelpFlowStep={setHelpFlowStep}
                        helpFlowData={helpFlowData}
                        onDataChange={setHelpFlowData}
                        onRunAnalysis={handleStateAdvisorAnalysis}
                        isLoading={isStateAdvisorLoading}
                        analysisResult={stateAdvisorResult}
                        handleStartOver={handleStateAdvisorStartOver}
                    />
                </motion.div>
            )}
            {/* New: Type Advisor Flow Overlay for Chat UI */}
            {currentScreen === 'type_advisor' && !isModal && (
                <motion.div
                    key="type-advisor-overlay"
                    className="absolute inset-0 z-20"
                    initial={{ y: '100%' }}
                    animate={{ y: 0 }}
                    exit={{ y: '100%' }}
                    transition={{ duration: 0.3, ease: 'easeInOut' }}
                >
                    <TypeAdvisorFlow
                        onBack={() => {
                            setCurrentScreen('welcome');
                            addMessage('ai', "No problem. What type of company would you like to form?");
                            setSuggestedReplies([...COMPANY_TYPES.map(t => t.name), 'AI Type Advisor']);
                            setStage('TYPE_SELECT');
                        }}
                        onComplete={({ state, type }) => {
                            setCompanyData(prev => ({ ...prev, state: state, type: type }));
                            setCurrentScreen('welcome');
                            addMessage('user', `I select ${COMPANY_TYPES.find(t => t.id === type)?.name} in ${state}`); // Show user's selection
                            addMessage('ai', `Perfect choice! A ${COMPANY_TYPES.find(t => t.id === type)?.name} in ${state} is ideal for your business based on our AI analysis.`);
                            addMessage('ai', `Now, let's choose a name for your new company. What would you like to call it?`);
                            addMessage('ai', "Just enter the business name without any legal ending (like LLC or Inc) - I'll ask you to choose that in the next step.");
                            setSuggestedReplies([]); // Clear suggestions to indicate text input needed
                            setStage('NAME_INPUT_PENDING');
                        }}
                        state={companyData.state}
                        existingData={stateAdvisorResult ? helpFlowData : null}
                    />
                </motion.div>
            )}
            {/* Owner/Manager Form Overlay for Chat UI */}
            {currentScreen === 'owner_form' && !isModal && (
                <motion.div
                    key="owner-form-overlay"
                    className="absolute inset-0 z-20"
                    initial={{ y: '100%' }}
                    animate={{ y: 0 }}
                    exit={{ y: '100%' }}
                    transition={{ duration: 0.3, ease: 'easeInOut' }}
                >
                    <OwnerForm
                        onBack={() => {
                            setCurrentScreen('welcome'); // Close the form

                            // Based on the current stage, provide the correct prompt to re-initiate the action.
                            if (isEditingOrganizer) {
                                addMessage('ai', "Okay, you can add the organizer information when you're ready. This information is required to file your company documents.");
                                setSuggestedReplies(['Add Organizer']);
                                setStage('ORGANIZER_INTRO');
                            } else if (stage === 'OWNERS_INTRO' || stage === 'ADDING_ORGANIZER' || stage === 'AWAITING_ORGANIZER_OWNERSHIP' || stage === 'OWNERS_COMPLETE') { // Added AWAITING_ORGANIZER_OWNERSHIP & OWNERS_COMPLETE for robustness
                                addMessage('ai', "No problem. Let's add the company owners when you're ready.");
                                const replies = ['Add other owner', 'Skip to Managers'];
                                if (organizer && !chatOwners.some(o => o.firstName === organizer.firstName && o.lastName === organizer.lastName)) {
                                    replies.unshift(`Add ${organizer.firstName} ${organizer.lastName} as Owner`);
                                }
                                setSuggestedReplies(replies);
                                setStage('OWNERS_INTRO'); // Reset stage to allow re-entry
                            } else if (stage === 'MANAGERS_COMPLETE' || stage === 'MANAGERS_INTRO' || stage === 'AWAITING_MANAGER_TITLE' || stage === 'ADDING_MANAGER' || stage === 'ASK_ADD_MANAGER') { // Include MANAGERS_INTRO and AWAITING_MANAGER_TITLE
                                addMessage('ai', "No problem. Let's add the company managers when you're ready.");
                                const managerNames = new Set(chatManagers.map(m => `${m.firstName} ${m.lastName}`));
                                const availableOwners = chatOwners.filter(o => !managerNames.has(`${o.firstName} ${o.lastName}`));
                                const managerReplies = availableOwners.map(owner => `Add ${owner.firstName} ${owner.lastName} as Manager`);
                                managerReplies.push('Add non-owner manager');
                                managerReplies.push('Skip and Finalize');
                                setSuggestedReplies(managerReplies);
                                setStage('MANAGERS_INTRO'); // Revert to manager selection/intro
                            }
                            setCurrentPersonIndex(-1); // Reset index
                            setIsEditingManager(false); // Reset flag
                            setIsEditingOrganizer(false); // Reset flag
                        }}
                        onSave={(personData) => { // Renamed from ownerData for clarity
                            setIsAiTyping(true); // AI starts "processing"

                            if (isEditingOrganizer) {
                                setOrganizer(personData);
                                setCurrentScreen('welcome');
                                addMessage('user', `**${personData.firstName} ${personData.lastName}**\nOrganizer`);

                                setTimeout(() => {
                                    addMessage('ai', "Great, organizer information saved. Now let's add the company owners. Who owns this company?");
                                    const replies = [`Add ${personData.firstName} ${personData.lastName} as Owner`, 'Add other owner', 'Skip to Managers'];
                                    setSuggestedReplies(replies);
                                    setStage('OWNERS_INTRO');
                                    setIsAiTyping(false);
                                    setIsEditingOrganizer(false);
                                }, 800);
                                return;
                            }

                            let updatedList;
                            let savedPersonIndex;
                            const isManagerSave = isEditingManager; // Use the state variable

                            if (isManagerSave) {
                                if (currentPersonIndex > -1) {
                                    updatedList = [...chatManagers];
                                    updatedList[currentPersonIndex] = personData;
                                    savedPersonIndex = currentPersonIndex;
                                } else {
                                    updatedList = [...chatManagers, personData];
                                    savedPersonIndex = updatedList.length - 1;
                                }
                                setChatManagers(updatedList);
                            } else { // Saving an owner
                                // Check ownership percentage validation before saving
                                const newOwnershipPercent = parseFloat(personData.ownershipPercent) || 0;
                                
                                // Calculate total ownership excluding the current owner being edited
                                let otherOwnersTotal = 0;
                                if (currentPersonIndex > -1) {
                                    // Editing existing owner - exclude their current percentage
                                    otherOwnersTotal = chatOwners.reduce((acc, owner, index) => {
                                        if (index !== currentPersonIndex) {
                                            return acc + (parseFloat(owner.ownershipPercent) || 0);
                                        }
                                        return acc;
                                    }, 0);
                                } else {
                                    // Adding new owner - include all existing owners
                                    otherOwnersTotal = chatOwners.reduce((acc, owner) => acc + (parseFloat(owner.ownershipPercent) || 0), 0);
                                }
                                
                                const totalWithNewOwner = otherOwnersTotal + newOwnershipPercent;
                                const maxAllowed = 100 - otherOwnersTotal;
                                
                                if (totalWithNewOwner > 100) {
                                    addMessage('ai', `This owner cannot own more than ${maxAllowed}%. Please adjust their ownership percentage.`);
                                    setIsAiTyping(false);
                                    setCurrentScreen('welcome'); // Close the form, user needs to re-edit
                                    // Optionally, could set specific suggested replies here if the form itself doesn't auto-correct
                                    return; // Don't save the owner
                                }

                                if (currentPersonIndex > -1) {
                                    updatedList = [...chatOwners];
                                    updatedList[currentPersonIndex] = personData;
                                    savedPersonIndex = currentPersonIndex;
                                } else {
                                    updatedList = [...chatOwners, personData];
                                    savedPersonIndex = updatedList.length - 1;
                                }
                                setChatOwners(updatedList);
                            }

                            setCurrentScreen('welcome'); // Close owner form

                            // Add user message for the saved person
                            const userMessageText = `**${personData.firstName} ${personData.lastName}**\n${isManagerSave ? 'Manager' : personData.ownershipPercent + '% Ownership'}`;
                            addMessage('user', userMessageText, {
                                stage: isManagerSave ? 'MANAGER_EDIT' : 'OWNER_EDIT', // New stage for manager editing
                                isEditable: true,
                                personIndex: savedPersonIndex, // Use personIndex
                                isManager: isManagerSave // Pass isManager flag
                            });

                            setTimeout(() => {
                                const totalOwnership = (isManagerSave ? chatOwners : updatedList).reduce((acc, owner) => acc + (parseFloat(owner.ownershipPercent) || 0), 0);
                                const ownerSummary = (isManagerSave ? chatOwners : updatedList).map(o => `${o.firstName.toUpperCase()} ${o.lastName.toUpperCase()} : ${o.ownershipPercent}%`).join('  ');

                                if (!isManagerSave) { // Logic for owner save
                                    addMessage('ai', `**Current Owners:** ${ownerSummary}`);
                                    
                                    if (totalOwnership === 100) {
                                        addMessage('ai', "🎉 Total ownership is 100%! Let's move on to the managers.");
                                        setSuggestedReplies(['Continue to Managers']);
                                        setStage('OWNERS_COMPLETE');
                                    } else {
                                        addMessage('ai', `Total ownership is now ${totalOwnership}%. You can add more owners or continue to managers.`);
                                        setSuggestedReplies(['Add Another Owner', 'Continue to Managers']);
                                        setStage('OWNERS_COMPLETE'); // Set to OWNERS_COMPLETE for flow consistency
                                    }
                                } else { // Logic for manager save
                                    const managersListText = updatedList.map((manager, index) => `${index + 1}. **${manager.firstName} ${manager.lastName}**${manager.titles && manager.titles.length > 0 ? ` (${manager.titles.join(', ')})` : ''}`).join('\n');
                                    addMessage('ai', `Manager information saved.\n**Current Managers:**\n${managersListText}`);
                                    setSuggestedReplies(['Add another manager', 'No more managers']);
                                    setStage('MANAGERS_COMPLETE'); // Ensure stage is set after manager save
                                }
                                setIsAiTyping(false); // AI finishes "processing"
                                setCurrentPersonIndex(-1); // Reset
                                setIsEditingManager(false); // Reset
                                setIsEditingOrganizer(false);
                            }, 800);
                        }}
                        ownerData={currentPerson}
                        isManager={isEditingManager} // Pass this prop to OwnerForm
                        isOrganizer={isEditingOrganizer}
                    />
                </motion.div>
            )}
        </AnimatePresence>

        <div className="flex-shrink-0 p-4 border-b border-[var(--border)] flex items-center justify-between">
            <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(true)} className="text-[var(--text-secondary)] hover:bg-[var(--secondary)] rounded-full h-10 w-10">
                <Menu className="h-5 w-5" />
            </Button>
            <h2
              onClick={startConversation}
              className="text-lg font-bold flex items-center justify-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
              role="button"
              aria-label="Restart Conversation"
            >
                <Logo className="w-6 h-6 text-[var(--primary)]" />
                <span className="text-[var(--primary)]">frinc.ai</span>
            </h2>
            {/* Theme selector moved here */}
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="text-[var(--text-secondary)] hover:bg-[var(--secondary)] rounded-full h-10 px-3 flex items-center gap-2">
                        <Palette className="h-5 w-5" />
                        <span className="capitalize text-sm font-medium">{theme}</span>
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-[var(--popover)] border-[var(--border)] text-[var(--popover-foreground)]">
                    <DropdownMenuItem onClick={() => setTheme('fun')} className="focus:bg-[var(--accent)]"><Smile className="mr-2 h-4 w-4" /> Fun</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setTheme('light')} className="focus:bg-[var(--accent)]"><Sun className="mr-2 h-4 w-4" /> Light</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setTheme('dark')} className="focus:bg-[var(--accent)]"><Moon className="mr-2 h-4 w-4" /> Dark</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setTheme('ai')} className="focus:bg-[var(--accent)]"><Bot className="mr-2 h-4 w-4" /> AI</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setTheme('bling')} className="focus:bg-[var(--accent)]"><Sparkles className="mr-2 h-4 w-4" /> Bling</DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
        </div>
        <div ref={chatContainerRef} className="flex-1 p-4 overflow-y-auto custom-scrollbar">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center p-4 -mt-8">
                <motion.div
                  key="hero-title"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, ease: 'easeOut' }}
                >
                    <h1 className="text-3xl font-bold text-[var(--text-primary)] tracking-tight leading-tight">
                        Open your U.S. company
                    </h1>
                    <h1 className="text-3xl font-bold text-[var(--text-primary)] tracking-tight leading-tight">
                        <button onClick={() => handleReply("Let's start!")} className="underline text-[var(--text-primary)] hover:opacity-80 transition-opacity">free & fast</button> with <span className="text-[var(--primary)]">frinc.ai</span>
                    </h1>
                    <h2 className="text-2xl font-normal text-[var(--text-secondary)] mt-4 min-h-[2rem]">
                        {typedSubtitle}
                        {isSubtitleTyping && <span className="inline-block w-0.5 h-6 bg-[var(--text-secondary)] animate-pulse ml-1 align-bottom"></span>}
                    </h2>
                </motion.div>
          </div>
          )}
            <AnimatePresence>
                {messages.map((msg, index) => (
                    <ChatMessage key={index} message={msg} onEdit={handleEdit} user={user} />
                ))}
            </AnimatePresence>
            {isAiTyping && (
                <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className="flex items-end gap-2 my-2 justify-start"
                >
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[var(--primary)] text-[var(--primary-foreground)] flex items-center justify-center border-2 border-[var(--background)] shadow-md">
                      <Logo className="w-5 h-5" />
                    </div>
                    <div className="px-4 py-3 rounded-2xl bg-[var(--secondary)] text-[var(--text-primary)] rounded-bl-none">
                        <div className="flex items-center justify-center gap-1">
                            <span className="w-2 h-2 bg-current rounded-full animate-bounce" />
                            <span className="w-2 h-2 bg-current rounded-full animate-bounce" style={{animationDelay: '0.2s'}} />
                            <span className="w-2 h-2 bg-current rounded-full animate-bounce" style={{animationDelay: '0.4s'}} />
                        </div>
                    </div>
                </motion.div>
            )}
        </div>
        <div className="flex-shrink-0 border-t border-[var(--border)] bg-[var(--background)] p-4">
            {stage === 'NAME_INPUT_PENDING' && !isModal ? (
                <TextInput
                    onSubmit={handleReply}
                    placeholder="Your company name"
                    disabled={isAiTyping}
                />
            ) : stage === 'AWAITING_ORGANIZER_OWNERSHIP' && !isModal ? (
                <TextInput
                    onSubmit={handleReply}
                    placeholder="Enter ownership percentage (e.g., 50)"
                    disabled={isAiTyping}
                    showPercentageOptions={true}
                />
            ) : (
                <SuggestedReplies replies={suggestedReplies} onSelect={handleReply} disabled={isAiTyping} />
            )}
        </div>
      </div>
    </div>
  );
}
