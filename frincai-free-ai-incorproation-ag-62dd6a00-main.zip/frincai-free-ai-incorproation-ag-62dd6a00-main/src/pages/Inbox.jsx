import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { User as UserEntity } from '@/api/entities';
import { Message } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Mail, MessageSquare, Archive } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function InboxPage() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  
  useEffect(() => {
    const loadData = async () => {
      try {
        const currentUser = await UserEntity.me();
        setUser(currentUser);
        const userMessages = await Message.filter({ recipient_email: currentUser.email }, '-created_date');
        setMessages(userMessages);

        // Mark unread messages as read
        const unreadMessages = userMessages.filter(msg => !msg.is_read);
        if (unreadMessages.length > 0) {
          await Promise.all(unreadMessages.map(msg => Message.update(msg.id, { is_read: true })));
          // Optional: refresh message list or update state locally to reflect read status instantly
          const refreshedMessages = await Message.filter({ recipient_email: currentUser.email }, '-created_date');
          setMessages(refreshedMessages);
        }

      } catch (error) {
        console.error("Error loading inbox:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="w-12 h-12 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 md:px-6 py-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center gap-3 mb-2">
          <Mail className="w-8 h-8 text-cyan-400" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
            Inbox
          </h1>
        </div>
        <p className="text-slate-400">All communications from the frinc.ai team.</p>
      </motion.div>

      <div className="max-w-4xl mx-auto">
        {messages.length === 0 ? (
          <div className="text-center py-20 bg-slate-800/50 rounded-2xl border border-slate-700">
            <Archive className="w-16 h-16 text-slate-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-300">Your Inbox is Empty</h3>
            <p className="text-slate-500">Important notifications and messages will appear here.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg, index) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className={`bg-slate-800/80 backdrop-blur-sm border transition-all duration-300 ${!msg.is_read ? 'border-cyan-500/50' : 'border-slate-700/50'}`}>
                    <CardHeader>
                        <div className="flex items-center justify-between">
                            <CardTitle className="text-lg text-slate-200">{msg.subject}</CardTitle>
                            <span className="text-xs text-slate-500">{new Date(msg.created_date).toLocaleString()}</span>
                        </div>
                        <CardDescription className="text-slate-400">From: {msg.sender_name}</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-300 whitespace-pre-wrap">{msg.body}</p>
                    </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}