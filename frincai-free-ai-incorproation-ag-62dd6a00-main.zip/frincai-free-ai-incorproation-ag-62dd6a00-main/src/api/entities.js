import { base44 } from './base44Client';


export const Test = base44.entities.Test;

export const Company = base44.entities.Company;

export const Message = base44.entities.Message;

export const StateData = base44.entities.StateData;



// auth sdk:
export const User = base44.auth;