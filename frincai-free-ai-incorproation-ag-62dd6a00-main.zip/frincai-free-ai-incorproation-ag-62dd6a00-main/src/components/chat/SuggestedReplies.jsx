import React from 'react';
import { motion } from 'framer-motion';

export default function SuggestedReplies({ replies, onSelect, disabled }) {
  if (!replies || replies.length === 0) return null;

  // Check if this is a state list (50 US states)
  const isStateList = replies.length === 51; // 50 states + "Use AI State Advisor"

  if (isStateList) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.5 }}
        className="px-4 py-6"
      >
        <div 
          className="grid grid-cols-3 gap-2 max-h-80 overflow-y-auto"
          style={{ scrollbarWidth: 'thin' }}
        >
          {replies.map((reply, index) => (
            <motion.button
              key={index}
              disabled={disabled}
              onClick={() => onSelect(reply)}
              className={`border text-sm px-3 py-2 rounded-full hover:border-[var(--primary)] transition-all disabled:opacity-50 disabled:cursor-wait text-center ${
                reply === 'Use AI State Advisor' 
                  ? 'bg-[var(--primary)] text-[var(--primary-foreground)] border-[var(--primary)]' 
                  : 'bg-[var(--background)] border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]'
              }`}
              whileHover={{ scale: disabled ? 1 : 1.02 }}
              whileTap={{ scale: disabled ? 1 : 0.98 }}
            >
              {typeof reply === 'string' ? reply : reply.label}
            </motion.button>
          ))}
        </div>
      </motion.div>
    );
  }

  // Regular suggested replies layout for non-state lists
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.5 }}
      className="flex flex-wrap items-center justify-center gap-2 px-4 py-6"
    >
      {replies.map((reply, index) => (
        <motion.button
          key={index}
          disabled={disabled}
          onClick={() => onSelect(reply)}
          className="bg-[var(--background)] border border-[var(--border)] text-[var(--text-primary)] rounded-full px-4 py-2 text-sm hover:bg-[var(--accent)] hover:border-[var(--primary)] transition-all disabled:opacity-50 disabled:cursor-wait"
          whileHover={{ scale: disabled ? 1 : 1.05 }}
          whileTap={{ scale: disabled ? 1 : 0.95 }}
        >
          {typeof reply === 'string' ? reply : reply.label}
        </motion.button>
      ))}
    </motion.div>
  );
}