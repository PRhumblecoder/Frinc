import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bot, User, Edit } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import Logo from '../Logo';
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export default function ChatMessage({ message, onEdit, user }) {
  const isAI = message.sender === 'ai';

  const handleEditClick = () => {
    if (onEdit && message.stage) {
      onEdit(message.stage, message.personIndex, message.isManager);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex items-end gap-2 my-2 ${isAI ? 'justify-start' : 'justify-end'}`}
    >
      {isAI && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[var(--primary)] text-[var(--primary-foreground)] flex items-center justify-center border-2 border-[var(--background)] shadow-md">
          <Logo className="w-5 h-5" />
        </div>
      )}
      <div
        className={`prose prose-sm max-w-xs md:max-w-md px-4 py-3 rounded-2xl break-words relative group ${
          isAI
            ? 'bg-[var(--secondary)] text-[var(--text-primary)] rounded-bl-none'
            : 'bg-[var(--primary)] text-[var(--primary-foreground)] rounded-br-none'
        }`}
      >
        <ReactMarkdown
          components={{
            p: ({node, ...props}) => <p className="text-inherit" {...props} />,
          }}
        >
          {message.text}
        </ReactMarkdown>
        {!isAI && message.isEditable && (
          <button
            onClick={handleEditClick}
            className="absolute -top-2 -right-2 bg-[var(--background)] border border-[var(--border)] rounded-full p-1.5 hover:bg-[var(--accent)]"
            aria-label="Edit this step"
          >
            <Edit className="w-3 h-3 text-[var(--text-secondary)]" />
          </button>
        )}
      </div>
      {!isAI && (
         <Avatar className="h-8 w-8 border-2 border-[var(--background)] shadow-md">
            <AvatarFallback className="bg-[var(--secondary)] text-[var(--text-primary)] text-xs font-bold">
                {user && user.full_name ? user.full_name.split(' ').map(n => n[0]).join('').toUpperCase() : <User className="w-4 h-4" />}
            </AvatarFallback>
        </Avatar>
      )}
    </motion.div>
  );
}