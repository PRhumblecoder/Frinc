import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function TextInput({ onSubmit, placeholder = "Type your message...", disabled = false, showPercentageOptions = false }) {
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (inputValue.trim() && !disabled) {
      onSubmit(inputValue.trim());
      setInputValue('');
    }
  };

  const handlePercentageSelect = (percentage) => {
    setInputValue(percentage.toString());
    onSubmit(percentage.toString());
  };

  const percentageOptions = [5, 10, 20, 33.333, 50, 75, 100];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-3"
    >
      <form onSubmit={handleSubmit} className="flex items-center gap-3 p-4">
        <Input
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          className="flex-1 bg-[var(--background)] border border-[var(--border)] text-[var(--text-primary)] rounded-full px-6 placeholder:text-[var(--muted-foreground)] h-16 text-base"
        />
        <Button
          type="submit"
          disabled={!inputValue.trim() || disabled}
          className="bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-30 transition-opacity rounded-full p-2 h-16 w-16 flex-shrink-0"
        >
          <Send className="w-6 h-6" />
        </Button>
      </form>
      
      {showPercentageOptions && (
        <div className="px-4 pb-2">
          <p className="text-xs text-[var(--text-secondary)] mb-2 text-center">Quick options:</p>
          <div className="flex flex-wrap justify-center gap-2">
            {percentageOptions.map((percentage) => (
              <motion.button
                key={percentage}
                disabled={disabled}
                onClick={() => handlePercentageSelect(percentage)}
                className="bg-[var(--secondary)] border border-[var(--border)] text-[var(--text-primary)] rounded-full px-3 py-1 text-xs hover:bg-[var(--accent)] hover:border-[var(--primary)] transition-all disabled:opacity-50 disabled:cursor-wait"
                whileHover={{ scale: disabled ? 1 : 1.05 }}
                whileTap={{ scale: disabled ? 1 : 0.95 }}
              >
                {percentage}%
              </motion.button>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
}