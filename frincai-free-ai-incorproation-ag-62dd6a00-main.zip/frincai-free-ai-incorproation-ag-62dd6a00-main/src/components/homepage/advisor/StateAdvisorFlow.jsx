
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, Sparkles, Loader, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const US_STATES = [
  'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut',
  'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa',
  'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan',
  'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
  'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio',
  'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota',
  'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia',
  'Wisconsin', 'Wyoming'
];

const StateResultPlaceholder = () => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className="bg-[var(--card-foreground)] border border-[var(--border)] rounded-xl p-4 animate-pulse"
  >
    <div className="flex items-center justify-between mb-3">
      <div className="h-6 bg-slate-400/30 rounded w-1/3"></div>
      <div className="h-6 bg-slate-400/30 rounded w-1/4"></div>
    </div>
    <div className="h-4 bg-slate-400/30 rounded w-full mb-2"></div>
    <div className="h-4 bg-slate-400/30 rounded w-5/6 mb-4"></div>
    <div className="grid grid-cols-2 gap-2 mb-4">
      {[...Array(6)].map((_, i) => (
        <div key={i} className="h-6 bg-slate-400/30 rounded-full w-full"></div>
      ))}
    </div>
    <div className="h-10 bg-slate-400/30 rounded w-full"></div>
  </motion.div>
);

export default function StateAdvisorFlow({
  onBack,
  onComplete,
  helpFlowStep,
  setHelpFlowStep,
  helpFlowData,
  onDataChange,
  onRunAnalysis,
  analysisResult,
  isLoading,
  // Removed loadingMessageIndex and loadingMessages as props, now managed internally
  handleStartOver,
  setCompanyData,
  setCurrentScreen,
  setStage,
  addMessage,
  setSuggestedReplies,
  COMPANY_TYPES,
}) {
  const [showMore, setShowMore] = useState(false);
  const [stateAdvisorLoadingMessageIndex, setStateAdvisorLoadingMessageIndex] = useState(0);
  const [showPlaceholders, setShowPlaceholders] = useState(false);
  const [revealedStatesCount, setRevealedStatesCount] = useState(0);

  const stateAdvisorLoadingMessages = [
    "Parsing your business needs...",
    "Comparing privacy & liability shields across all 50 states...",
    "Analyzing incorporation costs and annual fees...",
    "Evaluating your priorities against state benefits...",
    "Compiling tailored recommendations..."
  ];

  useEffect(() => {
    let interval;
    if (isLoading) {
      interval = setInterval(() => {
        setStateAdvisorLoadingMessageIndex(prevIndex => (prevIndex + 1) % stateAdvisorLoadingMessages.length);
      }, 1000); // Reduced from 2000ms to 1000ms (1 second)
    }
    return () => clearInterval(interval);
  }, [isLoading, stateAdvisorLoadingMessages.length]);

  useEffect(() => {
    let placeholderTimeout;
    if (isLoading) {
      // Show placeholders after a delay (e.g., 1 second)
      placeholderTimeout = setTimeout(() => {
        setShowPlaceholders(true);
      }, 1000);
    } else {
      // Hide placeholders immediately when loading stops
      setShowPlaceholders(false);
    }
    return () => clearTimeout(placeholderTimeout); // Cleanup timeout
  }, [isLoading]);

  useEffect(() => {
    if (analysisResult && !isLoading) {
        setRevealedStatesCount(0); // Reset on new analysis
        const states = analysisResult.top_recommended_states;
        if (!states || states.length === 0) return;

        const interval = setInterval(() => {
            setRevealedStatesCount(prev => {
                if (prev < states.length) {
                    return prev + 1;
                }
                clearInterval(interval);
                return prev;
            });
        }, 300); // 300ms between each reveal

        return () => clearInterval(interval);
    }
  }, [analysisResult, isLoading]);

  const correctPhysicalLocations = [
    'In the state of residency',
    'In state(s) other than residency',
    'No physical location in the US'
  ];

  const correctPriorities = [
    "Owners' Privacy",
    "Investors funding", 
    "Low Setup Cost",
    "Low Maintenance Cost"
  ];

  const canContinue = () => {
    if (helpFlowStep === 1) return helpFlowData.businessDescription.trim();
    if (helpFlowStep === 2) return helpFlowData.residency;
    if (helpFlowStep === 3) return helpFlowData.physicalLocation;
    if (helpFlowStep === 4) return helpFlowData.priorities.length > 0;
    return false;
  };

  const handlePriorityToggle = (priority) => {
    const newPriorities = helpFlowData.priorities.includes(priority)
      ? helpFlowData.priorities.filter(p => p !== priority)
      : [...helpFlowData.priorities, priority];
    onDataChange({...helpFlowData, priorities: newPriorities});
  };

  const renderContent = () => {
    switch (helpFlowStep) {
      case 1:
        return (
          <div className="flex flex-col h-full">
            <div className="flex-1 space-y-4">
              <h4 className="text-base font-semibold text-[var(--text-primary)] text-center">Tell us about your business</h4>
              <Textarea
                placeholder="e.g., An online store selling handmade jewelry, a SaaS for project management, a consulting business for startups..."
                value={helpFlowData.businessDescription}
                onChange={(e) => onDataChange({...helpFlowData, businessDescription: e.target.value})}
                className="bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] rounded-xl h-40 placeholder:text-[var(--muted-foreground)]"
              />
            </div>
            <div className="flex gap-3 pt-4">
               <Button onClick={() => setHelpFlowStep(2)} disabled={!canContinue()} className="w-full bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-30 transition-opacity">Continue</Button>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="flex flex-col h-full">
            <div className="flex-1 space-y-4">
              <h4 className="text-base font-semibold text-[var(--text-primary)] text-center">What is your state of residency?</h4>
              <Select onValueChange={(value) => onDataChange({...helpFlowData, residency: value})} value={helpFlowData.residency}>
                <SelectTrigger className="bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] rounded-xl">
                  <SelectValue placeholder="Select your residency *" />
                </SelectTrigger>
                <SelectContent className="bg-[var(--popover)] border-[var(--border)] text-[var(--popover-foreground)] max-h-60 overflow-y-auto">
                  <SelectItem value="Non U.S. Resident" className="focus:bg-[var(--accent)]">I'm a Non U.S. Resident</SelectItem>
                  {US_STATES.map(state => (
                    <SelectItem key={state} value={state} className="focus:bg-[var(--accent)]">{state}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-3 pt-4">
              <Button variant="outline" className="flex-1 border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]" onClick={() => setHelpFlowStep(1)}>Back</Button>
              <Button onClick={() => setHelpFlowStep(3)} disabled={!canContinue()} className="flex-1 bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-30 transition-opacity">Continue</Button>
            </div>
          </div>
        );
      case 3:
        return (
          <div className="flex flex-col h-full">
            <div className="flex-1 space-y-2">
              <h4 className="text-base font-semibold text-[var(--text-primary)] text-center mb-4">Where is your physical business location?</h4>
              {correctPhysicalLocations.map((location) => (
                <div
                  key={location}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    helpFlowData.physicalLocation === location
                      ? 'border-[var(--primary)] bg-[hsl(var(--primary)/0.2)]'
                      : 'border-[var(--border)] bg-[var(--secondary)] hover:border-[var(--muted-foreground)]'
                  }`}
                  onClick={() => onDataChange({...helpFlowData, physicalLocation: location})}
                >
                  <span className="text-[var(--text-primary)] text-sm">{location}</span>
                </div>
              ))}
            </div>
            <div className="flex gap-3 pt-4">
              <Button variant="outline" className="flex-1 border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]" onClick={() => setHelpFlowStep(2)}>Back</Button>
              <Button onClick={() => setHelpFlowStep(4)} disabled={!canContinue()} className="flex-1 bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-30 transition-opacity">Continue</Button>
            </div>
          </div>
        );
      case 4:
        return (
          <div className="flex flex-col h-full">
            <div className="flex-1 space-y-2">
              <h4 className="text-base font-semibold text-[var(--text-primary)] text-center">What matters most to you?</h4>
              <p className="text-xs text-[var(--text-secondary)] text-center mb-4">Select all that apply</p>
              {correctPriorities.map((priority) => (
                <div
                  key={priority}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    helpFlowData.priorities.includes(priority)
                      ? 'border-[var(--primary)] bg-[hsl(var(--primary)/0.2)]'
                      : 'border-[var(--border)] bg-[var(--secondary)] hover:border-[var(--muted-foreground)]'
                  }`}
                  onClick={() => handlePriorityToggle(priority)}
                >
                  <span className="text-[var(--text-primary)] text-sm">{priority}</span>
                </div>
              ))}
            </div>
            <div className="flex justify-center pt-4">
              <div className="flex gap-3 w-full">
                <Button variant="outline" className="flex-1 border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]" onClick={() => setHelpFlowStep(3)}>Back</Button>
                <Button onClick={onRunAnalysis} disabled={!canContinue()} className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:opacity-30 transition-opacity">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Get AI Recommendation
                </Button>
              </div>
            </div>
          </div>
        );
      case 5:
        if (isLoading) {
          if (showPlaceholders) {
            return (
              <div className="text-left">
                <div className="mb-4">
                    <h4 className="text-base font-bold text-[var(--text-primary)] mb-2">AI Recommendations</h4>
                    <div className="bg-[var(--secondary)] p-2 rounded-lg border border-[var(--border)]">
                        <AnimatePresence mode="wait">
                            <motion.p
                              key={stateAdvisorLoadingMessageIndex}
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              exit={{ opacity: 0 }}
                              transition={{ duration: 0.3 }}
                              className="text-xs text-[var(--text-secondary)] text-center"
                            >
                              {stateAdvisorLoadingMessages[stateAdvisorLoadingMessageIndex]}
                            </motion.p>
                        </AnimatePresence>
                    </div>
                </div>
                <div className="h-20 bg-[var(--secondary)] p-3 rounded-lg border border-[var(--border)] mb-4 animate-pulse">
                   <div className="h-4 bg-slate-400/30 rounded w-full mb-2"></div>
                   <div className="h-4 bg-slate-400/30 rounded w-3/4"></div>
                </div>
                <div className="space-y-3">
                  <StateResultPlaceholder />
                  <StateResultPlaceholder />
                </div>
              </div>
            );
          }
          return (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <Loader className="w-10 h-10 text-[var(--primary)] animate-spin mb-4" />
              <h4 className="text-lg font-bold text-[var(--text-primary)] mb-2">Running AI Analysis...</h4>
              <div className="bg-[var(--secondary)] p-2 rounded-lg border border-[var(--border)] max-w-xs">
                  <AnimatePresence mode="wait">
                    <motion.p
                      key={stateAdvisorLoadingMessageIndex}
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      transition={{ duration: 0.3 }}
                      className="text-xs text-[var(--text-secondary)] text-center"
                    >
                      {stateAdvisorLoadingMessages[stateAdvisorLoadingMessageIndex]}
                    </motion.p>
                  </AnimatePresence>
              </div>
            </div>
          );
        }
        if (analysisResult && analysisResult.error) {
            return (
                <div className="text-center text-red-400">
                    <p>{analysisResult.error}</p>
                    <Button onClick={handleStartOver} className="mt-4">Try Again</Button>
                </div>
            )
        }
        if (analysisResult) {
            const allStates = analysisResult.top_recommended_states;
            const statesToDisplay = allStates.slice(0, revealedStatesCount);
            const maxVisible = showMore ? allStates.length : 3;
            const placeholdersCount = Math.max(0, Math.min(maxVisible, allStates.length) - revealedStatesCount);

          return (
            <div className="text-left">
              <motion.h4 initial={{opacity:0}} animate={{opacity:1}} className="text-base font-bold text-[var(--text-primary)] mb-2">AI Recommendations</motion.h4>
              <motion.p
                 initial={{ opacity: 0 }}
                 animate={{ opacity: 1 }}
                 transition={{ duration: 0.3 }}
                className="text-sm text-[var(--text-secondary)] bg-[var(--secondary)] p-3 rounded-lg border border-[var(--border)] mb-4">
                {analysisResult.analysis_summary}
              </motion.p>
              
              <div className="space-y-3">
                {statesToDisplay.slice(0, maxVisible).map((state) => (
                  <motion.div
                    key={state.state_name}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className="bg-[var(--card-foreground)] border border-[var(--border)] rounded-xl p-4"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h5 className="font-bold text-[var(--text-primary)] text-lg">{state.state_name}</h5>
                      <div className="flex items-center gap-2">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="font-bold text-yellow-400">{state.overall_score}/10</span>
                      </div>
                    </div>
                    <p className="text-sm text-[var(--text-secondary)] mb-3">{state.summary}</p>
                    <div className="grid grid-cols-2 gap-2 mb-3">
                      <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Privacy:</span><span className="font-semibold text-[var(--text-primary)]">{state.owners_privacy_score}/10</span></div>
                      <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Funding:</span><span className="font-semibold text-[var(--text-primary)]">{state.fundraising_score}/10</span></div>
                      <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Income Tax:</span><span className="font-semibold text-[var(--text-primary)]">{state.income_tax_score}/10</span></div>
                      <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Sales Tax:</span><span className="font-semibold text-[var(--text-primary)]">{state.sales_tax_score}/10</span></div>
                      <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Setup:</span><span className="font-semibold text-[var(--text-primary)]">{state.setup_cost_score}/10</span></div>
                      <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Maint:</span><span className="font-semibold text-[var(--text-primary)]">{state.maintenance_cost_score}/10</span></div>
                    </div>
                    <Button 
                      onClick={() => {
                        console.log('Button clicked for state:', state.state_name);
                        onComplete(state.state_name);
                      }}
                      className="w-full bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-30 transition-opacity"
                    >
                      Select {state.state_name}
                    </Button>
                  </motion.div>
                ))}
                 {Array.from({ length: placeholdersCount }).map((_, index) => (
                    <StateResultPlaceholder key={`placeholder-${index}`} />
                ))}
              </div>

              <div className="mt-4 space-y-3">
                {allStates.length > 3 && !showMore && revealedStatesCount >= 3 && (
                  <Button 
                    variant="outline" 
                    onClick={() => setShowMore(true)}
                    className="w-full border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]"
                  >
                    Load More States
                  </Button>
                )}
                 <Button 
                    variant="outline" 
                    onClick={() => {
                      console.log('Back to state selection clicked');
                      onBack();
                    }}
                    className="w-full border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]"
                  >
                    Back to State Selection
                  </Button>
              </div>
            </div>
          );
        }
        return null;
    }
  };
  
  return (
    <motion.div
      key="state-advisor"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="h-full flex flex-col p-6 bg-[var(--background)]"
    >
      <div className="flex-shrink-0 flex items-center justify-center mb-6 relative">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={helpFlowStep === 1 ? onBack : () => setHelpFlowStep(helpFlowStep - 1)} 
          className="absolute left-0 rounded-full h-10 w-10 bg-[var(--secondary)] backdrop-blur-sm border border-[var(--border)] hover:bg-[var(--accent)] hover:border-[var(--primary)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all shadow-lg"
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h3 className="text-lg font-bold text-[var(--text-primary)] flex-1 text-center">AI State Advisor</h3>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={onBack}
          className="absolute right-0 rounded-full h-10 w-10 bg-[var(--secondary)] backdrop-blur-sm border border-[var(--border)] hover:bg-[var(--accent)] hover:border-[var(--primary)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all shadow-lg"
        >
          <span className="text-lg">×</span>
        </Button>
      </div>

      {helpFlowStep < 5 && (
        <div className="flex justify-center mb-4">
          <div className="flex gap-2">
            {[1, 2, 3, 4].map((step) => (
              <motion.div
                key={step}
                className={`w-2 h-2 rounded-full transition-colors ${
                  step <= helpFlowStep ? 'bg-[var(--primary)]' : 'bg-slate-600'
                }`}
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                transition={{ delay: step * 0.05 }}
              />
            ))}
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto custom-scrollbar -mr-2 pr-2">
        {renderContent()}
      </div>
    </motion.div>
  );
}
