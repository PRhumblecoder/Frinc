import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

const FactorBar = ({ label, score }) => (
  <div className="w-full">
    <div className="flex justify-between items-center mb-1">
      <span className="text-xs text-slate-300">{label}</span>
      <span className="text-xs font-bold text-white">{score.toFixed(1)}/10</span>
    </div>
    <div className="w-full bg-slate-700/50 rounded-full h-1.5">
      <motion.div 
        className="bg-gradient-to-r from-cyan-500 to-blue-500 h-1.5 rounded-full"
        initial={{ width: 0 }}
        animate={{ width: `${score * 10}%` }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      />
    </div>
  </div>
);


export default function AnalysisScreen({
  isAnalyzing,
  progressPercent,
  analysisResult,
  showMoreResults,
  loadingMore,
  allResultsLoaded,
  onRecommendationSelect,
  onTypeRecommendationSelect,
  onLoadMore,
  onTryAgain,
  isTypeAnalysis = false
}) {
  if (isAnalyzing || !analysisResult) {
    return (
      <div className="h-full flex flex-col justify-center items-center p-6 text-center text-white">
        <motion.div 
          className="w-16 h-16 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-full flex items-center justify-center mb-6"
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
        >
          <Sparkles className="w-8 h-8 text-white" />
        </motion.div>
        <h3 className="text-xl font-bold mb-2">AI is analyzing...</h3>
        <p className="text-slate-300 mb-4 text-sm">
          {isTypeAnalysis ? 'Finding the best legal structure...' : 'Finding the perfect state for your venture...'}
        </p>
        <div className="w-full bg-slate-700 rounded-full h-2.5 mb-2">
          <motion.div 
            className="bg-gradient-to-r from-purple-500 to-indigo-600 h-2.5 rounded-full"
            initial={{ width: '0%' }}
            animate={{ width: `${progressPercent}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
        <p className="text-sm text-slate-400">{Math.round(progressPercent)}% complete</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full flex flex-col h-full p-6"
    >
      <div className="flex-shrink-0 text-center mb-4">
        <div className="bg-gradient-to-r from-emerald-500 to-cyan-600 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
          <Check className="w-6 h-6 text-white" />
        </div>
        <h3 className="text-xl font-bold text-white">
          {isTypeAnalysis ? 'Type Recommendations' : 'Top Recommendations'}
        </h3>
      </div>
      
      <div className="flex-grow space-y-3 overflow-y-auto custom-scrollbar -mr-3 pr-3 pb-2">
        {analysisResult?.recommendations?.length > 0 ? 
          analysisResult.recommendations.map((rec, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-slate-800/60 rounded-xl p-4 border border-slate-600/50"
            >
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-bold text-lg text-white">
                  {isTypeAnalysis ? rec.type : rec.state}
                </h4>
                <div className="flex items-baseline gap-1 text-cyan-400">
                  <div className="text-2xl font-bold">{rec.score?.toFixed(1) || 'N/A'}</div>
                  <div className="text-sm font-medium">/10</div>
                </div>
              </div>
              <p className="text-sm text-slate-300 mb-4 leading-relaxed text-left">{rec.reasoning}</p>
              
              <div className="text-left border-t border-slate-700 pt-3 space-y-3">
                {rec.factors && Object.entries(rec.factors).map(([factor, factorScore]) => (
                  <FactorBar key={factor} label={factor} score={typeof factorScore === 'number' ? factorScore : 0} />
                ))}
              </div>
              
              <Button 
                onClick={() => isTypeAnalysis ? onTypeRecommendationSelect(rec.type) : onRecommendationSelect(rec.state, rec.entity_type)}
                className="w-full mt-4 bg-cyan-600 hover:bg-cyan-700"
              >
                Select {isTypeAnalysis ? rec.type : `${rec.state} (${rec.entity_type?.toUpperCase() || 'LLC'})`}
              </Button>
            </motion.div>
          )) : (
            <div className="text-center text-slate-400 flex flex-col justify-center items-center h-full">
              <p className="mb-4">No recommendations available. Please try again.</p>
              <Button 
                onClick={onTryAgain}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Try Again
              </Button>
            </div>
          )
        }
        {!isTypeAnalysis && !allResultsLoaded && analysisResult?.recommendations?.length > 0 && (
            <Button 
              onClick={onLoadMore}
              disabled={loadingMore}
              variant="outline"
              className="w-full border-slate-600 text-slate-300 hover:bg-slate-700/50 hover:text-white"
            >
              {loadingMore ? 'Loading...' : 'Show More Recommendations'}
            </Button>
        )}
      </div>
    </motion.div>
  );
}