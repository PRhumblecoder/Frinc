
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, Sparkles, Building, Monitor, Loader, Info, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { InvokeLLM } from '@/api/integrations';

const TypeResultPlaceholder = () => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className="bg-[var(--card-foreground)] border border-[var(--border)] rounded-xl p-4 animate-pulse"
  >
    <div className="flex items-center justify-between mb-3">
      <div className="h-6 bg-slate-400/30 rounded w-1/2"></div>
      <div className="h-6 bg-slate-400/30 rounded w-1/4"></div>
    </div>
    <div className="h-4 bg-slate-400/30 rounded w-full mb-2"></div>
    <div className="h-4 bg-slate-400/30 rounded w-5/6 mb-4"></div>
    <div className="grid grid-cols-2 gap-2 mb-4">
      {[...Array(6)].map((_, i) => (
        <div key={i} className="h-6 bg-slate-400/30 rounded-full w-full"></div>
      ))}
    </div>
    <div className="h-10 bg-slate-400/30 rounded w-full"></div>
  </motion.div>
);


export default function TypeAdvisorFlow({ onBack, onComplete, state, existingData }) {
  // If we have existing data from State Advisor, skip to step 4 and auto-run analysis
  const [step, setStep] = useState(existingData ? 4 : 1);
  const [businessDescription, setBusinessDescription] = useState(existingData?.businessDescription || '');
  const [scenario, setScenario] = useState(existingData ? 'B' : null); // Default to online business if coming from State Advisor
  const [priorities, setPriorities] = useState(existingData?.priorities || []);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const [loadingMessageIndex, setLoadingMessageIndex] = useState(0);
  const [showPlaceholders, setShowPlaceholders] = useState(false);
  const [revealedResultsCount, setRevealedResultsCount] = useState(0);

  // New states for selection confirmation
  const [selectedRecommendation, setSelectedRecommendation] = useState(null);
  const [showSelectionConfirmation, setShowSelectionConfirmation] = useState(false);
  const [isSelecting, setIsSelecting] = useState(false); // To disable buttons during the selection process

  const loadingMessages = [
    "Analyzing your business model and priorities...",
    "Comparing tax structures (LLC vs S-Corp vs C-Corp)...",
    "Evaluating investor-friendliness vs. personal liability...",
    `Finalizing optimal entity type for ${state}...`
  ];

  // Auto-run analysis if we have existing data
  useEffect(() => {
    if (existingData && !analysisResult && !isLoading) {
      handleRunAnalysis();
    }
  }, [existingData, analysisResult, isLoading]);

  useEffect(() => {
    let interval;
    if (isLoading) {
      interval = setInterval(() => {
        setLoadingMessageIndex(prevIndex => (prevIndex + 1) % loadingMessages.length);
      }, 1000); // Reduced from 2000ms to 1000ms (1 second)
    }
    return () => clearInterval(interval);
  }, [isLoading, loadingMessages.length]);

  useEffect(() => {
    let placeholderTimeout;
    if (isLoading) {
      placeholderTimeout = setTimeout(() => {
        setShowPlaceholders(true);
      }, 1000);
    } else {
      setShowPlaceholders(false);
    }
    return () => clearTimeout(placeholderTimeout);
  }, [isLoading]);

  useEffect(() => {
    if (analysisResult && !isLoading) {
        setRevealedResultsCount(0); // Reset
        const recs = analysisResult.recommendations;
        if (!recs || recs.length === 0) return;

        // Start revealing results one by one
        const interval = setInterval(() => {
            setRevealedResultsCount(prev => {
                if (prev < recs.length) {
                    return prev + 1;
                }
                clearInterval(interval);
                return prev;
            });
        }, 300); // Reveal one item every 300ms

        return () => clearInterval(interval); // Cleanup interval on component unmount or dependency change
    }
  }, [analysisResult, isLoading]);

  const priorityOptions = [
    "Owners' Privacy",
    "Investors funding",
    "Low Setup Cost",
    "Low Maintenance Cost"
  ];

  const createPrompt = (residenceState, description, selectedScenario, selectedPriorities) => {
    const scenarioText = selectedScenario === 'A'
      ? "Scenario A: A physical business (e.g., retail store, service office) located within my state of residence, with local employees."
      : "Scenario B: A purely online business with no physical presence, no employees, and no inventory in my state of residence (only the owner resides there).";

    const prioritiesText = selectedPriorities.length > 0
      ? `The user's top priorities are: ${selectedPriorities.join(', ')}.`
      : '';

    return `
      You are an expert US business formation and tax advisor. A user needs an entity type recommendation.

      User's Information:
      - State of Residence: ${residenceState}
      - Business Description: "${description}"
      - Business Scenario: ${scenarioText}
      ${prioritiesText}

      Please evaluate the entity types based on these factors:
      - Owners' Privacy: How much personal information is publicly disclosed?
      - Fundraising Potential: How attractive is this structure to VCs or angel investors?
      - Low State Income Tax: Considering corporate and individual pass-through taxes in ${residenceState} and the state of formation.
      - Low Sales Tax Burden: How the entity affects sales tax, especially for online businesses.
      - Low Setup Cost: Initial state filing fees and legal/accounting costs.
      - Low Maintenance Cost: Annual state fees, registered agent fees, and ongoing compliance.

      Provide a detailed comparison and recommendations for these entity types, adapted for ${residenceState}:
      - LLC (default tax) in ${residenceState}.
      - LLC (elected as S-Corp) in ${residenceState}.
      - C-Corp in ${residenceState}.
      - Delaware C-Corp (with foreign registration in ${residenceState}).
      - Wyoming LLC (with foreign registration in ${residenceState} if applicable, or as a standalone option).

      Return the entire response as a single JSON object matching the provided schema.
    `;
  };

  const responseSchema = {
    type: "object",
    properties: {
      recommendations: {
        type: "array",
        description: "A list of recommended entity options.",
        items: {
          type: "object",
          properties: {
            display_name: { type: "string", description: "e.g., Delaware LLC, Wyoming C-Corp" },
            state_name: { type: "string", description: "The state for this entity. e.g. Delaware" },
            type_id: { type: "string", enum: ["llc", "inc", "scorp"], description: "The machine-readable type id." },
            summary: { type: "string", description: "Brief summary of why this option is recommended" },
            overall_score: { type: "number", description: "Overall score for this option, out of 10." },
            owners_privacy_score: { type: "number" },
            fundraising_score: { type: "number" },
            income_tax_score: { type: "number" },
            sales_tax_score: { type: "number" },
            setup_cost_score: { type: "number" },
            maintenance_cost_score: { type: "number" }
          },
          required: ["display_name", "state_name", "type_id", "summary", "overall_score", "owners_privacy_score", "fundraising_score", "income_tax_score", "sales_tax_score", "setup_cost_score", "maintenance_cost_score"]
        }
      },
      analysis_summary: {
        type: "string",
        description: "A brief summary of the overall recommendation."
      },
      scenario_b_deep_dive: {
        type: "object",
        description: "Specific analysis for Scenario B, only present if Scenario B was chosen.",
        properties: {
          economic_nexus_explanation: { type: "string" },
          wyoming_llc_analysis: { type: "string" }
        }
      }
    },
    required: ["recommendations", "analysis_summary"]
  };

  const handleRunAnalysis = async () => {
    setIsLoading(true);
    setStep(4);
    try {
      const prompt = createPrompt(state, businessDescription, scenario, priorities);
      const result = await InvokeLLM({ prompt: prompt, response_json_schema: responseSchema });
      // Sort results by overall_score descending
      result.recommendations.sort((a, b) => b.overall_score - a.overall_score);
      setAnalysisResult(result);
    } catch (error) {
      console.error("AI Analysis failed:", error);
      setAnalysisResult({ error: "Analysis failed. Please try again." });
    } finally {
      setIsLoading(false);
    }
  };

  const handlePriorityToggle = (priority) => {
    setPriorities(prev =>
      prev.includes(priority)
        ? prev.filter(p => p !== priority)
        : [...prev, priority]
    );
  };

  const handleStartOver = () => {
    setBusinessDescription('');
    setScenario(null);
    setPriorities([]);
    setAnalysisResult(null);
    setRevealedResultsCount(0); // Reset for start over
    setShowMore(false); // Reset for start over
    setStep(1);
  };

  const handleSelectRecommendation = (rec) => {
    setIsSelecting(true);
    setSelectedRecommendation(rec);
    setShowSelectionConfirmation(true);

    setTimeout(() => {
      onComplete({ state: rec.state_name, type: rec.type_id });
      setShowSelectionConfirmation(false);
      setSelectedRecommendation(null);
      setIsSelecting(false);
    }, 1500); // Show confirmation for 1.5 seconds
  };

  const renderContent = () => {
    switch (step) {
      case 1:
        return (
          <div className="flex flex-col h-full">
            <div className="flex-1 space-y-4">
              <h4 className="text-base font-semibold text-[var(--text-primary)] text-center">Tell us about your business</h4>
              <Textarea
                placeholder="e.g., An online store selling handmade jewelry, a SaaS for project management, a consulting business for startups..."
                value={businessDescription}
                onChange={(e) => setBusinessDescription(e.target.value)}
                className="bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] rounded-xl h-40 placeholder:text-[var(--muted-foreground)]"
                disabled={isSelecting}
              />
            </div>
            <div className="flex gap-3 pt-4">
              <Button onClick={() => setStep(2)} disabled={!businessDescription.trim() || isSelecting} className="w-full bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-30 transition-opacity">Continue</Button>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="flex flex-col h-full">
            <div className="flex-1 space-y-4">
              <h4 className="text-base font-semibold text-[var(--text-primary)] text-center">What is your business scenario?</h4>
              <div className="space-y-3">
                <div className={`p-4 rounded-xl border border-[var(--border)] bg-[var(--card-foreground)] cursor-pointer ${isSelecting ? 'opacity-50' : 'hover:border-[var(--muted-foreground)]'}`} onClick={() => { if (!isSelecting) { setScenario('A'); setStep(3); } }}>
                  <div className="flex items-start gap-3">
                      <Building className="w-6 h-6 text-[var(--primary)] flex-shrink-0 mt-1" />
                      <div>
                          <p className="font-semibold text-[var(--text-primary)]">Physical Business</p>
                          <p className="text-xs text-[var(--text-secondary)]">e.g., retail store, service office with local employees.</p>
                      </div>
                  </div>
                </div>
                <div className={`p-4 rounded-xl border border-[var(--border)] bg-[var(--card-foreground)] cursor-pointer ${isSelecting ? 'opacity-50' : 'hover:border-[var(--muted-foreground)]'}`} onClick={() => { if (!isSelecting) { setScenario('B'); setStep(3); } }}>
                  <div className="flex items-start gap-3">
                      <Monitor className="w-6 h-6 text-[var(--primary)] flex-shrink-0 mt-1" />
                      <div>
                          <p className="font-semibold text-[var(--text-primary)]">Online Business</p>
                          <p className="text-xs text-[var(--text-secondary)]">No physical presence or employees in your state.</p>
                      </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex gap-3 pt-4">
                 <Button variant="outline" className="flex-1 border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]" onClick={() => setStep(1)} disabled={isSelecting}>Back</Button>
                 <div className="flex-1" />
            </div>
          </div>
        );
      case 3:
        return (
          <div className="flex flex-col h-full">
            <div className="flex-1 space-y-2">
              <h4 className="text-base font-semibold text-[var(--text-primary)] text-center">What is important to you?</h4>
              <p className="text-xs text-[var(--text-secondary)] text-center mb-4">Select all that apply</p>
              <div className="space-y-2">
                {priorityOptions.map((priority) => (
                  <div
                    key={priority}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      priorities.includes(priority)
                      ? 'border-[var(--primary)] bg-[hsl(var(--primary)/0.2)]'
                      : 'border-[var(--border)] bg-[var(--secondary)] hover:border-[var(--muted-foreground)]'
                    } ${isSelecting ? 'opacity-50 pointer-events-none' : ''}`}
                    onClick={() => handlePriorityToggle(priority)}
                  >
                    <span className="text-[var(--text-primary)] text-sm">{priority}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex justify-center pt-4">
              <div className="flex gap-3 w-full">
                <Button variant="outline" className="flex-1 border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]" onClick={() => setStep(2)} disabled={isSelecting}>Back</Button>
                <Button onClick={handleRunAnalysis} disabled={!priorities.length || isSelecting} className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:opacity-30 transition-opacity">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Get AI Recommendation
                </Button>
              </div>
            </div>
          </div>
        );
      case 4:
        if (isLoading) {
          if (showPlaceholders) {
             return (
              <div className="text-left">
                <div className="flex justify-between items-center mb-2">
                    <h4 className="text-base font-bold text-[var(--text-primary)]">AI Recommendations</h4>
                </div>
                <div className="bg-[var(--secondary)] p-2 rounded-lg border border-[var(--border)] mb-4">
                    <AnimatePresence mode="wait">
                        <motion.p
                          key={loadingMessageIndex}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="text-xs text-[var(--text-secondary)] text-center"
                        >
                          {loadingMessages[loadingMessageIndex]}
                        </motion.p>
                    </AnimatePresence>
                </div>
                <div className="h-20 bg-[var(--secondary)] p-3 rounded-lg border border-[var(--border)] mb-4 animate-pulse">
                   <div className="h-4 bg-slate-400/30 rounded w-full mb-2"></div>
                   <div className="h-4 bg-slate-400/30 rounded w-3/4"></div>
                </div>
                <div className="space-y-3">
                  <TypeResultPlaceholder />
                  <TypeResultPlaceholder />
                </div>
              </div>
            );
          }
          return (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <Loader className="w-10 h-10 text-[var(--primary)] animate-spin mb-4" />
              <h4 className="text-lg font-bold text-[var(--text-primary)] mb-2">Running AI Analysis...</h4>
              <div className="bg-[var(--secondary)] p-2 rounded-lg border border-[var(--border)] max-w-xs">
                  <AnimatePresence mode="wait">
                    <motion.p
                      key={loadingMessageIndex}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.3 }}
                      className="text-xs text-[var(--text-secondary)] text-center"
                    >
                      {loadingMessages[loadingMessageIndex]}
                    </motion.p>
                  </AnimatePresence>
              </div>
            </div>
          );
        }
        if (analysisResult && analysisResult.error) {
          return (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <p className="text-center text-red-400">{analysisResult.error}</p>
              <Button
                variant="outline"
                onClick={handleStartOver}
                className="mt-4 w-full border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]"
              >
                Try Again
              </Button>
            </div>
          );
        }
        // New conditional rendering for confirmation
        if (showSelectionConfirmation) {
          return (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.3 }}
              className="flex flex-col items-center justify-center h-full text-center p-6"
            >
              <Sparkles className="w-16 h-16 text-[var(--primary)] mb-6 animate-pulse" />
              <h4 className="text-2xl font-bold text-[var(--text-primary)] mb-2">Great Choice!</h4>
              {selectedRecommendation && (
                <p className="text-lg text-[var(--text-secondary)] mb-8">
                  You've selected <span className="font-semibold text-[var(--text-primary)]">{selectedRecommendation.display_name}</span>.
                </p>
              )}
              <Loader className="w-8 h-8 text-[var(--primary)] animate-spin" />
              <p className="text-sm text-[var(--text-secondary)] mt-4">Redirecting to next step...</p>
            </motion.div>
          );
        }
        if (analysisResult) {
          const allResults = analysisResult.recommendations;
          const maxVisibleBeforeShowMore = 3;
          const numberOfRealResultsToShow = showMore ? allResults.length : Math.min(revealedResultsCount, maxVisibleBeforeShowMore);

          const resultsToDisplay = allResults.slice(0, numberOfRealResultsToShow);
          const numberOfPlaceholdersToShow = Math.max(0, (showMore ? allResults.length : maxVisibleBeforeShowMore) - numberOfRealResultsToShow);

          return (
            <div className="text-left">
              <motion.h4 initial={{opacity:0}} animate={{opacity:1}} className="text-base font-bold text-[var(--text-primary)] mb-2">AI Recommendations</motion.h4>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="text-sm text-[var(--text-secondary)] bg-[var(--secondary)] p-3 rounded-lg border border-[var(--border)] mb-4">
                {analysisResult.analysis_summary}
              </motion.p>

              <div className="space-y-3">
                <AnimatePresence mode="popLayout">
                  {resultsToDisplay.map((rec, index) => (
                    <motion.div
                      key={index} // Index is stable for already rendered items in a slice growing from 0
                      layout // For smooth transitions when items are added/removed
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }} // Animate out if an item is removed (e.g. going back a step)
                      transition={{ duration: 0.3 }}
                      className="bg-[var(--card-foreground)] border border-[var(--border)] rounded-xl p-4"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="font-bold text-[var(--text-primary)] text-lg">{rec.display_name}</h5>
                        <div className="flex items-center gap-2">
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                          <span className="font-bold text-yellow-400">{rec.overall_score}/10</span>
                        </div>
                      </div>
                      <p className="text-sm text-[var(--text-secondary)] mb-3">{rec.summary}</p>
                      <div className="grid grid-cols-2 gap-2 mb-3">
                        <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Privacy:</span><span className="font-semibold text-[var(--text-primary)]">{rec.owners_privacy_score}/10</span></div>
                        <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Funding:</span><span className="font-semibold text-[var(--text-primary)]">{rec.fundraising_score}/10</span></div>
                        <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Income Tax:</span><span className="font-semibold text-[var(--text-primary)]">{rec.income_tax_score}/10</span></div>
                        <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Sales Tax:</span><span className="font-semibold text-[var(--text-primary)]">{rec.sales_tax_score}/10</span></div>
                        <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Setup:</span><span className="font-semibold text-[var(--text-primary)]">{rec.setup_cost_score}/10</span></div>
                        <div className="flex items-center text-xs bg-[var(--secondary)] px-2 py-1 rounded-full border border-[var(--border)]"><span className="text-[var(--muted-foreground)] mr-1.5">Maint:</span><span className="font-semibold text-[var(--text-primary)]">{rec.maintenance_cost_score}/10</span></div>
                      </div>
                      <Button
                        onClick={() => handleSelectRecommendation(rec)}
                        className="w-full bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-30 transition-opacity"
                        disabled={isSelecting}
                      >
                        Select {rec.display_name}
                      </Button>
                    </motion.div>
                  ))}
                  {Array.from({ length: numberOfPlaceholdersToShow }).map((_, index) => (
                      <TypeResultPlaceholder key={`placeholder-${index}`} />
                  ))}
                </AnimatePresence>
              </div>

              <div className="mt-4 space-y-3">
                {allResults.length > maxVisibleBeforeShowMore && !showMore && revealedResultsCount >= maxVisibleBeforeShowMore && (
                  <Button
                    variant="outline"
                    onClick={() => setShowMore(true)}
                    className="w-full border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]"
                    disabled={isSelecting}
                  >
                    Load More Options
                  </Button>
                )}

                <Button
                  variant="outline"
                  onClick={handleStartOver}
                  className="w-full border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]"
                  disabled={isSelecting}
                >
                  Start Over
                </Button>
              </div>

              {analysisResult.scenario_b_deep_dive && (
                <div className="mt-4 space-y-3">
                  <div className="bg-[var(--secondary)] p-3 rounded-lg border border-[var(--border)]">
                    <h5 className="font-semibold text-[var(--text-primary)] text-sm flex items-center gap-2 mb-1"><Info className="w-4 h-4 text-[var(--primary)]"/> Economic Nexus</h5>
                    <p className="text-xs text-[var(--text-secondary)]">{analysisResult.scenario_b_deep_dive.economic_nexus_explanation}</p>
                  </div>
                   <div className="bg-[var(--secondary)] p-3 rounded-lg border border-[var(--border)]">
                    <h5 className="font-semibold text-[var(--text-primary)] text-sm flex items-center gap-2 mb-1"><Info className="w-4 h-4 text-[var(--primary)]"/> Wyoming LLC Analysis</h5>
                    <p className="text-xs text-[var(--text-secondary)]">{analysisResult.scenario_b_deep_dive.wyoming_llc_analysis}</p>
                  </div>
                </div>
              )}
            </div>
          );
        }
        return null;
    }
  };

  return (
    <motion.div
      key="type-advisor"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="h-full flex flex-col p-6 bg-[var(--background)]"
    >
      <div className="flex-shrink-0 flex items-center justify-center mb-6 relative">
        <Button
          variant="ghost"
          size="icon"
          onClick={step === 1 ? onBack : () => setStep(step - 1)}
          className="absolute left-0 rounded-full h-10 w-10 bg-[var(--secondary)] backdrop-blur-sm border border-[var(--border)] hover:bg-[var(--accent)] hover:border-[var(--primary)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all shadow-lg"
          disabled={isSelecting}
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h3 className="text-lg font-bold text-[var(--text-primary)] flex-1 text-center">AI Type Advisor</h3>
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="absolute right-0 rounded-full h-10 w-10 bg-[var(--secondary)] backdrop-blur-sm border border-[var(--border)] hover:bg-[var(--accent)] hover:border-[var(--primary)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all shadow-lg"
          disabled={isSelecting}
        >
          <span className="text-lg">×</span>
        </Button>
      </div>

      {step < 4 && !showSelectionConfirmation && ( // Only show step indicators if not on confirmation screen
        <div className="flex justify-center mb-4">
          <div className="flex gap-2">
            {[1, 2, 3].map((s) => (
              <motion.div
                key={s}
                className={`w-2 h-2 rounded-full transition-colors ${
                  s <= step ? 'bg-[var(--primary)]' : 'bg-slate-600'
                }`}
                initial={{ scale: 0.5 }}
                animate={{ scale: 1 }}
                transition={{ delay: s * 0.05 }}
              />
            ))}
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto custom-scrollbar -mr-2 pr-2">
        {renderContent()}
      </div>
    </motion.div>
  );
}
