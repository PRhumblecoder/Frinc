
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Rocket, Sparkles, ShieldCheck, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

const SUPPORT_FAQS = [
    {
        question: "How is frinc.ai free?",
        answer: "We provide the core service of filing your company formation documents for free. We make money through optional, add-on services like Registered Agent services, annual compliance, and expedited filing, which you can choose if you need them."
    },
    {
        question: "What are state filing fees?",
        answer: "These are mandatory fees that the state government charges to register your business. We pass this cost directly to you with zero markup. These fees vary from state to state."
    },
    {
        question: "Can I use frinc.ai if I live outside the U.S.?",
        answer: "Absolutely! 🌍 We're designed for global entrepreneurs. You can form a U.S. LLC or C-Corporation from anywhere in the world."
    },
    {
        question: "Do I need a Social Security Number (SSN)?",
        answer: "No, you do not need an SSN to form a company. However, you will likely need an Employer Identification Number (EIN) to open a U.S. bank account, which we can also help you obtain."
    },
    {
        question: "What's a Registered Agent and do I need one?",
        answer: "A Registered Agent is a designated person or entity that receives official legal and state documents on behalf of your business. Most states require you to have one in the state of formation. We offer this as an affordable add-on service."
    },
    {
        question: "How long does the incorporation process take?",
        answer: "It depends on the state. Some states are as fast as 1-2 business days, while others can take a few weeks. Our AI advisor provides real-time estimates during the setup process."
    },
    {
        question: "Can I check if my company name is available?",
        answer: "While we don't have a live name check, we recommend choosing a unique name. If the state rejects your chosen name, we will contact you to choose a new one at no extra cost."
    },
    {
        question: "What documents do I get after formation?",
        answer: "Once your company is approved by the state, you'll receive your official formation documents, such as the Articles of Organization (for LLCs) or Articles of Incorporation (for Corps), directly in your dashboard."
    },
    {
        question: "Does frinc.ai help with annual compliance?",
        answer: "Yes! We offer an annual compliance service to help you prepare and file your yearly state reports, ensuring your company remains in good standing with the state."
    },
    {
        question: "Is my data safe with frinc.ai?",
        answer: "Yes, we use industry-standard security measures, including encryption, to protect your personal information. You can read more in our Privacy Policy."
    }
];

export default function InfoScreen({ currentScreen, onBack }) {
  const [supportTicket, setSupportTicket] = useState({ name: '', email: '', message: '' });
  const [ticketSubmitted, setTicketSubmitted] = useState(false);
  const [expandedSupportFaq, setExpandedSupportFaq] = useState(null);

  const getTitle = () => {
    if (currentScreen === 'about') return "What's frinc.ai?";
    if (currentScreen === 'support') return "Support";
    if (currentScreen === 'legal') return "Legal & Stuff";
    return "";
  };

  const renderContent = () => {
    if (currentScreen === 'about') {
      return (
        <div className="space-y-4">
            <p>
                Tired of complicated paperwork and expensive lawyers? 😴 So were we!
            </p>
            <p>
                <span className="font-bold text-[var(--primary)]">frinc.ai</span> is your super-smart AI incorporation agent 🤖, designed to help entrepreneurs like you launch a U.S. business from anywhere in the world.🌍
            </p>
            <p>
                We believe starting a business should be exciting, not expensive. That's why our core service is <span className="font-bold text-[var(--primary)]">100% free</span>. You only pay the mandatory fees the state charges. No hidden costs, no confusing jargon—just a fast, simple path to your American dream. ✨
            </p>
            <ul className="space-y-3 mt-4">
                <li className="flex items-start gap-3">
                    <Rocket className="w-5 h-5 text-[var(--primary)] mt-0.5 flex-shrink-0" />
                    <span><span className="font-semibold text-[var(--text-primary)]">Launch Fast:</span> Get your company filed in minutes, not weeks.</span>
                </li>
                <li className="flex items-start gap-3">
                    <Sparkles className="w-5 h-5 text-[var(--primary)] mt-0.5 flex-shrink-0" />
                    <span><span className="font-semibold text-[var(--text-primary)]">AI-Powered Advice:</span> Our AI helps you choose the best state and company type for your needs.</span>
                </li>
                <li className="flex items-start gap-3">
                    <ShieldCheck className="w-5 h-5 text-[var(--primary)] mt-0.5 flex-shrink-0" />
                    <span><span className="font-semibold text-[var(--text-primary)]">Totally Free:</span> We don't charge a dime for our formation service. Seriously.</span>
                </li>
            </ul>
        </div>
      );
    }

    if (currentScreen === 'support') {
      return (
        <div className="space-y-6">
            <div>
                <h4 className="font-bold text-[var(--text-primary)] mb-2">Submit a Support Ticket</h4>
                {ticketSubmitted ? (
                    <div className="bg-green-500/20 border border-green-500/50 text-green-200 p-3 rounded-lg text-center">
                        <p className="font-semibold">Thank you!</p>
                        <p className="text-xs">Your ticket has been submitted. We'll get back to you soon.</p>
                    </div>
                ) : (
                    <form onSubmit={(e) => { e.preventDefault(); setTicketSubmitted(true); }} className="space-y-3">
                        <Input 
                            placeholder="Your Name" 
                            className="bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] rounded-lg placeholder:text-[var(--muted-foreground)]"
                            value={supportTicket.name}
                            onChange={(e) => setSupportTicket({...supportTicket, name: e.target.value})}
                            required
                        />
                        <Input 
                            type="email" 
                            placeholder="Your Email" 
                            className="bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] rounded-lg placeholder:text-[var(--muted-foreground)]"
                            value={supportTicket.email}
                            onChange={(e) => setSupportTicket({...supportTicket, email: e.target.value})}
                            required
                        />
                        <Textarea 
                            placeholder="How can we help?" 
                            className="bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] rounded-lg placeholder:text-[var(--muted-foreground)] h-24"
                            value={supportTicket.message}
                            onChange={(e) => setSupportTicket({...supportTicket, message: e.target.value})}
                            required
                        />
                        <Button type="submit" className="w-full bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-30 transition-opacity">Submit Ticket</Button>
                    </form>
                )}
            </div>
            <div>
                <h4 className="font-bold text-[var(--text-primary)] mb-3 mt-4">Frequently Asked Questions</h4>
                <div className="space-y-2">
                    {SUPPORT_FAQS.map((faq, index) => (
                        <div key={index} className="bg-[var(--card-foreground)] border border-[var(--border)] rounded-lg overflow-hidden">
                            <button
                                className="w-full text-left p-3 flex justify-between items-center hover:bg-[var(--secondary)]"
                                onClick={() => setExpandedSupportFaq(expandedSupportFaq === index ? null : index)}
                            >
                                <span className="font-semibold text-[var(--text-primary)]">{faq.question}</span>
                                <ChevronLeft className={`w-5 h-5 transition-transform text-[var(--text-secondary)] ${expandedSupportFaq === index ? '-rotate-90' : ''}`} />
                            </button>
                            <AnimatePresence>
                                {expandedSupportFaq === index && (
                                    <motion.div
                                        initial={{ height: 0, opacity: 0 }}
                                        animate={{ height: 'auto', opacity: 1 }}
                                        exit={{ height: 0, opacity: 0 }}
                                        className="overflow-hidden"
                                    >
                                        <div className="p-3 pt-0 text-[var(--text-secondary)]">
                                            <p>{faq.answer}</p>
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      );
    }

    if (currentScreen === 'legal') {
      return (
        <div className="space-y-6">
            <div>
                <h4 className="font-bold text-[var(--text-primary)] mb-2">Frinc.ai Terms of Service</h4>
                <p className="italic mb-2">Last Updated: July 22, 2025</p>
                <p className="mb-2">Welcome to frinc.ai! These Terms of Service ("Terms") govern your access to and use of the frinc.ai website, products, and services (collectively, the "Service"). By accessing or using the Service, you agree to be bound by these Terms.</p>
                
                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">1. Acceptance of Terms</h5>
                <p>By creating an account, accessing, or using the Service, you signify your agreement to these Terms and our Privacy Policy. If you do not agree to these Terms, you may not access or use the Service.</p>
                
                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">2. Nature of Service and Disclaimers</h5>
                <p className="mb-1">2.1. No Legal or Tax Advice: The information and tools provided by frinc.ai are for informational and general guidance purposes only. We do not provide legal, tax, financial, or any other professional advice. You should not rely on any information obtained from frinc.ai as a substitute for professional advice. Always consult with a qualified professional for specific advice tailored to your situation.</p>
                <p>2.2. Accuracy and Professional Verification: While frinc.ai strives to provide accurate and helpful information, our service may contain errors, inaccuracies, or omissions. Artificial intelligence and automated systems can make mistakes. Therefore, users should always double-check any information, calculations, or recommendations provided by frinc.ai with a qualified professional before making any decisions or taking any actions. Frinc.ai is not responsible for any decisions made or actions taken based on the information provided by the Service without independent professional verification.</p>
                
                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">3. User Accounts</h5>
                <p>To access certain features of the Service, you may need to register for an account. You agree to: Provide accurate, current, and and complete information during the registration process. Maintain the security of your password and identification. Notify frinc.ai immediately of any unauthorized use of your account. Be responsible for all activities that occur under your account.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">4. User Conduct</h5>
                <p>You agree not to use the Service to: Violate any applicable laws or regulations. Infringe upon the rights of others. Transmit any harmful, threatening, defamatory, obscene, or otherwise objectionable content. Engage in any activity that could damage, disable, overburden, or impair the Service.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">5. Intellectual Property</h5>
                <p>All content, features, and functionality on the Service, including but not limited to text, graphics, logos, and software, are the exclusive property of frinc.ai and its licensors and are protected by intellectual property laws.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">6. Termination</h5>
                <p>We may terminate or suspend your access to the Service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">7. Limitation of Liability</h5>
                <p>To the fullest extent permitted by applicable law, in no event shall frinc.ai, its affiliates, directors, employees, or agents be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from (i) your access to or use of or inability to access or use the Service; (iii) any content obtained from the Service; and (iv) unauthorized access, use or alteration of your transmissions or content, whether based on warranty, contract, tort (including negligence) or any other legal theory, whether or not we have been informed of the possibility of such damage.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">8. Governing Law</h5>
                <p>These Terms shall be governed and construed in accordance with the laws of the State of New York, United States, without regard to its conflict of law provisions.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">9. Changes to Terms</h5>
                <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, we will try to provide at least 30 days' notice prior to any new terms taking effect. By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">10. Contact Us</h5>
                <p>If you have any questions about these Terms, please contact us: Company Name: frinc.ai, Address: 1820 Ave M #1079, Brooklyn NY 11230, Email: team@frinc.ai</p>
            </div>

            <div className="pt-6 border-t border-[var(--border)]">
                <h4 className="font-bold text-[var(--text-primary)] mb-2">Frinc.ai Privacy Policy</h4>
                <p className="italic mb-2">Last Updated: July 22, 2025</p>
                <p className="mb-2">Frinc.ai ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website frinc.ai and use our services (collectively, the "Service"). Please read this Privacy Policy carefully. If you do not agree with the terms of this Privacy Policy, please do not access the Service.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">1. Information We Collect</h5>
                <p className="mb-1">We may collect information about you in a variety of ways. The information we may collect via the Service depends on the content and materials you use, and includes:</p>
                <p className="mb-1">1.1. Personal Data: Personally identifiable information, such as your name, email address, and any other information you voluntarily give to us when you register with the Service or when you choose to participate in various activities related to the Service.</p>
                <p className="mb-1">1.2. Derivative Data: Information our servers automatically collect when you access the Service, such as your IP address, your browser type, your operating system, your access times, and the pages you have viewed directly before and after accessing the Service.</p>
                <p>1.3. Data from Contests, Giveaways, and Surveys: Personal and other information you may provide when entering contests or giveaways and/or responding to surveys.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">2. How We Use Your Information</h5>
                <p>Having accurate information about you permits us to provide you with a smooth, efficient, and customized experience. Specifically, we may use information collected about you via the Service to: Create and manage your account. Email you regarding your account or order. Enable user-to-user communications. Generate a personal profile about you to make your visit to the Service more personalized. Monitor and analyze usage and trends to improve your experience with the Service. Notify you of updates to the Service. Perform other business activities as needed.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">3. Disclosure of Your Information</h5>
                <p className="mb-1">We may share information we have collected about you in certain situations. Your information may be disclosed as follows:</p>
                <p className="mb-1">3.1. By Law or to Protect Rights: If we believe the release of information about you is necessary to respond to legal process, to investigate or remedy potential violations of our policies, or to protect the rights, property, and safety of others, we may share your information as permitted or required by any applicable law, rule, or regulation.</p>
                <p className="mb-1">3.2. Third-Party Service Providers: We may share your information with third parties that perform services for us or on our behalf, including data analysis, email delivery, hosting services, customer service, and marketing assistance.</p>
                <p>3.3. Marketing Communications: With your consent, or with an opportunity for you to withdraw consent, we may share your information with third parties for marketing purposes, as permitted by law.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">4. Security of Your Information</h5>
                <p>We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">5. Policy for Children</h5>
                <p>We do not knowingly solicit information from or market to children under the age of 13. If you become aware of any data we have collected from children under age 13, please contact us using the contact information provided below.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">6. Changes to This Privacy Policy</h5>
                <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.</p>

                <h5 className="font-semibold text-[var(--text-primary)] mt-3 mb-1">7. Contact Us</h5>
                <p>If you have questions or comments about this Privacy Policy, please contact us: Company Name: frinc.ai, Address: 1820 Ave M #1079, Brooklyn NY 11230, Email: team@frinc.ai</p>
            </div>
        </div>
      );
    }
  };

  return (
    <motion.div
        key={currentScreen}
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 50 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="h-full flex flex-col p-6 text-[var(--text-primary)] bg-[var(--background)]"
    >
        <div className="flex-shrink-0 flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-[var(--text-primary)]">{getTitle()}</h3>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onBack} 
              className="bg-[var(--secondary)] backdrop-blur-sm border border-[var(--border)] hover:bg-[var(--accent)] hover:border-[var(--primary)] rounded-full h-10 w-10 text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all"
            >
                <X className="h-5 w-5" />
            </Button>
        </div>
        <div className="text-[var(--text-primary)] text-base prose prose-sm max-w-none overflow-y-auto custom-scrollbar pr-2 prose-p:text-[var(--text-primary)] prose-h4:text-[var(--text-primary)] prose-h5:text-[var(--text-primary)] prose-strong:text-[var(--text-primary)] prose-ul:text-[var(--text-primary)]">
            {renderContent()}
        </div>
    </motion.div>
  );
}
