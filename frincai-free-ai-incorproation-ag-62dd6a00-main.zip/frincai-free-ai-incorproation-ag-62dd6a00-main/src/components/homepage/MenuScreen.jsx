
import React from 'react';
import { motion } from 'framer-motion';
import { X, Globe, Info, Landmark, ShieldCheck, Building, LogOut, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User as UserEntity } from '@/api/entities';

export default function MenuScreen({ onBack, onNavigate, user, onLogout }) {
  const handleLogin = async () => {
    // Redirect to login, and then to the dashboard after successful login
    await UserEntity.loginWithRedirect(window.location.origin + createPageUrl('Dashboard'));
  };

  const modes = [
    {
      id: 'fun',
      name: 'Fun',
      icon: '😊',
      description: 'Playful colors and animations'
    },
    {
      id: 'light',
      name: 'Light',
      icon: '☀️',
      description: 'Clean and professional'
    },
    {
      id: 'dark',
      name: 'Dark',
      icon: '🌙',
      description: 'Easy on the eyes'
    },
    {
      id: 'ai',
      name: 'AI',
      icon: '🤖',
      description: 'Futuristic cyber theme'
    },
    {
      id: 'bling',
      name: 'Bling',
      icon: '💰',
      description: 'Gold and luxury vibes'
    }
  ];

  return (
    <motion.div
      key="menu"
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="h-full flex flex-col p-6 text-[var(--text-primary)] bg-[var(--background)]"
    >
      <div className="flex-shrink-0 flex items-center justify-between mb-8">
        <h3 className="text-xl font-bold text-[var(--text-primary)]">Menu</h3>
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="bg-[var(--secondary)] border border-[var(--border)] hover:bg-[var(--accent)] rounded-full h-10 w-10 text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-all"
        >
          <X className="h-6 w-6" />
        </Button>
      </div>
      <div className="flex flex-col gap-2 flex-grow">
        <Button variant="ghost" className="justify-start text-[var(--text-primary)] hover:bg-[var(--accent)] text-base p-3" onClick={() => onNavigate('welcome')}>
          <Globe className="w-5 h-5 mr-3 text-[var(--primary)]"/> Home
        </Button>
        <Button variant="ghost" className="justify-start text-[var(--text-primary)] hover:bg-[var(--accent)] text-base p-3" onClick={() => onNavigate('states')}>
          <Building className="w-5 h-5 mr-3 text-[var(--primary)]"/> New Company
        </Button>
        <Button variant="ghost" className="justify-start text-[var(--text-primary)] hover:bg-[var(--accent)] text-base p-3" onClick={() => onNavigate('about')}>
          <Info className="w-5 h-5 mr-3 text-[var(--primary)]"/> What's frinc.ai?
        </Button>
        <Button variant="ghost" className="justify-start text-[var(--text-primary)] hover:bg-[var(--accent)] text-base p-3" onClick={() => onNavigate('support')}>
          <Landmark className="w-5 h-5 mr-3 text-[var(--primary)]"/> Support
        </Button>
        <Button variant="ghost" className="justify-start text-[var(--text-primary)] hover:bg-[var(--accent)] text-base p-3" onClick={() => onNavigate('legal')}>
          <ShieldCheck className="w-5 h-5 mr-3 text-[var(--primary)]"/> Legal & Stuff
        </Button>
        {user && (
          <Link to={createPageUrl('Dashboard')}>
             <Button variant="ghost" className="w-full justify-start text-[var(--text-primary)] hover:bg-[var(--accent)] text-base p-3">
                <Building className="w-5 h-5 mr-3 text-[var(--primary)]"/> Dashboard
            </Button>
          </Link>
        )}
      </div>
      <div className="flex-shrink-0 mt-4">
         {user ? (
          <Button onClick={onLogout} variant="outline" className="w-full border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]">
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        ) : (
          <Button onClick={handleLogin} className="w-full bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-30 transition-opacity">
            <LogIn className="w-4 h-4 mr-2" />
            Login or Sign Up
          </Button>
        )}
      </div>
    </motion.div>
  );
}
