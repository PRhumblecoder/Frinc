import React from 'react';
import { motion } from 'framer-motion';
import { Building, Globe, ArrowRight, BadgePercent, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function WelcomeScreen({ onStart }) {
  return (
    <motion.div
      key="welcome-professional"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="h-full flex flex-col justify-between items-center p-6 text-[var(--text-primary)] bg-[var(--background)]"
    >
      <div className="w-full text-center">
        <h1 className="text-3xl font-bold tracking-tight text-[var(--text-primary)] leading-tight">
          Open Your U.S. Company with <span className="text-[var(--primary)]">AI</span>
        </h1>
        <p className="mt-3 text-base text-[var(--text-secondary)]">
          The free, fast, and intelligent way to launch your business.
        </p>
      </div>

      <div className="w-full grid grid-cols-2 gap-4 my-6">
        <div className="bg-[var(--card-foreground)] border border-[var(--border)] rounded-[var(--radius)] p-4 flex flex-col items-center justify-center text-center h-[120px]">
          <BadgePercent className="w-7 h-7 text-[var(--primary)] mb-2" />
          <p className="font-semibold text-sm text-[var(--text-primary)]">100% FREE</p>
          <p className="text-xs text-[var(--text-secondary)] mt-1">No Service Fees</p>
        </div>
        
        <div className="bg-[var(--card-foreground)] border border-[var(--border)] rounded-[var(--radius)] p-4 flex flex-col items-center justify-center text-center h-[120px]">
          <Clock className="w-7 h-7 text-[var(--primary)] mb-2" />
          <p className="font-semibold text-sm text-[var(--text-primary)]">IN MINUTES</p>
          <p className="text-xs text-[var(--text-secondary)] mt-1">Fast AI Process</p>
        </div>
        
        <div className="bg-[var(--card-foreground)] border border-[var(--border)] rounded-[var(--radius)] p-4 flex flex-col items-center justify-center text-center h-[120px]">
          <Building className="w-7 h-7 text-[var(--primary)] mb-2" />
          <p className="font-semibold text-sm text-[var(--text-primary)]">All Types</p>
          <p className="text-xs text-[var(--text-secondary)] mt-1">LLC & INC</p>
        </div>
        
        <div className="bg-[var(--card-foreground)] border border-[var(--border)] rounded-[var(--radius)] p-4 flex flex-col items-center justify-center text-center h-[120px]">
          <Globe className="w-7 h-7 text-[var(--primary)] mb-2" />
          <p className="font-semibold text-sm text-[var(--text-primary)]">50 States</p>
          <p className="text-xs text-[var(--text-secondary)] mt-1">Full Support</p>
        </div>
      </div>

       <Button 
        size="lg" 
        onClick={onStart} 
        className="group relative w-full mt-6 bg-[var(--primary)] text-[var(--primary-foreground)] rounded-[var(--radius)] py-6 text-base font-bold shadow-lg transition-all overflow-hidden"
      >
        <span className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity duration-200"></span>
        <span className="relative flex items-center justify-center">
          Start Now
          <ArrowRight className="w-5 h-5 ml-2" />
        </span>
      </Button>
    </motion.div>
  );
}