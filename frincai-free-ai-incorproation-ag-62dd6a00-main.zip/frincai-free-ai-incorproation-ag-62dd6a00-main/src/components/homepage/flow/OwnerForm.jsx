import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useForm, Controller } from 'react-hook-form';

// Import from the correct path
const COUNTRIES = ['USA', 'Canada', 'United Kingdom', 'Australia', 'Germany', 'France', 'Other'];

const US_STATES_OPTIONS = [
  'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
];

const US_STATES = US_STATES_OPTIONS; // Alias for backward compatibility with existing state logic using US_STATES

export default function OwnerForm({ onBack, onSave, ownerData, isManager, isOrganizer = false, companyData }) {
  const { control, handleSubmit, watch, setValue, reset, formState: { isValid, errors } } = useForm({
    mode: 'onChange',
    defaultValues: ownerData || {
      firstName: '', middleName: '', lastName: '', streetAddress: '', suite: '',
      city: '', state: '', zipCode: '', country: 'USA', ownershipPercent: '',
      titles: [] // Add titles to default values
    }
  });

  const [stateInput, setStateInput] = useState('');
  const [showStateSuggestions, setShowStateSuggestions] = useState(false);
  
  const isManagerOnlyMode = isManager; // Keeping this for consistency with existing manager logic

  const formData = watch();

  useEffect(() => {
    reset(ownerData);
    setStateInput(ownerData?.state || '');
  }, [ownerData, reset]);

  const stateAbbreviations = {
      'ny': 'new york', 'ca': 'california', 'tx': 'texas', 'fl': 'florida', 'il': 'illinois',
      'pa': 'pennsylvania', 'oh': 'ohio', 'ga': 'georgia', 'nc': 'north carolina', 'mi': 'michigan',
      'nj': 'new jersey', 'va': 'virginia', 'wa': 'washington', 'az': 'arizona', 'ma': 'massachusetts',
      'tn': 'tennessee', 'in': 'indiana', 'mo': 'missouri', 'md': 'maryland', 'wi': 'wisconsin',
      'co': 'colorado', 'mn': 'minnesota', 'sc': 'south carolina', 'al': 'alabama', 'la': 'louisiana',
      'ky': 'kentucky', 'or': 'oregon', 'ok': 'oklahoma', 'ct': 'connecticut', 'ut': 'utah',
      'ia': 'iowa', 'nv': 'nevada', 'ar': 'arkansas', 'ms': 'mississippi', 'ks': 'kansas',
      'nm': 'new mexico', 'ne': 'nebraska', 'wv': 'west virginia', 'id': 'idaho', 'hi': 'hawaii',
      'nh': 'new hampshire', 'me': 'maine', 'ri': 'rhode island', 'mt': 'montana', 'de': 'delaware',
      'sd': 'south dakota', 'nd': 'north dakota', 'ak': 'alaska', 'vt': 'vermont', 'wy': 'wyoming'
  };

  const filteredStates = US_STATES.filter(state => {
    if (!stateInput) return false;
    const searchTerm = stateInput.toLowerCase();
    const stateName = state.toLowerCase();
    const fullStateFromAbbr = stateAbbreviations[searchTerm];
    
    if (stateName.startsWith(searchTerm)) {
      return true;
    }
    
    if (fullStateFromAbbr && stateName === fullStateFromAbbr) {
      return true;
    }
    
    return false;
  });

  const handleStateInputChange = (e, field) => {
    const val = e.target.value;
    setStateInput(val);
    
    const lowerVal = val.toLowerCase();
    const fullStateFromAbbr = stateAbbreviations[lowerVal];

    const potentialMatches = US_STATES.filter(state => {
        const stateLower = state.toLowerCase();
        // Match if state STARTS with the search term
        if (stateLower.startsWith(lowerVal)) {
            return true;
        }
        // Match if the search term is an exact abbreviation for the state
        if (fullStateFromAbbr && stateLower === fullStateFromAbbr) {
            return true;
        }
        return false;
    });

    if (potentialMatches.length === 1 && val.length > 0) {
        // If there's exactly one match, auto-select it
        const singleMatch = potentialMatches[0];
        setStateInput(singleMatch);
        field.onChange(singleMatch);
        setShowStateSuggestions(false);
    } else {
        // Otherwise, update the field and show suggestions
        field.onChange(val);
        setShowStateSuggestions(val.length > 0);
    }
  };

  return (
    <motion.div
      key="owner_form"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="h-full flex flex-col bg-[var(--background)]"
    >
      <div className="flex-shrink-0 flex items-center justify-center p-6 relative">
        <Button variant="ghost" size="icon" onClick={onBack} className="rounded-full h-10 w-10 text-[var(--text-secondary)] hover:bg-[var(--secondary)] absolute left-0">
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h3 className="text-lg font-bold text-[var(--text-primary)]">
          {isOrganizer ? 'Organizer Information' : (isManager ? 'Manager Information' : 'Owner Information')}
        </h3>
      </div>

      <form onSubmit={handleSubmit(onSave)} className="flex-1 flex flex-col min-h-0">
        <div className="flex-1 overflow-y-auto px-6 custom-scrollbar">
          <div className="flex flex-col gap-4">
            <div>
              <Label htmlFor="firstName" className="text-[var(--text-secondary)]">First Name *</Label>
              <Controller
                name="firstName"
                control={control}
                rules={{ required: "First name is required." }}
                render={({ field }) => (
                  <Input id="firstName" {...field} className={`bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] ${errors.firstName ? 'border-red-500 ring-1 ring-red-500' : ''}`} />
                )}
              />
              {errors.firstName && <p className="text-red-500 text-xs mt-1">{errors.firstName.message}</p>}
            </div>
            <div>
              <Label htmlFor="middleName" className="text-[var(--text-secondary)]">Middle Name</Label>
              <Controller
                name="middleName"
                control={control}
                render={({ field }) => (
                  <Input id="middleName" {...field} className="bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)]" />
                )}
              />
            </div>
            <div>
              <Label htmlFor="lastName" className="text-[var(--text-secondary)]">Last Name *</Label>
              <Controller
                name="lastName"
                control={control}
                rules={{ required: "Last name is required." }}
                render={({ field }) => (
                  <Input id="lastName" {...field} className={`bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] ${errors.lastName ? 'border-red-500 ring-1 ring-red-500' : ''}`} />
                )}
              />
              {errors.lastName && <p className="text-red-500 text-xs mt-1">{errors.lastName.message}</p>}
            </div>
            {/* Address fields - keeping existing Controller based implementation */}
            <div>
              <Label htmlFor="streetAddress" className="text-[var(--text-secondary)]">Street Address *</Label>
              <Controller
                name="streetAddress"
                control={control}
                rules={{ required: "Street address is required." }}
                render={({ field }) => (
                  <Input id="streetAddress" {...field} className={`bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] ${errors.streetAddress ? 'border-red-500 ring-1 ring-red-500' : ''}`} />
                )}
              />
              {errors.streetAddress && <p className="text-red-500 text-xs mt-1">{errors.streetAddress.message}</p>}
            </div>
            <div>
              <Label htmlFor="suite" className="text-[var(--text-secondary)]">Apt/Suite</Label>
              <Controller
                name="suite"
                control={control}
                render={({ field }) => (
                  <Input id="suite" {...field} className="bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)]" />
                )}
              />
            </div>
            <div>
              <Label htmlFor="city" className="text-[var(--text-secondary)]">City *</Label>
              <Controller
                name="city"
                control={control}
                rules={{ required: "City is required." }}
                render={({ field }) => (
                  <Input id="city" {...field} className={`bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] ${errors.city ? 'border-red-500 ring-1 ring-500' : ''}`} />
                )}
              />
              {errors.city && <p className="text-red-500 text-xs mt-1">{errors.city.message}</p>}
            </div>
            <div>
              <Label htmlFor="country" className="text-[var(--text-secondary)]">Country *</Label>
              <Controller
                name="country"
                control={control}
                rules={{ required: "Country is required." }}
                render={({ field }) => (
                  <Select onValueChange={field.onChange} value={field.value}>
                    <SelectTrigger className={`w-full bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] ${errors.country ? 'border-red-500 ring-1 ring-red-500' : ''}`}><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-[var(--popover)] border-[var(--border)] text-[var(--popover-foreground)]">{COUNTRIES.map(c => <SelectItem key={c} value={c} className="focus:bg-[var(--accent)]">{c}</SelectItem>)}</SelectContent>
                  </Select>
                )}
              />
              {errors.country && <p className="text-red-500 text-xs mt-1">{errors.country.message}</p>}
            </div>
            {formData.country === 'USA' && (
              <Controller
                name="state"
                control={control}
                rules={{
                  required: "State is required",
                  validate: (value) =>
                    US_STATES_OPTIONS.includes(value) || "Please select a valid state from the list.", // Using US_STATES_OPTIONS
                }}
                render={({ field }) => {
                  const handleStateSelect = (state) => {
                    setStateInput(state);
                    field.onChange(state);
                    setShowStateSuggestions(false);
                  };

                  return (
                    <div className="relative">
                      <Label htmlFor="state" className="text-[var(--text-secondary)]">State *</Label>
                      <Input
                        id="state"
                        {...field}
                        value={stateInput}
                        onChange={(e) => handleStateInputChange(e, field)}
                        onFocus={() => setShowStateSuggestions(true)}
                        onBlur={() => {
                          field.onBlur();
                          setTimeout(() => setShowStateSuggestions(false), 150);
                        }}
                        className={`bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] ${errors.state ? 'border-red-500 ring-1 ring-red-500' : ''}`}
                        placeholder="Type state name or abbreviation..."
                        autoComplete="off"
                      />
                      {showStateSuggestions && (
                        <div className="absolute top-full left-0 right-0 bg-[var(--card)] border border-[var(--border)] rounded-md mt-1 max-h-32 overflow-y-auto z-10 shadow-lg">
                          {filteredStates.length > 0 ? (
                            filteredStates.slice(0, 5).map(state => (
                              <div
                                key={state}
                                className="px-3 py-2 hover:bg-[var(--secondary)] cursor-pointer text-[var(--text-primary)] text-sm"
                                onMouseDown={() => handleStateSelect(state)}
                              >
                                {state}
                              </div>
                            ))
                          ) : (
                            <div className="px-3 py-2 text-xs text-center text-[var(--text-secondary)]">
                              No matching state found.
                            </div>
                          )}
                        </div>
                      )}
                      {errors.state && <p className="text-red-500 text-xs mt-1">{errors.state.message}</p>}
                    </div>
                  );
                }}
              />
            )}
            <div>
              <Label htmlFor="zipCode" className="text-[var(--text-secondary)]">Zip/Postal Code *</Label>
              <Controller
                name="zipCode"
                control={control}
                rules={{ required: "Zip/Postal code is required." }}
                render={({ field }) => (
                  <Input id="zipCode" {...field} className={`bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] ${errors.zipCode ? 'border-red-500 ring-1 ring-red-500' : ''}`} />
                )}
              />
              {errors.zipCode && <p className="text-red-500 text-xs mt-1">{errors.zipCode.message}</p>}
            </div>
            
            {!(isManager || isOrganizer) && ( // Show ownership percent only if neither manager nor organizer
              <div className="space-y-2">
                <Label htmlFor="ownershipPercent" className="text-sm font-medium text-[var(--text-secondary)]">Ownership Percentage (%) *</Label>
                <Controller
                  name="ownershipPercent"
                  control={control}
                  rules={{ required: "Ownership % is required.", min: { value: 0.01, message: "Must be greater than 0."}, max: { value: 100, message: "Cannot exceed 100."} }}
                  render={({ field }) => (
                    <Input id="ownershipPercent" type="number" {...field} className={`bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] ${errors.ownershipPercent ? 'border-red-500 ring-1 ring-red-500' : ''}`} />
                  )}
                />
                {errors.ownershipPercent && <p className="text-red-500 text-xs mt-1">{errors.ownershipPercent.message}</p>}
              </div>
            )}

            {isManagerOnlyMode && (companyData?.type === 'inc' || companyData?.type === 'scorp') && (
              <div className="space-y-2">
                <Label htmlFor="titles" className="text-sm font-medium text-[var(--text-secondary)]">Management Titles *</Label>
                <div className="text-xs text-[var(--text-secondary)] mb-2">Select one or more titles for this manager:</div>
                <Controller
                  name="titles"
                  control={control}
                  rules={{
                    required: "Please select at least one title for the manager.",
                    validate: (value) => (value && value.length > 0) || "Please select at least one title."
                  }}
                  render={({ field }) => (
                    <div className="grid grid-cols-2 gap-2">
                      {['President', 'Vice President', 'Secretary', 'Treasurer', 'CEO', 'CFO', 'COO'].map(title => (
                        <div key={title} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={title}
                            value={title}
                            checked={field.value.includes(title)}
                            onChange={(e) => {
                              const newTitles = e.target.checked
                                ? [...field.value, title]
                                : field.value.filter(t => t !== title);
                              field.onChange(newTitles);
                            }}
                            className="rounded border-[var(--border)] h-4 w-4 text-[var(--primary)] focus:ring-[var(--primary)] focus:ring-2 bg-[var(--secondary)]"
                          />
                          <label htmlFor={title} className="text-sm text-[var(--text-primary)] cursor-pointer">{title}</label>
                        </div>
                      ))}
                    </div>
                  )}
                />
                {errors.titles && <p className="text-red-500 text-xs mt-1">{errors.titles.message}</p>}
              </div>
            )}
          </div>
        </div>

        <div className="flex-shrink-0 p-6 pt-4">
          <Button
            type="submit"
            disabled={!isValid}
            className="w-full bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)] hover:opacity-30 transition-opacity disabled:bg-[var(--muted)] disabled:text-[var(--muted-foreground)] disabled:cursor-not-allowed rounded-lg py-3 text-base font-bold"
          >
            {isOrganizer ? 'Save Organizer' : (isManager ? 'Save Manager' : 'Save Owner')}
          </Button>
        </div>
      </form>
    </motion.div>
  );
}