
import React from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Users, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ManagersList({ 
    onBack, 
    onContinue, 
    managers, 
    companyName,
    user
}) {
  return (
    <motion.div
      key="managers_list"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="h-full flex flex-col p-6 text-center bg-[var(--background)]"
    >
      <div className="flex-shrink-0 flex items-center justify-center mb-4 relative">
        <Button variant="ghost" size="icon" onClick={onBack} className="rounded-full h-10 w-10 text-[var(--text-secondary)] hover:bg-[var(--secondary)] absolute left-0">
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h3 className="text-lg font-bold text-[var(--text-primary)]">Company Managers</h3>
      </div>
      <p className="text-sm text-[var(--text-secondary)] mb-4">
        Review the managers of {companyName}.
      </p>

      <div className="flex-1 overflow-y-auto custom-scrollbar pr-1 mb-4">
        {managers.length === 0 ? (
          <div className="text-center text-[var(--text-secondary)] py-10">
            <Users className="mx-auto w-12 h-12 mb-4" />
            <p>No managers selected. <br /> Owners will manage the company.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {managers.map((manager, index) => (
              <div key={index} className="bg-[var(--card-foreground)] border border-[var(--border)] rounded-xl p-3 text-left">
                <p className="font-semibold text-[var(--text-primary)]">{manager.firstName} {manager.lastName}</p>
                <p className="text-sm text-[var(--text-secondary)]">Manager • {manager.ownershipPercent}% Ownership</p>
                {manager.titles && manager.titles.length > 0 && (
                  <p className="text-xs text-[var(--muted-foreground)] mt-1">Titles: {manager.titles.join(', ')}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="flex-shrink-0 space-y-4">
        <Button 
          onClick={onContinue}
          className="w-full bg-gradient-to-r from-emerald-500 to-green-600 text-white font-semibold hover:opacity-30 transition-opacity"
        >
          {user ? (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Launch Company
            </>
          ) : (
            'Signup & Launch Company'
          )}
        </Button>
      </div>
    </motion.div>
  );
}
