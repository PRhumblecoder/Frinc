
import React from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, User, Plus, Trash2, Edit, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function OwnersList({ 
    onBack, 
    onContinue, 
    owners, 
    onEditOwner, 
    onDeleteOwner, 
    onAddNewOwner,
    companyName 
}) {
  const totalOwnership = owners.reduce((acc, owner) => acc + (parseFloat(owner.ownershipPercent) || 0), 0);

  return (
    <motion.div
      key="owners_list"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="h-full flex flex-col p-6 text-center bg-[var(--background)]"
    >
      <div className="flex-shrink-0 flex items-center justify-center mb-4 relative">
        <Button variant="ghost" size="icon" onClick={onBack} className="rounded-full h-10 w-10 text-[var(--text-secondary)] hover:bg-[var(--secondary)] absolute left-0">
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h3 className="text-lg font-bold text-[var(--text-primary)]">Company Owners</h3>
      </div>
      <p className="text-sm text-[var(--text-secondary)] mb-4">
        Add the owners of {companyName || 'your company'}. Total ownership must equal 100%.
      </p>

      <div className="flex-1 overflow-y-auto custom-scrollbar -mr-2 pr-2 mb-4">
        {owners.length === 0 ? (
          <div className="text-center text-[var(--text-secondary)] py-10 flex flex-col items-center">
            <User className="mx-auto w-12 h-12 text-[var(--primary)] opacity-50 mb-4" />
            <p className="text-[var(--text-secondary)]">No owners added yet. <br /> Add the first owner to get started.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {owners.map((owner, index) => (
              <div key={index} className="bg-[var(--secondary)] border border-[var(--border)] rounded-[var(--radius)] p-3 text-left flex justify-between items-center">
                <div>
                  <p className="font-semibold text-[var(--text-primary)]">{owner.firstName} {owner.lastName}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-sm text-[var(--text-secondary)]">{owner.ownershipPercent}% Ownership</p>
                    {owner.isManager && <span className="text-xs font-medium bg-green-500/20 text-green-500 px-2 py-0.5 rounded-full">Manager</span>}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-[var(--text-secondary)] hover:text-[var(--text-primary)]" onClick={() => onEditOwner(index)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-[var(--text-secondary)] hover:text-red-500" onClick={() => onDeleteOwner(index)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="flex-shrink-0 space-y-3 mt-auto pt-2 border-t border-[var(--border)]">
         {totalOwnership !== 100 && owners.length > 0 && (
          <p className="text-xs text-orange-600 text-center">
            Total ownership is {totalOwnership}%. It must be exactly 100% to continue.
          </p>
        )}
        <Button onClick={onAddNewOwner} variant="outline" className="w-full border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]">
          <Plus className="w-4 h-4 mr-2" /> Add {owners.length > 0 ? 'Another' : 'an'} Owner
        </Button>
        
        <Button 
          onClick={onContinue}
          disabled={owners.length > 0 && totalOwnership !== 100}
          className="group relative w-full bg-[var(--primary)] text-[var(--primary-foreground)] transition-all disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden"
        >
          <span className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity duration-200"></span>
          <span className="relative flex items-center justify-center">
            Continue to Managers
            <ArrowRight className="w-4 h-4 ml-2" />
          </span>
        </Button>
      </div>
    </motion.div>
  );
}
