
import React from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Check, Sparkles, Rocket, Building, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function TypeSelector({
  onBack,
  onTypeSelect,
  onAIAdvisor,
  selectedState,
  selectedType,
  companyTypes
}) {
  return (
    <motion.div
      key="types"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="h-full flex flex-col p-6 text-center bg-[var(--background)]"
    >
      <div className="flex-shrink-0 flex items-center justify-center mb-6 relative">
        <Button variant="ghost" size="icon" onClick={onBack} className="rounded-full h-10 w-10 text-[var(--text-secondary)] hover:bg-[var(--secondary)] absolute left-0">
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h3 className="text-lg font-bold text-[var(--text-primary)]">Select Company Type</h3>
      </div>
      <p className="text-sm text-[var(--text-secondary)] mb-4">
        Choose the legal structure for your company in {selectedState}.
      </p>
      
      <div className="flex-1 flex flex-col gap-3 overflow-y-auto custom-scrollbar pr-1">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="relative bg-[var(--secondary)] border border-[var(--primary)] rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer hover:bg-[var(--card-foreground)] transition-all duration-200"
          onClick={onAIAdvisor}
        >
          <Sparkles className="w-6 h-6 text-[var(--primary)] mb-2" />
          <span className="text-sm font-bold text-[var(--primary)] mb-1">AI Type Advisor</span>
          <span className="text-xs text-[hsl(var(--primary)/0.8)] text-center">Get personalized recommendations</span>
        </motion.div>

        {companyTypes.map((type) => (
            <motion.div
                key={type.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: 0.1 }}
                className={`relative bg-[var(--card)] border border-[var(--border)] rounded-xl p-4 flex flex-col items-start text-left cursor-pointer hover:bg-[var(--secondary)] hover:border-[var(--primary)] transition-all duration-200 ${
                    selectedType === type.id ? 'border-[var(--primary)] ring-2 ring-[hsl(var(--primary)/0.5)]' : ''
                }`}
                onClick={() => onTypeSelect(type.id)}
            >
                <h4 className="text-lg font-semibold text-[var(--text-primary)] flex items-center gap-2">
                    {type.id === 'inc' && <Rocket className="w-5 h-5 text-[var(--primary)]" />}
                    {type.id === 'llc' && <Building className="w-5 h-5 text-[var(--primary)]" />}
                    {type.id === 'scorp' && <ShoppingCart className="w-5 h-5 text-[var(--primary)]" />}
                    {type.name}
                </h4>
                <p className="text-sm text-[var(--text-secondary)] mt-1">{type.description}</p>
                {selectedType === type.id && (
                    <Check className="absolute top-3 right-3 text-[var(--primary)] w-5 h-5" />
                )}
            </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
