
import React from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Check, Sparkles, Building, Rocket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const STATE_FEES = {
  'Delaware': { llc: 90, inc: 89 }, 'Wyoming': { llc: 100, inc: 100 }, 'Nevada': { llc: 425, inc: 425 }, 'New Mexico': { llc: 50, inc: 100 },
  'Florida': { llc: 125, inc: 70 }, 'Texas': { llc: 300, inc: 300 }, 'California': { llc: 70, inc: 100 }, 'New York': { llc: 200, inc: 125 },
  'Alabama': { llc: 100, inc: 100 }, 'Alaska': { llc: 250, inc: 250 }, 'Arizona': { llc: 50, inc: 60 }, 'Arkansas': { llc: 45, inc: 50 },
  'Colorado': { llc: 50, inc: 50 }, 'Connecticut': { llc: 120, inc: 250 }, 'Georgia': { llc: 100, inc: 100 }, 'Hawaii': { llc: 50, inc: 50 },
  'Idaho': { llc: 100, inc: 100 }, 'Illinois': { llc: 150, inc: 150 }, 'Indiana': { llc: 95, inc: 95 }, 'Iowa': { llc: 50, inc: 50 }, 'Kansas': { llc: 160, inc: 165 },
  'Kentucky': { llc: 40, inc: 40 }, 'Louisiana': { llc: 100, inc: 75 }, 'Maine': { llc: 175, inc: 145 }, 'Maryland': { llc: 100, inc: 120 },
  'Massachusetts': { llc: 500, inc: 275 }, 'Michigan': { llc: 50, inc: 60 }, 'Minnesota': { llc: 135, inc: 135 }, 'Mississippi': { llc: 50, inc: 50 },
  'Missouri': { llc: 50, inc: 58 }, 'Montana': { llc: 35, inc: 35 }, 'Nebraska': { llc: 100, inc: 60 }, 'New Hampshire': { llc: 100, inc: 100 },
  'New Jersey': { llc: 125, inc: 125 }, 'North Carolina': { llc: 125, inc: 125 }, 'North Dakota': { llc: 135, inc: 100 }, 'Ohio': { llc: 99, inc: 99 },
  'Oklahoma': { llc: 100, inc: 100 }, 'Oregon': { llc: 100, inc: 100 }, 'Pennsylvania': { llc: 125, inc: 125 }, 'Rhode Island': { llc: 150, inc: 230 },
  'South Carolina': { llc: 110, inc: 110 }, 'South Dakota': { llc: 150, inc: 150 }, 'Tennessee': { llc: 300, inc: 100 }, 'Utah': { llc: 54, inc: 54 },
  'Vermont': { llc: 125, inc: 125 }, 'Virginia': { llc: 100, inc: 50 }, 'Washington': { llc: 180, inc: 180 }, 'West Virginia': { llc: 100, inc: 50 },
  'Wisconsin': { llc: 130, inc: 100 }
};

export default function StateSelector({ 
  onBack, 
  onStateSelect, 
  onAIAdvisor, 
  selectedState, 
  stateSearch, 
  onSearchChange, 
  usStates,
  isEmbedded = false
}) {
  return (
    <motion.div
      key="states"
      initial={{ opacity: 0, x: isEmbedded ? 0 : 20, y: isEmbedded ? 10 : 0 }}
      animate={{ opacity: 1, x: 0, y: 0 }}
      exit={{ opacity: 0, x: isEmbedded ? 0 : -20, y: isEmbedded ? 10 : 0 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className={`h-full flex flex-col text-center bg-transparent ${!isEmbedded ? 'p-6 bg-[var(--background)]' : ''}`}
    >
      {isEmbedded ? (
        <div className="flex-shrink-0 flex items-center justify-start mb-2">
            <Button variant="ghost" size="sm" onClick={onBack} className="text-[var(--text-secondary)] hover:bg-[var(--secondary)]">
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back to options
            </Button>
        </div>
      ) : (
        <>
          <div className="flex-shrink-0 flex items-center justify-center mb-6 relative">
            <Button variant="ghost" size="icon" onClick={onBack} className="rounded-full h-10 w-10 text-[var(--text-secondary)] hover:bg-[var(--secondary)] absolute left-0">
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <h3 className="text-lg font-bold text-[var(--text-primary)]">Select State</h3>
          </div>
          <p className="text-sm text-[var(--text-secondary)] mb-4">
            Choose the state where you'd like to form your company.
          </p>
        </>
      )}

      <Input
        type="text"
        placeholder="Search state..."
        value={stateSearch}
        onChange={(e) => onSearchChange(e.target.value)}
        className="mb-4 bg-[var(--card)] border-[var(--border)] text-[var(--text-primary)] rounded-[var(--radius)] placeholder:text-[var(--muted-foreground)]"
      />

      <div className="flex-1 overflow-y-auto custom-scrollbar pr-1">
        <div className="grid grid-cols-1 gap-3 pb-4">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="col-span-1 relative bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 border-2 border-transparent rounded-[var(--radius)] p-4 flex flex-col items-center justify-center cursor-pointer transition-all duration-200"
            onClick={onAIAdvisor}
          >
            <Sparkles className="w-6 h-6 text-white mb-2" />
            <span className="text-sm font-bold text-white mb-1">AI State Advisor</span>
            <span className="text-xs text-blue-100 text-center">Get personalized recommendations</span>
          </motion.div>

          {usStates.filter(state => state.toLowerCase().includes(stateSearch.toLowerCase())).map((state) => (
            <motion.div
              key={state}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className={`relative bg-[var(--card)] border-2 rounded-[var(--radius)] p-3 flex items-center justify-between cursor-pointer hover:bg-[var(--secondary)] transition-all duration-200 ${
                selectedState === state ? 'border-[var(--primary)] ring-2 ring-[hsl(var(--primary)/0.3)] bg-[hsl(var(--primary)/0.1)]' : 'border-[var(--border)] hover:border-[var(--primary)]'
              }`}
              onClick={() => onStateSelect(state)}
            >
              <div className="flex flex-col items-start text-left">
                <span className="text-sm font-medium text-[var(--text-primary)]">{state}</span>
                {STATE_FEES[state] && (
                  <div className="text-xs text-[var(--text-secondary)] mt-2 space-y-1">
                    <div>
                      <span>State Fee: </span>
                      <span className="text-[var(--text-primary)] font-medium">LLC: ${STATE_FEES[state].llc}</span>
                      <span className="mx-1 text-[var(--muted-foreground)]">|</span>
                      <span className="text-[var(--text-primary)] font-medium">INC: ${STATE_FEES[state].inc}</span>
                    </div>
                    <div className="text-[var(--primary)] font-semibold">
                      AI Agent Fee: $0 (100% Free)
                    </div>
                  </div>
                )}
              </div>
              {selectedState === state && (
                <Check className="text-[var(--primary)] w-5 h-5" />
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
