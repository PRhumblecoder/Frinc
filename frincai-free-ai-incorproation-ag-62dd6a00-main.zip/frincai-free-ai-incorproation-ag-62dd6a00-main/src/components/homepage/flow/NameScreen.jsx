
import React from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function NameScreen({
  onBack,
  onSubmit,
  selectedState,
  selectedType,
  companyName,
  onNameChange,
  legalEnding,
  onLegalEndingChange,
  llcEndings,
  corpEndings
}) {
  return (
    <motion.div
      key="name"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="h-full flex flex-col p-6 bg-[var(--background)]"
    >
      <div className="flex-shrink-0 flex items-center justify-center mb-2 relative">
        <Button variant="ghost" size="icon" onClick={onBack} className="rounded-full h-12 w-12 text-[var(--text-secondary)] hover:bg-[var(--secondary)] absolute left-0">
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <h3 className="text-lg font-bold text-[var(--text-primary)] text-center flex-1">Company Name</h3>
      </div>
      <p className="text-sm text-[var(--text-secondary)] mb-6 text-center">
        Choose a name for your {selectedType?.toUpperCase()} in {selectedState}.
      </p>
      
      <div className="flex-1 flex flex-col gap-4">
        <Input
          placeholder="Enter your company name"
          value={companyName}
          onChange={(e) => onNameChange(e.target.value)}
          className="bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] rounded-[var(--radius)] text-lg p-4 placeholder:text-[var(--muted-foreground)]"
        />
        
        <Select onValueChange={onLegalEndingChange} value={legalEnding}>
          <SelectTrigger className="w-full bg-[var(--secondary)] border-[var(--border)] text-[var(--text-primary)] rounded-[var(--radius)]">
            <SelectValue placeholder="Select legal ending *" />
          </SelectTrigger>
          <SelectContent className="bg-[var(--popover)] text-[var(--popover-foreground)] border-[var(--border)]">
            {selectedType === 'llc' && llcEndings.map(ending => (
              <SelectItem key={ending} value={ending} className="focus:bg-[var(--accent)] hover:bg-[var(--accent)]">{ending}</SelectItem>
            ))}
            {(selectedType === 'inc' || selectedType === 'scorp') && corpEndings.map(ending => (
              <SelectItem key={ending} value={ending} className="focus:bg-[var(--accent)] hover:bg-[var(--accent)]">{ending}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        {companyName && legalEnding && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[var(--secondary)] border border-[var(--border)] rounded-[var(--radius)] p-4 mt-4 text-center">
            <p className="text-[var(--text-secondary)] text-sm mb-2">Your company will be:</p>
            <p className="text-[var(--text-primary)] font-bold text-lg">{companyName}, {legalEnding}</p>
          </motion.div>
        )}
      </div>
      
      <div className="p-6 pt-0 mt-auto">
        <Button
            onClick={onSubmit}
            disabled={!companyName || !legalEnding}
            className="group relative w-full bg-[var(--primary)] text-[var(--primary-foreground)] transition-all disabled:bg-[var(--muted)] disabled:text-[var(--muted-foreground)] disabled:cursor-not-allowed rounded-lg py-3 mt-auto overflow-hidden"
        >
            <span className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity duration-200"></span>
            <span className="relative">Next</span>
        </Button>
      </div>
    </motion.div>
  );
}
