import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UploadFile } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Trash2, UploadCloud } from 'lucide-react';

function FileUploadZone({ filePath, initialUrl, onUploadComplete, section, originalIndex }) {
  const uploadKey = `${section}_${originalIndex}`;
  const [isUploading, setIsUploading] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [imageUrl, setImageUrl] = useState(initialUrl);

  useEffect(() => {
    setImageUrl(initialUrl);
  }, [initialUrl]);

  const handleUpload = useCallback(async (file) => {
    if (!file) return;

    setIsUploading(true);
    try {
      const result = await UploadFile({ file });
      setImageUrl(result.file_url);
      onUploadComplete(filePath, result.file_url);
    } catch (error) {
      console.error('Upload failed:', error);
      alert('Upload failed. Please try again.');
    } finally {
      setIsUploading(false);
    }
  }, [filePath, onUploadComplete]);

  const handleFileChange = useCallback((e) => {
    const file = e.target.files?.[0];
    if (file) handleUpload(file);
  }, [handleUpload]);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) handleUpload(file);
  }, [handleUpload]);
  
  const handlePaste = useCallback((e) => {
    const item = Array.from(e.clipboardData.items).find(item => item.type.startsWith('image/'));
    if (item) {
      e.preventDefault();
      const file = item.getAsFile();
      if (file) handleUpload(file);
    }
  }, [handleUpload]);

  return (
    <div
      className={`border-2 border-dashed rounded-lg p-4 text-center transition-colors ${
        isDragOver ? 'border-blue-400 bg-blue-400/10' : 'border-gray-600 bg-gray-800'
      }`}
      onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
      onDragLeave={(e) => { e.preventDefault(); setIsDragOver(false); }}
      onDrop={handleDrop}
      onPaste={handlePaste}
      tabIndex={0}
    >
      {imageUrl ? (
        <div className="space-y-3">
          <img src={imageUrl} alt="Preview" className="max-w-full max-h-48 mx-auto rounded-lg border border-gray-600" />
          <Button type="button" variant="outline" size="sm" onClick={() => document.getElementById(`file_input_${uploadKey}`).click()} className="text-white border-gray-600 hover:bg-gray-700">
            Replace Image
          </Button>
          <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" id={`file_input_${uploadKey}`} />
        </div>
      ) : (
        <div className="space-y-3">
          {isUploading ? (
            <>
              <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
              <span className="text-gray-300">Uploading...</span>
            </>
          ) : (
            <>
              <UploadCloud className="w-8 h-8 text-gray-400 mx-auto" />
              <div>
                <p className="text-white font-medium text-sm">Click, drag & drop, or paste to upload</p>
                <p className="text-gray-400 text-xs mt-1">PNG, JPG up to 10MB</p>
              </div>
              <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" id={`file_input_${uploadKey}`} />
              <Button type="button" variant="outline" size="sm" onClick={() => document.getElementById(`file_input_${uploadKey}`).click()} className="text-white border-gray-600 hover:bg-gray-700">
                Choose File
              </Button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default function StateDataForm({ initialData, onSave, onCancel }) {
  const [formData, setFormData] = useState(initialData || {});
  const [activeTab, setActiveTab] = useState('general');

  useEffect(() => {
    setFormData(initialData || {});
  }, [initialData]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleNestedChange = (e) => {
    const { name, value } = e.target;
    const keys = name.split(/[.\[\]]/).filter(k => k);
    setFormData(prev => {
      const newData = JSON.parse(JSON.stringify(prev));
      let current = newData;
      for (let i = 0; i < keys.length - 1; i++) {
        if (!current[keys[i]]) {
          current[keys[i]] = isNaN(keys[i+1]) ? {} : [];
        }
        current = current[keys[i]];
      }
      current[keys[keys.length - 1]] = value;
      return newData;
    });
  };

  const updateScreenshotField = (section, index, field, value) => {
    setFormData(prev => {
      const newData = JSON.parse(JSON.stringify(prev));
      if (newData[section] && newData[section].screenshots && newData[section].screenshots[index]) {
        newData[section].screenshots[index][field] = value;
      }
      return newData;
    });
  };

  const addScreenshotStep = (section) => {
    setFormData(prev => {
      const newData = JSON.parse(JSON.stringify(prev));
      if (!newData[section]) newData[section] = {};
      if (!newData[section].screenshots) newData[section].screenshots = [];
      const newStepNumber = newData[section].screenshots.length > 0 ? Math.max(...newData[section].screenshots.map(s => s.step_number || 0)) + 1 : 1;
      newData[section].screenshots.push({ step_number: newStepNumber, step_title: '', step_description: '', screenshot_url: '', html_content: '', highlighted_fields: '[]' });
      return newData;
    });
  };

  const removeScreenshotStep = (section, index) => {
    setFormData(prev => {
      const newData = JSON.parse(JSON.stringify(prev));
      newData[section].screenshots.splice(index, 1);
      return newData;
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const dataToSave = JSON.parse(JSON.stringify(formData));
    ['name_search', 'llc_registration', 'corporation_registration'].forEach(section => {
        if (dataToSave[section]?.screenshots) {
            dataToSave[section].screenshots.forEach(step => {
                try {
                    step.highlighted_fields = JSON.parse(step.highlighted_fields);
                } catch {
                    step.highlighted_fields = []; 
                }
            });
        }
    });
    onSave(dataToSave);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <form onSubmit={handleSubmit} className="w-full max-w-4xl max-h-[90vh] flex flex-col bg-gray-900 rounded-lg shadow-2xl overflow-hidden">
        <div className="flex-shrink-0 p-6 border-b border-gray-700">
          <h2 className="text-2xl font-bold text-white">Edit {formData.state_name} Data</h2>
          <p className="text-gray-400">Editing incorporation data for Wyoming</p>
        </div>
        <div className="flex-1 overflow-y-auto p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-gray-800">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="name_search">Name Search</TabsTrigger>
              <TabsTrigger value="llc_registration">LLC Reg</TabsTrigger>
              <TabsTrigger value="corporation_registration">Corp Reg</TabsTrigger>
            </TabsList>
            
            <TabsContent value="general" className="mt-6">
               {/* General fields content here */}
            </TabsContent>

            {/* Name Search Tab */}
            <TabsContent value="name_search" className="mt-6">
              <div className="space-y-4">
                <div><Label htmlFor="name_search_url" className="text-gray-300">Name Search URL</Label><Input id="name_search_url" name="name_search.search_url" value={formData.name_search?.search_url || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white" /></div>
                <div className="flex justify-end"><Button type="button" onClick={() => addScreenshotStep('name_search')} className="bg-blue-600 hover:bg-blue-700 text-white"><Plus className="mr-2 h-4 w-4" /> Add Step</Button></div>
                <div className="space-y-6">
                  {[...(formData.name_search?.screenshots || [])].sort((a, b) => (a.step_number || 0) - (a.step_number || 0)).map((step, index) => {
                    const originalIndex = (formData.name_search?.screenshots || []).findIndex(s => s === step);
                    if (originalIndex === -1) return null;
                    return (
                      <Card key={originalIndex} className="bg-gray-800 border-gray-700">
                        <CardHeader className="pb-3"><div className="flex justify-between items-center"><CardTitle className="text-lg text-white">Step {step.step_number || index + 1}</CardTitle><Button type="button" variant="destructive" size="icon" onClick={() => removeScreenshotStep('name_search', originalIndex)}><Trash2 className="h-4 w-4" /></Button></div></CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div><Label htmlFor={`name_search_title_${originalIndex}`} className="text-gray-300">Step Title</Label><Input id={`name_search_title_${originalIndex}`} name={`name_search.screenshots[${originalIndex}].step_title`} value={step.step_title || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white" /></div>
                            <div><Label htmlFor={`name_search_number_${originalIndex}`} className="text-gray-300">Step Number</Label><Input type="number" id={`name_search_number_${originalIndex}`} name={`name_search.screenshots[${originalIndex}].step_number`} value={step.step_number || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white" /></div>
                          </div>
                          <div><Label htmlFor={`name_search_desc_${originalIndex}`} className="text-gray-300">Step Description</Label><Textarea id={`name_search_desc_${originalIndex}`} name={`name_search.screenshots[${originalIndex}].step_description`} value={step.step_description || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white h-20" /></div>
                          <div><Label htmlFor={`name_search_html_${originalIndex}`} className="text-gray-300">HTML Content</Label><Textarea id={`name_search_html_${originalIndex}`} name={`name_search.screenshots[${originalIndex}].html_content`} value={step.html_content || ''} onChange={handleNestedChange} placeholder="Paste HTML..." className="bg-gray-900 border-gray-600 text-white h-40 font-mono text-sm" /></div>
                          <div><Label htmlFor={`name_search_highlight_${originalIndex}`} className="text-gray-300">Highlighted Fields (JSON)</Label><Textarea id={`name_search_highlight_${originalIndex}`} name={`name_search.screenshots[${originalIndex}].highlighted_fields`} value={typeof step.highlighted_fields === 'string' ? step.highlighted_fields : JSON.stringify(step.highlighted_fields || [], null, 2)} onChange={(e) => updateScreenshotField('name_search', originalIndex, 'highlighted_fields', e.target.value)} placeholder='["#id", ".class"]' className="bg-gray-900 border-gray-600 text-white h-24 font-mono text-sm" /></div>
                          <div><Label className="text-gray-300">Screenshot</Label><FileUploadZone section="name_search" originalIndex={originalIndex} filePath={`name_search.screenshots[${originalIndex}].screenshot_url`} initialUrl={step.screenshot_url} onUploadComplete={updateScreenshotField} /></div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            </TabsContent>

            {/* LLC Registration Tab */}
            <TabsContent value="llc_registration" className="mt-6">
              <div className="space-y-4">
                <div><Label htmlFor="llc_registration_url" className="text-gray-300">LLC Registration URL</Label><Input id="llc_registration_url" name="llc_registration.registration_url" value={formData.llc_registration?.registration_url || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white" /></div>
                <div className="flex justify-end"><Button type="button" onClick={() => addScreenshotStep('llc_registration')} className="bg-blue-600 hover:bg-blue-700 text-white"><Plus className="mr-2 h-4 w-4" /> Add Step</Button></div>
                <div className="space-y-6">
                  {[...(formData.llc_registration?.screenshots || [])].sort((a, b) => (a.step_number || 0) - (a.step_number || 0)).map((step, index) => {
                    const originalIndex = (formData.llc_registration?.screenshots || []).findIndex(s => s === step);
                    if (originalIndex === -1) return null;
                    return (
                      <Card key={originalIndex} className="bg-gray-800 border-gray-700">
                        <CardHeader className="pb-3"><div className="flex justify-between items-center"><CardTitle className="text-lg text-white">Step {step.step_number || index + 1}</CardTitle><Button type="button" variant="destructive" size="icon" onClick={() => removeScreenshotStep('llc_registration', originalIndex)}><Trash2 className="h-4 w-4" /></Button></div></CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div><Label htmlFor={`llc_reg_title_${originalIndex}`} className="text-gray-300">Step Title</Label><Input id={`llc_reg_title_${originalIndex}`} name={`llc_registration.screenshots[${originalIndex}].step_title`} value={step.step_title || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white" /></div>
                            <div><Label htmlFor={`llc_reg_number_${originalIndex}`} className="text-gray-300">Step Number</Label><Input type="number" id={`llc_reg_number_${originalIndex}`} name={`llc_registration.screenshots[${originalIndex}].step_number`} value={step.step_number || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white" /></div>
                          </div>
                          <div><Label htmlFor={`llc_reg_desc_${originalIndex}`} className="text-gray-300">Step Description</Label><Textarea id={`llc_reg_desc_${originalIndex}`} name={`llc_registration.screenshots[${originalIndex}].step_description`} value={step.step_description || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white h-20" /></div>
                          <div><Label htmlFor={`llc_reg_html_${originalIndex}`} className="text-gray-300">HTML Content</Label><Textarea id={`llc_reg_html_${originalIndex}`} name={`llc_registration.screenshots[${originalIndex}].html_content`} value={step.html_content || ''} onChange={handleNestedChange} placeholder="Paste HTML..." className="bg-gray-900 border-gray-600 text-white h-40 font-mono text-sm" /></div>
                          <div><Label htmlFor={`llc_reg_highlight_${originalIndex}`} className="text-gray-300">Highlighted Fields (JSON)</Label><Textarea id={`llc_reg_highlight_${originalIndex}`} name={`llc_registration.screenshots[${originalIndex}].highlighted_fields`} value={typeof step.highlighted_fields === 'string' ? step.highlighted_fields : JSON.stringify(step.highlighted_fields || [], null, 2)} onChange={(e) => updateScreenshotField('llc_registration', originalIndex, 'highlighted_fields', e.target.value)} placeholder='["#id", ".class"]' className="bg-gray-900 border-gray-600 text-white h-24 font-mono text-sm" /></div>
                          <div><Label className="text-gray-300">Screenshot</Label><FileUploadZone section="llc_registration" originalIndex={originalIndex} filePath={`llc_registration.screenshots[${originalIndex}].screenshot_url`} initialUrl={step.screenshot_url} onUploadComplete={updateScreenshotField} /></div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            </TabsContent>

            {/* Corporation Registration Tab */}
            <TabsContent value="corporation_registration" className="mt-6">
              <div className="space-y-4">
                <div><Label htmlFor="corp_registration_url" className="text-gray-300">Corporation Registration URL</Label><Input id="corp_registration_url" name="corporation_registration.registration_url" value={formData.corporation_registration?.registration_url || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white" /></div>
                <div className="flex justify-end"><Button type="button" onClick={() => addScreenshotStep('corporation_registration')} className="bg-blue-600 hover:bg-blue-700 text-white"><Plus className="mr-2 h-4 w-4" /> Add Step</Button></div>
                <div className="space-y-6">
                  {[...(formData.corporation_registration?.screenshots || [])].sort((a, b) => (a.step_number || 0) - (a.step_number || 0)).map((step, index) => {
                    const originalIndex = (formData.corporation_registration?.screenshots || []).findIndex(s => s === step);
                    if (originalIndex === -1) return null;
                    return (
                      <Card key={originalIndex} className="bg-gray-800 border-gray-700">
                        <CardHeader className="pb-3"><div className="flex justify-between items-center"><CardTitle className="text-lg text-white">Step {step.step_number || index + 1}</CardTitle><Button type="button" variant="destructive" size="icon" onClick={() => removeScreenshotStep('corporation_registration', originalIndex)}><Trash2 className="h-4 w-4" /></Button></div></CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div><Label htmlFor={`corp_reg_title_${originalIndex}`} className="text-gray-300">Step Title</Label><Input id={`corp_reg_title_${originalIndex}`} name={`corporation_registration.screenshots[${originalIndex}].step_title`} value={step.step_title || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white" /></div>
                            <div><Label htmlFor={`corp_reg_number_${originalIndex}`} className="text-gray-300">Step Number</Label><Input type="number" id={`corp_reg_number_${originalIndex}`} name={`corporation_registration.screenshots[${originalIndex}].step_number`} value={step.step_number || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white" /></div>
                          </div>
                          <div><Label htmlFor={`corp_reg_desc_${originalIndex}`} className="text-gray-300">Step Description</Label><Textarea id={`corp_reg_desc_${originalIndex}`} name={`corporation_registration.screenshots[${originalIndex}].step_description`} value={step.step_description || ''} onChange={handleNestedChange} className="bg-gray-900 border-gray-600 text-white h-20" /></div>
                          <div><Label htmlFor={`corp_reg_html_${originalIndex}`} className="text-gray-300">HTML Content</Label><Textarea id={`corp_reg_html_${originalIndex}`} name={`corporation_registration.screenshots[${originalIndex}].html_content`} value={step.html_content || ''} onChange={handleNestedChange} placeholder="Paste HTML..." className="bg-gray-900 border-gray-600 text-white h-40 font-mono text-sm" /></div>
                          <div><Label htmlFor={`corp_reg_highlight_${originalIndex}`} className="text-gray-300">Highlighted Fields (JSON)</Label><Textarea id={`corp_reg_highlight_${originalIndex}`} name={`corporation_registration.screenshots[${originalIndex}].highlighted_fields`} value={typeof step.highlighted_fields === 'string' ? step.highlighted_fields : JSON.stringify(step.highlighted_fields || [], null, 2)} onChange={(e) => updateScreenshotField('corporation_registration', originalIndex, 'highlighted_fields', e.target.value)} placeholder='["#id", ".class"]' className="bg-gray-900 border-gray-600 text-white h-24 font-mono text-sm" /></div>
                          <div><Label className="text-gray-300">Screenshot</Label><FileUploadZone section="corporation_registration" originalIndex={originalIndex} filePath={`corporation_registration.screenshots[${originalIndex}].screenshot_url`} initialUrl={step.screenshot_url} onUploadComplete={updateScreenshotField} /></div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
        <div className="flex-shrink-0 p-6 pt-0 bg-gray-900">
          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={onCancel} className="text-white border-gray-600 hover:bg-gray-700">Cancel</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white">Save State Data</Button>
          </div>
        </div>
      </form>
    </div>
  );
}