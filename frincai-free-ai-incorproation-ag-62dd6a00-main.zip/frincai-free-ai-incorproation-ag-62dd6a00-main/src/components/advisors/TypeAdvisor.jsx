import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { X, Sparkles, Lightbulb, Bot } from 'lucide-react';
import { InvokeLLM } from '@/api/integrations';

export default function TypeAdvisor({ onSelect, onClose, companyName }) {
  const [businessDescription, setBusinessDescription] = useState('');
  const [recommendation, setRecommendation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const getRecommendation = async () => {
    if (!businessDescription.trim()) {
      setError('Please describe your business first.');
      return;
    }
    setLoading(true);
    setError('');
    setRecommendation(null);

    const prompt = `
      I am starting a new US-based company called "${companyName}".
      Business Description: "${businessDescription}"
      
      Based on this, recommend the best entity type (LLC, C-Corp, or S-Corp) and provide a brief (2-3 sentences) justification explaining why it's the best fit. Consider factors like liability protection, taxation, and investment potential.

      The final output must be a single, valid JSON object with two keys: "type" (the recommended entity type in lowercase, e.g., "llc", "inc", "scorp") and "justification" (the reason for the recommendation). Do not include any text outside the JSON object.
    `;

    try {
      const result = await InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            type: { type: 'string', enum: ['llc', 'inc', 'scorp'] },
            justification: { type: 'string' },
          },
          required: ['type', 'justification'],
        },
      });
      setRecommendation(result);
    } catch (e) {
      console.error(e);
      setError('The AI advisor failed to generate a recommendation. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const typeMap = {
    llc: 'LLC',
    inc: 'C-Corp',
    scorp: 'S-Corp'
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-slate-800 border border-slate-700 rounded-2xl w-full max-w-lg p-6 text-white relative"
      >
        <Button variant="ghost" size="icon" onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white">
          <X className="w-5 h-5" />
        </Button>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-lg flex items-center justify-center">
            <Lightbulb className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold">AI Type Advisor</h2>
            <p className="text-sm text-slate-400">Let's find the best legal structure.</p>
          </div>
        </div>

        <div className="space-y-4">
          <Textarea
            value={businessDescription}
            onChange={(e) => setBusinessDescription(e.target.value)}
            placeholder="Briefly describe your business, including plans for fundraising or number of owners."
            className="bg-slate-700 border-slate-600 placeholder:text-slate-500 min-h-[100px]"
          />
          <Button onClick={getRecommendation} disabled={loading} className="w-full bg-indigo-600 hover:bg-indigo-700">
            {loading ? 'Analyzing...' : <><Sparkles className="w-4 h-4 mr-2" />Get Recommendation</>}
          </Button>

          {error && <p className="text-sm text-red-400 text-center">{error}</p>}
          
          {loading && (
             <div className="text-center py-4">
                <p className="text-slate-300">AI is thinking...</p>
             </div>
          )}

          {recommendation && (
            <motion.div initial={{opacity: 0}} animate={{opacity: 1}} className="bg-slate-900/50 p-4 rounded-lg border border-slate-700 space-y-3">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-indigo-400" />
                <h3 className="font-semibold text-lg">Recommendation: <span className="text-indigo-400">{typeMap[recommendation.type]}</span></h3>
              </div>
              <p className="text-slate-300">{recommendation.justification}</p>
              <Button onClick={() => onSelect(recommendation.type)} className="w-full bg-emerald-600 hover:bg-emerald-700">
                Use {typeMap[recommendation.type]}
              </Button>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
}