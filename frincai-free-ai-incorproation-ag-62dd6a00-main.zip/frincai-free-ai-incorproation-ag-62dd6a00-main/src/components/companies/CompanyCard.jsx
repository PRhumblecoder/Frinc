
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, Trash2, Rocket, Bot, UserCheck } from 'lucide-react';

export default function CompanyCard({ company, onLaunch, onEdit, onDelete, onLaunchGemini, onLaunchPro }) {
  const canLaunch = true; // Always allow launch - removed the status check

  return (
    <Card className="bg-[var(--card)] border-[var(--border)] flex flex-col justify-between hover:border-[var(--primary)] transition-all duration-200">
      <CardHeader className="p-4 md:p-6">
        <div className="flex justify-between items-start">
            <CardTitle className="text-[var(--text-primary)] text-base md:text-lg font-semibold">{company.company_name}</CardTitle>
        </div>
        <CardDescription className="text-[var(--text-secondary)] text-sm">{company.company_type.toUpperCase()} in {company.state}</CardDescription>
      </CardHeader>
      <CardContent className="p-4 md:p-6 pt-0">
        <div className="text-sm text-[var(--text-secondary)]">
          <p><span className="font-semibold text-[var(--text-primary)]">Owners:</span> {company.owners.length}</p>
          <p><span className="font-semibold text-[var(--text-primary)]">Managers:</span> {company.managers.length}</p>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col items-stretch gap-2 p-4 md:p-6 pt-4 border-t border-[var(--border)]">
        <Button
          onClick={onLaunchGemini}
          className="w-full bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)]/30 hover:text-[var(--primary-foreground)] transition-all duration-200 text-sm md:text-base py-2 md:py-3"
        >
          <Bot className="mr-2 h-4 w-4" />
          Launch with AI - Free
        </Button>
        <Button
          onClick={onLaunchPro}
          variant="outline"
          className="w-full bg-transparent text-[var(--primary)] border-[var(--primary)] hover:bg-[var(--primary)]/10 hover:text-[var(--primary)] transition-all duration-200 text-sm md:text-base py-2 md:py-3"
        >
          <UserCheck className="mr-2 h-4 w-4" />
          Launch with a Pro - $99
        </Button>
        <div className="flex gap-2 w-full mt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onEdit}
              className="flex-1 text-[var(--text-primary)] border-[var(--border)] hover:bg-[var(--accent)] transition-all duration-200 text-xs md:text-sm"
            >
                <Edit className="mr-1 md:mr-2 h-3 w-3 md:h-4 md:w-4" /> Edit
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={onDelete}
              className="flex-1 text-red-500 border-red-500/30 hover:bg-red-500/10 transition-all duration-200 text-xs md:text-sm"
            >
                <Trash2 className="mr-1 md:mr-2 h-3 w-3 md:h-4 md:w-4" /> 
                <span className="hidden sm:inline">Delete</span>
                <span className="sm:hidden">Del</span>
            </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
