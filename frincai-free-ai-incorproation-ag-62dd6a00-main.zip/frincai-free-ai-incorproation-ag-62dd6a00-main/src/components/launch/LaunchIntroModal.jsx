import React from 'react';
import { motion } from 'framer-motion';
import { X, Bot, UserCheck, ArrowRight } from 'lucide-react';
import Logo from '../Logo';
import { Button } from '@/components/ui/button';

export default function LaunchIntroModal({ company, onClose, onStartDIY, onGoPro }) {
  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <motion.div
        key="launch-intro"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="bg-[var(--background)] rounded-2xl shadow-2xl w-full max-w-2xl p-8 border border-[var(--border)]"
      >
        <div className="relative">
          <Button variant="ghost" size="icon" onClick={onClose} className="absolute -top-4 -right-4 bg-white/20 backdrop-blur-sm border border-slate-200/20 hover:bg-white/30 rounded-full h-8 w-8 text-white hover:text-white transition-all">
            <X className="h-5 w-5" />
          </Button>

          <div className="text-center">
            <Logo className="w-12 h-12 text-[var(--primary)] mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-[var(--text-primary)]">You're Ready to File!</h2>
            <p className="text-[var(--text-secondary)] mt-2 mb-6">
              You are about to start the filing process for <span className="font-semibold text-[var(--text-primary)]">{company.company_name}, {company.legal_ending}</span>. Choose how you'd like to proceed.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {/* Free AI Guide */}
            <div className="border border-[var(--border)] rounded-xl p-6 flex flex-col text-center bg-[var(--card-foreground)]">
              <Bot className="w-8 h-8 text-[var(--primary)] mx-auto mb-3" />
              <h3 className="font-bold text-[var(--text-primary)] mb-2">Free AI Guide</h3>
              <p className="text-sm text-[var(--text-secondary)] flex-1 mb-4">Our AI agent will guide you step-by-step through the official state website filing process.</p>
              <Button onClick={onStartDIY} className="bg-orange-500 hover:bg-orange-600 text-white font-bold w-full">
                Start Free Guide <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>

            {/* File with a Pro */}
            <div className="border border-green-500/50 rounded-xl p-6 flex flex-col text-center bg-green-500/10">
              <UserCheck className="w-8 h-8 text-green-400 mx-auto mb-3" />
              <h3 className="font-bold text-[var(--text-primary)] mb-2">File with a Pro ($99)</h3>
              <p className="text-sm text-[var(--text-secondary)] flex-1 mb-4">Save time and let our experts handle the entire filing for you. Guaranteed accuracy and peace of mind.</p>
              <Button onClick={onGoPro} className="bg-green-500 hover:bg-green-600 text-white font-bold w-full">
                Go Pro <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}