export const stateInfo = {
  'Alabama': {
    name: 'Alabama',
    sos_url: 'https://www.sos.alabama.gov/',
    fee: 200
  },
  'Alaska': {
    name: 'Alaska',
    sos_url: 'https://www.commerce.alaska.gov/web/cbpl/',
    fee: 250
  },
  'Arizona': {
    name: 'Arizona',
    sos_url: 'https://azsos.gov/',
    fee: 85
  },
  'Arkansas': {
    name: 'Arkansas',
    sos_url: 'https://www.sos.arkansas.gov/',
    fee: 45
  },
  'California': {
    name: 'California',
    sos_url: 'https://www.sos.ca.gov/',
    fee: 70
  },
  'Colorado': {
    name: 'Colorado',
    sos_url: 'https://www.sos.state.co.us/',
    fee: 50
  },
  'Connecticut': {
    name: 'Connecticut',
    sos_url: 'https://portal.ct.gov/SOTS',
    fee: 120
  },
  'Delaware': {
    name: 'Delaware',
    sos_url: 'https://corp.delaware.gov/',
    fee: 90
  },
  'Florida': {
    name: 'Florida',
    sos_url: 'https://dos.myflorida.com/sunbiz/',
    fee: 125
  },
  'Georgia': {
    name: 'Georgia',
    sos_url: 'https://sos.ga.gov/',
    fee: 100
  },
  'Hawaii': {
    name: 'Hawaii',
    sos_url: 'https://cca.hawaii.gov/',
    fee: 50
  },
  'Idaho': {
    name: 'Idaho',
    sos_url: 'https://sos.idaho.gov/',
    fee: 100
  },
  'Illinois': {
    name: 'Illinois',
    sos_url: 'https://www.cyberdriveillinois.com/',
    fee: 150
  },
  'Indiana': {
    name: 'Indiana',
    sos_url: 'https://www.in.gov/sos/',
    fee: 95
  },
  'Iowa': {
    name: 'Iowa',
    sos_url: 'https://sos.iowa.gov/',
    fee: 50
  },
  'Kansas': {
    name: 'Kansas',
    sos_url: 'https://www.kssos.org/',
    fee: 160
  },
  'Kentucky': {
    name: 'Kentucky',
    sos_url: 'https://www.sos.ky.gov/',
    fee: 40
  },
  'Louisiana': {
    name: 'Louisiana',
    sos_url: 'https://www.sos.la.gov/',
    fee: 100
  },
  'Maine': {
    name: 'Maine',
    sos_url: 'https://www.maine.gov/sos/',
    fee: 175
  },
  'Maryland': {
    name: 'Maryland',
    sos_url: 'https://www.sos.state.md.us/',
    fee: 100
  },
  'Massachusetts': {
    name: 'Massachusetts',
    sos_url: 'https://www.sec.state.ma.us/',
    fee: 500
  },
  'Michigan': {
    name: 'Michigan',
    sos_url: 'https://www.michigan.gov/sos',
    fee: 50
  },
  'Minnesota': {
    name: 'Minnesota',
    sos_url: 'https://www.sos.state.mn.us/',
    fee: 135
  },
  'Mississippi': {
    name: 'Mississippi',
    sos_url: 'https://www.sos.ms.gov/',
    fee: 50
  },
  'Missouri': {
    name: 'Missouri',
    sos_url: 'https://www.sos.mo.gov/',
    fee: 50
  },
  'Montana': {
    name: 'Montana',
    sos_url: 'https://sosmt.gov/',
    fee: 35
  },
  'Nebraska': {
    name: 'Nebraska',
    sos_url: 'https://www.sos.nebraska.gov/',
    fee: 100
  },
  'Nevada': {
    name: 'Nevada',
    sos_url: 'https://www.nvsos.gov/',
    fee: 425
  },
  'New Hampshire': {
    name: 'New Hampshire',
    sos_url: 'https://www.sos.nh.gov/',
    fee: 100
  },
  'New Jersey': {
    name: 'New Jersey',
    sos_url: 'https://www.nj.gov/treasury/revenue/',
    fee: 125
  },
  'New Mexico': {
    name: 'New Mexico',
    sos_url: 'https://www.sos.state.nm.us/',
    fee: 50
  },
  'New York': {
    name: 'New York',
    sos_url: 'https://www.dos.ny.gov/',
    fee: 200
  },
  'North Carolina': {
    name: 'North Carolina',
    sos_url: 'https://www.sosnc.gov/',
    fee: 125
  },
  'North Dakota': {
    name: 'North Dakota',
    sos_url: 'https://www.sos.nd.gov/',
    fee: 135
  },
  'Ohio': {
    name: 'Ohio',
    sos_url: 'https://www.sos.state.oh.us/',
    fee: 99
  },
  'Oklahoma': {
    name: 'Oklahoma',
    sos_url: 'https://www.sos.ok.gov/',
    fee: 100
  },
  'Oregon': {
    name: 'Oregon',
    sos_url: 'https://sos.oregon.gov/',
    fee: 100
  },
  'Pennsylvania': {
    name: 'Pennsylvania',
    sos_url: 'https://www.dos.pa.gov/',
    fee: 125
  },
  'Rhode Island': {
    name: 'Rhode Island',
    sos_url: 'https://www.sos.ri.gov/',
    fee: 150
  },
  'South Carolina': {
    name: 'South Carolina',
    sos_url: 'https://www.sos.sc.gov/',
    fee: 110
  },
  'South Dakota': {
    name: 'South Dakota',
    sos_url: 'https://sdsos.gov/',
    fee: 150
  },
  'Tennessee': {
    name: 'Tennessee',
    sos_url: 'https://sos.tn.gov/',
    fee: 300
  },
  'Texas': {
    name: 'Texas',
    sos_url: 'https://www.sos.state.tx.us/',
    fee: 300
  },
  'Utah': {
    name: 'Utah',
    sos_url: 'https://corporations.utah.gov/',
    fee: 54
  },
  'Vermont': {
    name: 'Vermont',
    sos_url: 'https://www.sec.state.vt.us/',
    fee: 125
  },
  'Virginia': {
    name: 'Virginia',
    sos_url: 'https://www.scc.virginia.gov/',
    fee: 100
  },
  'Washington': {
    name: 'Washington',
    sos_url: 'https://www.sos.wa.gov/',
    fee: 180
  },
  'West Virginia': {
    name: 'West Virginia',
    sos_url: 'https://sos.wv.gov/',
    fee: 100
  },
  'Wisconsin': {
    name: 'Wisconsin',
    sos_url: 'https://www.sos.state.wi.us/',
    fee: 130
  },
  'Wyoming': {
    name: 'Wyoming',
    sos_url: 'https://sos.wyo.gov/',
    fee: 100
  },
  'Default': {
    name: 'State',
    sos_url: 'https://www.sos.gov/',
    fee: 100
  }
};