import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Maximize, Minimize } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function SimulatedWebsiteFrame({ step, company }) {
  const [isEnlarged, setIsEnlarged] = useState(false);

  const finalHtml = useMemo(() => {
    if (!step?.html_content || !company) {
      return '<div style="display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;color:#555;">Loading Simulation...</div>';
    }

    // Replace placeholders with actual company data
    let html = step.html_content;
    html = html.replace(/{company_name}/g, company.company_name || '');
    html = html.replace(/{legal_ending}/g, company.legal_ending || '');
    
    const organizer = company.organizer || {};
    const owner = (company.owners && company.owners[0]) ? company.owners[0] : {};

    html = html.replace(/{organizer_firstname}/g, organizer.firstName || '');
    html = html.replace(/{organizer_lastname}/g, organizer.lastName || '');
    html = html.replace(/{organizer_address}/g, organizer.streetAddress || '');
    html = html.replace(/{organizer_city}/g, organizer.city || '');
    html = html.replace(/{organizer_state}/g, organizer.state || '');
    html = html.replace(/{organizer_zip}/g, organizer.zipCode || '');
    
    html = html.replace(/{owner_firstname}/g, owner.firstName || '');
    html = html.replace(/{owner_lastname}/g, owner.lastName || '');
    html = html.replace(/{owner_address}/g, owner.streetAddress || '');
    html = html.replace(/{owner_city}/g, owner.city || '');
    html = html.replace(/{owner_state}/g, owner.state || '');
    html = html.replace(/{owner_zip}/g, owner.zipCode || '');

    return `<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>${html}</html>`;
  }, [step, company]);

  return (
    <div className={`relative w-full h-full bg-gray-200 overflow-hidden shadow-lg transition-all duration-300
        ${isEnlarged 
            ? 'fixed inset-0 z-[60] rounded-none border-0' 
            : 'rounded-lg border border-gray-300'}`
    }>
      <div className={`w-full h-full ${isEnlarged ? '' : 'p-1 bg-gray-200'}`}>
        <div className="relative w-full h-full bg-white overflow-hidden">
            <div className="absolute top-2 right-2 z-20">
                <Button
                variant="secondary"
                size="icon"
                onClick={() => setIsEnlarged(!isEnlarged)}
                className="bg-black/40 text-white hover:bg-black/60 h-8 w-8"
                >
                {isEnlarged ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                </Button>
            </div>
            
            <iframe
                srcDoc={finalHtml}
                title={`Step ${step?.step_number}: ${step?.step_title}`}
                className="w-full h-full border-0"
                sandbox="allow-scripts allow-same-origin"
                style={!isEnlarged ? {
                    transform: 'scale(0.8)',
                    transformOrigin: 'top left',
                    width: '125%',
                    height: '125%',
                } : {}}
            />
        </div>
      </div>
    </div>
  );
}