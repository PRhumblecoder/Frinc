
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { X, Copy, Check, ExternalLink, CheckCircle2, User, Users, Briefcase, UserCheck, Rocket, Building, ClipboardCheck, AlertTriangle, ArrowRight, ArrowLeft, PartyPopper, ThumbsUp, Star, Play, Pause, Ear, BookOpen } from 'lucide-react';
import { User as UserEntity } from '@/api/entities';
import Logo from '../Logo';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { stateInfo as allStateInfo } from './stateInfo';
import ReactMarkdown from 'react-markdown';

// Completion Animation Component
const CompletionAnimation = ({ onComplete }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center overflow-hidden"
    >
      <div className="text-center text-white">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 260, damping: 20 }}
        >
          <PartyPopper className="w-24 h-24 mx-auto text-yellow-300" />
          <h2 className="text-3xl font-bold mt-4">Congratulations! 🎉</h2>
          <p className="text-lg mt-2">You've completed the filing guide!</p>
        </motion.div>
      </div>
      {/* Confetti Animation */}
      {[...Array(50)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ y: -20, opacity: 0 }}
          animate={{ 
            y: '110vh', 
            x: `${Math.random() * 100 - 50}vw`,
            rotate: Math.random() * 360,
            opacity: 1
          }}
          transition={{ 
            duration: Math.random() * 2 + 3, 
            ease: "linear",
            delay: Math.random() * 1
          }}
          style={{
            position: 'absolute',
            top: 0,
            left: `${Math.random() * 100}%`,
            width: '10px',
            height: '10px',
            background: ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800'][i % 15],
            borderRadius: '50%'
          }}
        />
      ))}
    </motion.div>
  );
};

// New Initial Review Modal
const InitialReviewModal = ({ onYes, onNo }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-[var(--background)] rounded-xl p-6 md:p-8 max-w-md w-full text-center shadow-2xl"
      >
        <h2 className="text-2xl font-bold text-[var(--text-primary)] mb-4">Did you like frinc.ai?</h2>
        <div className="flex justify-center gap-4">
          <Button onClick={onYes} className="bg-green-600 hover:bg-green-700 text-white flex-1">Yes</Button>
          <Button onClick={onNo} variant="outline" className="flex-1 border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]">No</Button>
        </div>
      </motion.div>
    </motion.div>
  );
};

// Updated Review Modal
const ReviewModal = ({ onNextSection }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-[var(--background)] rounded-xl p-6 md:p-8 max-w-md w-full text-center shadow-2xl"
      >
        <h2 className="text-2xl font-bold text-[var(--text-primary)] mb-2">Rate us on Trustpilot</h2>
        <a 
          href="https://www.trustpilot.com/review/frinc.ai" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex justify-center gap-1 my-4 text-yellow-400 hover:text-yellow-500 transition-colors"
        >
          {[...Array(5)].map((_, i) => <Star key={i} className="w-8 h-8" fill="currentColor" />)}
        </a>
        <p className="text-[var(--text-secondary)] mt-2 mb-6">
          Your feedback helps us improve and helps others make better decisions!
        </p>
        <Button 
          onClick={onNextSection} 
          variant="outline" 
          className="w-full border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)]"
        >
          What's Next?
        </Button>
      </motion.div>
    </motion.div>
  );
};

export default function TextualSimulation({ company, onClose }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [user, setUser] = useState(null);
  const [completedSteps, setCompletedSteps] = useState(new Set());
  const [showProModal, setShowProModal] = useState(false);
  const [isPanelVisible, setIsPanelVisible] = useState(false); 
  const [showCompletionAnimation, setShowCompletionAnimation] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [showInitialReview, setShowInitialReview] = useState(false);
  const [playingStep, setPlayingStep] = useState(null);
  const [audioTimer, setAudioTimer] = useState(0);
  const [audioDuration, setAudioDuration] = useState(0); // New state for audio duration
  const timelineContainerRef = useRef(null);
  const timerIntervalRef = useRef(null);

  const organizer = company.organizer || {};
  const stateInfo = allStateInfo[company.state] || allStateInfo['Default'];

  const baseSteps = [
    { 
      id: 'step_1', 
      group: 'Visit State Website', 
      title: 'Visit State Website', 
      description: `First, let's head over to the official ${company.state} Secretary of State website.`, 
      websiteUrl: `https://wyobiz.wyo.gov/Business/RegistrationType.aspx`
    },
    { 
      id: 'step_2', 
      group: 'Business Type', 
      title: 'Select Business Entity Type', 
      description: 'Choose "Limited Liability Company (Domestic)" from the dropdown menu on the Wyoming Secretary of State website.',
      previewContent: {
        title: 'Entity Type Selection',
        fields: [
          { label: 'Choose a Business Entity Type', value: 'Limited Liability Company (Domestic)' }
        ]
      }
    },
    {
      id: 'pro_offer_1',
      group: 'Go Pro',
      title: 'Want to save time?',
      description: 'Let our experts handle your filing for just $99. Professional service with guaranteed accuracy.',
      isProOffer: true
    },
    { 
      id: 'step_3', 
      group: 'Business Name', 
      title: 'Enter Business Name', 
      description: 'Enter your chosen company name in both the "Business Entity Name" and "Confirm Name" fields.', 
      copyText: `${company.company_name}, ${company.legal_ending}`,
      previewContent: {
        title: 'Business Entity Name',
        fields: [
            { label: 'Business Entity Name', value: `${company.company_name}, ${company.legal_ending}` },
            { label: 'Confirm Name', value: `${company.company_name}, ${company.legal_ending}` }
        ]
      }
    },
    { 
      id: 'step_4', 
      group: 'Detail', 
      title: 'Set Effective Date', 
      description: 'Leave the "Delayed Effective Date" field blank if you want the LLC formation to be effective immediately, or enter a future date within 90 days.',
      previewContent: {
        title: 'Detail',
        fields: [
            { label: 'Delayed Effective Date', value: '(leave blank for immediate)' }
        ]
      }
    },
    { id: 'step_5', group: 'Registered Agent', title: 'What is a Registered Agent?', description: `Every LLC must have a Registered Agent - a person or service with a physical address in ${company.state} who can receive official mail.` },
    {
      id: 'pro_offer_2',
      group: 'Go Pro',
      title: 'Need peace of mind?',
      description: 'Get professional registered agent service included. No more worrying about missed documents.',
      isProOffer: true
    },
    { id: 'step_6', group: 'Registered Agent', title: 'Why DIY Isn\'t Recommended', description: '🏠 **Privacy Risk**: Your home address becomes public record\n🔒 **Security Risk**: Anyone can find your personal address\n⚖️ **Legal Risk**: Missing important legal documents can result in penalties or lawsuits', showProAgentOffer: true },
    { id: 'step_7', group: 'Registered Agent', title: 'Enter Agent Information', description: "Enter your information in the agent section. Since you've chosen to serve as your own agent, we've pre-filled this with your organizer details. Copy each field into the corresponding field on the state website.",
      previewContent: {
        title: 'Registered Agent Information',
        fields: [
          { label: 'Agent Name', value: `${organizer.firstName || ''} ${organizer.lastName || ''}`.trim() },
          { label: 'Agent Address', value: `${organizer.streetAddress || ''} ${organizer.suite || ''}`.trim() },
          { label: 'City', value: organizer.city || '' },
          { label: 'State', value: organizer.state || company.state },
          { label: 'ZIP Code', value: organizer.zipCode || '' }
        ]
      }
    },
    {
      id: 'pro_offer_3',
      group: 'Go Pro',
      title: 'Ready to go pro?',
      description: 'Last chance to upgrade! Professional filing with expert review and priority processing.',
      isProOffer: true
    },
    { 
      id: 'step_8', 
      group: 'Organizer', 
      title: 'Enter Organizer Information', 
      description: 'The organizer is the person filing the paperwork. Enter the organizer\'s information in the required fields.',
      previewContent: {
        title: 'Organizer Information',
        fields: [
          { label: 'Organizer Name', value: `${organizer.firstName || ''} ${organizer.lastName || ''}`.trim() },
          { label: 'Organizer Address', value: `${organizer.streetAddress || ''} ${organizer.suite || ''}`.trim() },
          { label: 'City', value: organizer.city || '' },
          { label: 'State', value: organizer.state || company.state },
          { label: 'ZIP Code', value: organizer.zipCode || '' }
        ]
      }
    },
    { id: 'step_11', group: 'Review & Submit', title: 'Review Your Information', description: 'Carefully review all the information you\'ve entered before submitting your LLC formation.' },
    { id: 'step_12', group: 'Payment', title: 'Complete Payment', description: `Pay the required state filing fee. The fee for an LLC in ${company.state} is typically $100.` },
    { id: 'step_13', group: 'Confirmation', title: 'Process Finished', description: 'After successful submission, you\'ll receive a confirmation number. Save this for your records!' }
  ];
  
  const allSteps = baseSteps;

  useEffect(() => {
    // Load progress from localStorage
    const savedProgressRaw = localStorage.getItem(`frinc-progress-${company.id}`);
    if (savedProgressRaw) {
      try {
        const savedProgress = JSON.parse(savedProgressRaw);
        setCurrentStep(savedProgress.currentStep || 0);
        setCompletedSteps(new Set(savedProgress.completedSteps || []));
      } catch (e) {
        console.error("Failed to parse saved progress", e);
      }
    }

    const loadUser = async () => {
      try {
        const currentUser = await UserEntity.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Failed to load user:", error);
      }
    };
    loadUser();

    return () => {
      // Clean up timer and speech synthesis when component unmounts
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    };
  }, [company.id]);

  useEffect(() => {
    // Save progress to localStorage
    const progress = {
      currentStep,
      completedSteps: Array.from(completedSteps),
    };
    localStorage.setItem(`frinc-progress-${company.id}`, JSON.stringify(progress));
  }, [currentStep, completedSteps, company.id]);

  // This effect calculates the estimated audio duration whenever the step changes.
  useEffect(() => {
    const step = allSteps[currentStep];
    if (step) {
      let audioText = `${step.title}. ${step.description}`;
      if (step.copyText) {
        const fieldName = step.previewContent?.fields?.[0]?.label || 'appropriate field';
        audioText += ` Copy this text and paste it into the "${fieldName}" field on the state website: ${step.copyText}`;
      }
      const words = audioText.split(/\s+/).length;
      // Estimate duration at ~130 WPM, with a minimum of 5 seconds for very short steps.
      const estimatedDuration = Math.max(5, Math.round(words / 2.2)); 
      setAudioDuration(estimatedDuration);
      setAudioTimer(estimatedDuration); // Initialize timer for new step
    }
  }, [currentStep]);


  const handlePlayAudio = async (stepIndex, stepText) => {
    try {
      // Stop any currently playing audio
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      
      // If clicking the same step that's playing (or was playing before cancel), pause it
      if (playingStep === stepIndex) {
        setPlayingStep(null);
        setAudioTimer(audioDuration); // Reset timer to full duration on pause
        return;
      }

      // Create new audio using Web Speech API
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(stepText);
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 0.8;
        
        utterance.onstart = () => {
          setPlayingStep(stepIndex);
          setAudioTimer(audioDuration); // Ensure timer starts from the full duration
          // Start the countdown interval
          timerIntervalRef.current = setInterval(() => {
            setAudioTimer(prev => (prev > 0 ? prev - 1 : 0));
          }, 1000);
        };
        
        utterance.onend = () => {
          if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
          setPlayingStep(null);
          setAudioTimer(audioDuration); // Reset timer to full duration when finished
        };
        
        utterance.onerror = () => { 
          if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
          setPlayingStep(null);
          setAudioTimer(audioDuration); // Reset on error
        };
        
        window.speechSynthesis.speak(utterance);
      } else {
        console.warn("Web Speech API is not supported in this browser.");
      }
    } catch (error) {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      setPlayingStep(null);
      setAudioTimer(audioDuration); // Reset on error
    }
  };

  const handlePauseAudio = () => {
    try {
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      setPlayingStep(null);
      setAudioTimer(audioDuration); // Reset timer to full duration on pause
    } catch (error) {
       if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
       setPlayingStep(null);
       setAudioTimer(audioDuration); // Reset on error
    }
  };

  const handleNextStep = () => {
    // Before moving to next step, stop any playing audio
    if (playingStep !== null) {
      handlePauseAudio();
    }

    if (currentStep < allSteps.length - 1) {
      const nextStep = currentStep + 1;
      setCompletedSteps(prev => new Set(prev).add(currentStep));
      setCurrentStep(nextStep);
    } else {
      // Last step completed - trigger completion flow
      setCompletedSteps(prev => new Set(prev).add(currentStep));
      setShowCompletionAnimation(true);
    }
  };

  const handlePreviousStep = () => {
    // Before moving to previous step, stop any playing audio
    if (playingStep !== null) {
      handlePauseAudio();
    }
    
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleShowProModal = () => {
    // Stop audio when pro modal is opened
    if (playingStep !== null) {
      handlePauseAudio();
    }
    setShowProModal(true);
  };
  
  const handleCancelPro = () => {
    setShowProModal(false);
  };

  const ProModal = () => {
    if (!showProModal) return null;
    
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          className="bg-[var(--background)] rounded-xl p-6 md:p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
        >
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-2xl font-bold text-[var(--text-primary)]">Professional Filing Service</h3>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setShowProModal(false)}
              className="text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          <div className="p-6 text-center">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <UserCheck className="w-8 h-8 text-orange-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">File with a Pro - $99</h3>
            <p className="text-gray-600 mb-6">Let our experts handle your company registration for you. Save time and ensure everything is done correctly.</p>
            
            <div className="space-y-3 text-left mb-6">
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Check className="w-3 h-3 text-green-600" />
                </div>
                <span className="text-sm text-gray-700">Expert filing with zero mistakes</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Check className="w-3 h-3 text-green-600" />
                </div>
                <span className="text-sm text-gray-700">Fast-track processing</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Check className="w-3 h-3 text-green-600" />
                </div>
                <span className="text-sm text-gray-700">Complete peace of mind</span>
              </div>
            </div>
            
            <div className="flex gap-3">
              <Button 
                onClick={handleCancelPro}
                variant="outline" 
                className="flex-1 border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)] transition-all duration-200"
              >
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  setShowProModal(false);
                  alert('Pro Launch checkout coming soon!');
                }}
                className="flex-1 bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)]/30 hover:text-[var(--primary-foreground)]"
              >
                Get Pro Launch
              </Button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    );
  };

  const DetailsPanel = () => {
    const [copiedField, setCopiedField] = useState(null); 
    const org = company.organizer || {}; 
    const own = company.owners || [];
    const man = company.managers || [];

    const handleCopyToClipboard = (text, id) => {
      navigator.clipboard.writeText(text).then(() => {
        setCopiedField(id);
        setTimeout(() => setCopiedField(null), 2000);
      }).catch(err => {
        console.error('Failed to copy text: ', err);
      });
    };

    const createDetailFieldRow = (label, value, id) => {
      const isCopied = copiedField === id;
      return (
        <div className="flex items-center justify-between text-sm">
          <div className="text-xs text-[var(--text-secondary)] uppercase tracking-wider min-w-0 pr-2">
            {label}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[var(--text-primary)] break-words pr-2">{value}</span>
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 flex-shrink-0"
              onClick={() => handleCopyToClipboard(value, id)}
              title="Copy to clipboard"
            >
              {isCopied ? <ClipboardCheck className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4 text-[var(--text-secondary)]" />}
            </Button>
          </div>
        </div>
      );
    };

    const createFieldGroup = (title, items, icon) => {
      if (!items || items.length === 0) {
        if (title === "Managers") {
          return (
            <div className="border-t border-[var(--border)] pt-4">
              <h4 className="font-semibold text-[var(--text-primary)] flex items-center gap-2 mb-2">
                {icon}
                {title}
              </h4>
              <p className="text-[var(--text-secondary)] italic text-sm">No managers specified.</p>
            </div>
          );
        }
        return null;
      }

      return (
        <div className="border-t border-[var(--border)] pt-4">
          <h4 className="font-semibold text-[var(--text-primary)] flex items-center gap-2 mb-2">
            {icon}
            {title}
          </h4>
          <div className="space-y-2">
            {items.map((item, index) => (
              <div key={index} className="space-y-1">
                {createDetailFieldRow("Full Name", `${item.firstName} ${item.lastName}`, `${title.toLowerCase().replace(/\s/g, '-')}-${index}-full`)}
                {item.middleName && createDetailFieldRow("Middle Name", item.middleName, `${title.toLowerCase().replace(/\s/g, '-')}-${index}-middle`)}
                {item.titles && item.titles.length > 0 && createDetailFieldRow("Titles", item.titles.join(', '), `${title.toLowerCase().replace(/\s/g, '-')}-${index}-titles`)}
                {createDetailFieldRow("Address Line 1", item.streetAddress, `${title.toLowerCase().replace(/\s/g, '-')}-${index}-street`)}
                {item.suite && createDetailFieldRow("Address Line 2", item.suite, `${title.toLowerCase().replace(/\s/g, '-')}-${index}-suite`)}
                {createDetailFieldRow("City, State, Zip", `${item.city}, ${item.state} ${item.zipCode}`, `${title.toLowerCase().replace(/\s/g, '-')}-${index}-full-address`)}
                {item.ownershipPercent && createDetailFieldRow("Ownership %", `${item.ownershipPercent}%`, `${title.toLowerCase().replace(/\s/g, '-')}-${index}-ownership`)}
              </div>
            ))}
          </div>
        </div>
      );
    };

    return (
      <div className="bg-[var(--card)] border-l border-[var(--border)] shadow-lg h-full flex flex-col">
        <CardHeader className="border-b border-[var(--border)]">
          <CardTitle className="flex items-center gap-2">
            <Logo className="w-6 h-6 text-[var(--primary)]" />
            <h3 className="text-lg font-bold text-[var(--text-primary)]">🚀Launch with a Pro</h3>
          </CardTitle>
        </CardHeader>

        {/* File with a Pro Section - Reintroduced and styled to match the new theme */}
        <div className="flex-shrink-0 p-4 bg-[var(--background)] border-b border-[var(--border)] text-center">
          <p className="text-sm text-[var(--text-secondary)] mb-4">
            Save time and ensure your filing is accurate, compliant, and done right. Our experts handle everything for just $99 + state fees.
          </p>
          <Button onClick={handleShowProModal} className="w-full mt-4 bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)]/30 hover:text-[var(--primary-foreground)] transition-all duration-200">
            <UserCheck className="mr-2 h-4 w-4" />
            Go Pro
          </Button>
        </div>

        <div className="flex-shrink-0 p-4 border-b border-[var(--border)]">
          <h3 className="font-bold text-[var(--text-primary)]">Company Details</h3>
        </div>

        <div className="flex-1 overflow-y-scroll p-4 space-y-4 min-h-0" style={{ 
          scrollbarWidth: 'thin', 
          scrollbarColor: 'hsl(var(--primary) / 0.7) hsl(var(--border) / 0.5)' 
        }}>
          <Card className="bg-[var(--card)] border-[var(--border)] shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl flex items-center justify-between">
                <span className="text-[var(--text-primary)]">{company.company_name}, {company.legal_ending}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="w-8 h-8 flex-shrink-0"
                  onClick={() => handleCopyToClipboard(`${company.company_name}, ${company.legal_ending}`, 'company-name-full')}
                  title="Copy to clipboard"
                >
                  {copiedField === 'company-name-full' ? <ClipboardCheck className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4 text-[var(--text-secondary)]" />}
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {createDetailFieldRow("Entity Type", `${company.company_type.toUpperCase()} to be formed in ${company.state}`, "company-type-state")}
              
              {createFieldGroup("Organizer", [org], <User className="w-4 h-4"/>)}
              {createFieldGroup("Owners", own, <Users className="w-4 h-4"/>)}
              {createFieldGroup("Managers", man, <Briefcase className="w-4 h-4"/>)}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  const Timeline = () => {
    const stepRefs = useRef(new Map());

    const [copiedFieldTimeline, setCopiedFieldTimeline] = useState(null);

    const handleCopyToClipboardTimeline = (text, id) => {
      navigator.clipboard.writeText(text).then(() => {
        setCopiedFieldTimeline(id);
        setTimeout(() => setCopiedFieldTimeline(null), 2000);
      }).catch(err => {
        console.error('Failed to copy text: ', err);
      });
    };

    useEffect(() => {
      const node = stepRefs.current.get(currentStep);
      if (node && timelineContainerRef.current) {
        setTimeout(() => {
          const desiredScrollTop = node.offsetTop - 30; // 30px buffer from the top
          timelineContainerRef.current.scrollTo({
            top: desiredScrollTop,
            behavior: 'smooth',
          });
        }, 100);
      }
      // Stop audio if current step changes programmatically
      if (playingStep !== null && playingStep !== currentStep) {
        handlePauseAudio();
      }
    }, [currentStep]); 

    return (
      <div className="relative">
        <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200"></div>
        
        {allSteps.map((step, index) => {
            const isCompleted = completedSteps.has(index);
            const isCurrent = index === currentStep;
            const isPlaying = playingStep === index;

            return (
              <React.Fragment key={step.id}>
                <motion.div
                  ref={(el) => stepRefs.current.set(index, el)}
                  className={`relative flex items-start gap-3 pb-12 ${index === allSteps.length - 1 ? 'pb-0' : ''}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  {/* Circle Indicator */}
                  <div className={`relative z-10 flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border-2 text-sm font-bold ${
                    step.isProOffer ? (
                      isCompleted ? 'bg-orange-100 border-orange-500 text-orange-700' :
                      isCurrent ? 'bg-orange-500 border-orange-500 text-white' :
                      'bg-white border-orange-300 text-orange-500'
                    ) : (
                      isCompleted ? 'bg-green-100 border-green-500 text-green-700' :
                      isCurrent ? 'bg-[var(--primary)] border-[var(--primary)] text-[var(--primary-foreground)]' :
                      'bg-white border-gray-300 text-gray-500'
                    )
                  }`}>
                    {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : step.isProOffer || step.showProAgentOffer ? <UserCheck className="w-4 h-4" /> : index + 1}
                  </div>

                  {/* Content Wrapper */}
                  <div className={`flex-1 min-w-0 pb-2 rounded-lg transition-all duration-300 ${
                    isCurrent ? (
                      step.isProOffer ? 
                        'bg-orange-50 border border-orange-200 p-4 -ml-2' :
                        'p-4 -ml-2 step-glow'
                    ) : ''
                  }`}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <h4 className={`font-semibold text-sm md:text-base ${
                          isCurrent ? (
                            step.isProOffer ? 'text-orange-800' : 'text-blue-800 theme-dark:text-blue-200 theme-ai:text-blue-200'
                          ) : 'text-[var(--text-primary)]'
                        }`}>
                          {step.title}
                        </h4>
                      </div>
                      {step.group && (
                        <span className={`text-xs px-2 py-1 rounded ${
                          step.isProOffer || step.showProAgentOffer ? 'text-orange-600 bg-orange-100' : 'text-[var(--text-secondary)] bg-gray-100'
                        }`}>
                          {step.group}
                        </span>
                      )}
                    </div>

                    {isCurrent && (
                      <div className="mb-2 text-xs font-medium ${
                        step.isProOffer || step.showProAgentOffer ? 'text-orange-600' : 'text-blue-600 theme-dark:text-blue-300 theme-ai:text-blue-300'
                      }">
                        Current Step
                      </div>
                    )}

                    {/* NEW: Listen to Instructions Card */}
                    {isCurrent && !step.isProOffer && !step.showProAgentOffer && (
                        <Card className="bg-blue-50 border-blue-200 mt-2 mb-4 shadow-sm">
                            <CardContent className="p-3 flex items-center justify-between">
                                <h6 className="font-semibold text-blue-800 text-sm flex items-center gap-2">
                                    <Ear className="w-4 h-4" />
                                    Listen to the Instructions
                                    {/* Fixed-width container for the timer to prevent layout shifts */}
                                    <span className="text-xs text-blue-600 bg-blue-100 px-2 py-1 rounded w-12 text-center">
                                        {audioTimer}s
                                    </span>
                                </h6>
                                <div className="flex items-end justify-center gap-0.5 h-4 w-4">
                                    {isPlaying && (
                                        <>
                                            <span className="w-1 bg-blue-700 animate-sound-wave" style={{ animationDelay: '0s' }}></span>
                                            <span className="w-1 bg-blue-700 animate-sound-wave" style={{ animationDelay: '0.2s' }}></span>
                                            <span className="w-1 bg-blue-700 animate-sound-wave" style={{ animationDelay: '0.4s' }}></span>
                                        </>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* NEW: Read Instructions Card */}
                    <Card className="bg-white border-gray-200 shadow-sm">
                        <CardHeader className="p-3">
                            <CardTitle className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                                <BookOpen className="w-4 h-4" />
                                Read the Instructions
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-3 pt-0 space-y-4">
                            <div className="text-sm text-[var(--text-secondary)] break-words prose prose-sm max-w-none">
                                <ReactMarkdown
                                    components={{
                                    p: ({node, ...props}) => <p className="text-inherit" {...props} />,
                                    }}
                                >{step.description}</ReactMarkdown>
                            </div>
                            
                            {isCurrent && step.copyText && (
                                <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                                  <div className="flex items-center justify-between">
                                    <div>
                                      <div className="font-semibold text-yellow-800 text-sm mb-1">
                                        Copy this text and paste it into the "{step.previewContent?.fields[0]?.label || 'appropriate'}" field on the state website:
                                      </div>
                                      <div className="text-sm text-yellow-700 break-words">{step.copyText}</div>
                                    </div>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="ml-2 h-8 w-8 p-0 flex-shrink-0"
                                      onClick={() => handleCopyToClipboardTimeline(step.copyText, step.id)}
                                    >
                                      {copiedFieldTimeline === step.id ? <ClipboardCheck className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                                    </Button>
                                  </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    {/* Pro Offer Content */}
                    {(step.isProOffer && isCurrent) && (
                      <div className="mb-4 p-3 md:p-4 bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-lg">
                        <div className="flex items-start gap-3">
                          <div className="bg-white/20 p-2 rounded-full flex-shrink-0">
                            <UserCheck className="w-4 h-4 md:w-6 md:h-6 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h5 className="font-bold text-white mb-2 text-sm md:text-base">Professional Filing Service - $99</h5>
                            <ul className="text-white/90 text-xs md:text-sm space-y-1 mb-3 list-disc list-inside">
                              <li className="break-words">Expert handling of all paperwork</li>
                              <li className="break-words">Guaranteed accuracy and compliance</li>
                              <li className="break-words">Professional registered agent included</li>
                              <li className="break-words">Priority processing and support</li>
                            </ul>
                            <Button 
                              onClick={() => setShowProModal(true)} 
                              className="w-full bg-white text-orange-600 hover:bg-gray-100 text-xs md:text-sm px-3 py-2 font-semibold"
                            >
                              <UserCheck className="w-4 h-4 mr-2" />
                              Upgrade to Professional
                            </Button>
                            <div className="flex flex-col sm:flex-row gap-2 mt-2">
                              <Button
                                onClick={handlePreviousStep}
                                disabled={currentStep === 0}
                                variant="outline"
                                className="flex-1 bg-transparent border-white text-white hover:bg-white/10 text-xs md:text-sm px-3 py-2"
                              >
                                <ArrowLeft className="w-4 h-4 mr-2" /> Previous
                              </Button>
                              <Button
                                onClick={handleNextStep}
                                variant="outline"
                                className="flex-1 bg-transparent border-white text-white hover:bg-white/10 text-xs md:text-sm px-3 py-2"
                              >
                                Continue DIY <ArrowRight className="w-4 h-4 ml-2" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* All other existing content (website links, copy text, etc.) */}
                    {isCurrent && !(step.isProOffer || step.showProAgentOffer) && (
                      <>
                        {step.websiteUrl && (
                          <div className="my-6 p-4 bg-gradient-to-br from-yellow-50 to-amber-50 border-2 border-yellow-200 rounded-lg shadow-lg">
                              <p className="text-sm font-semibold text-amber-800 mb-3 border-b border-yellow-300 pb-2">✅ Action Required:</p>
                              <div className="flex items-start gap-3">
                                  <div className="flex-1">
                                      <div className="text-xs font-semibold text-amber-600 mb-2 uppercase tracking-wider">Click this link to open the state website in a new tab</div>
                                      <div className="relative flex items-center justify-between p-3 bg-white rounded-lg border-2 border-amber-300 shadow-md animate-enhanced-glow transform hover:scale-105 transition-transform duration-300">
                                          <a
                                              href={step.websiteUrl}
                                              target="_blank"
                                              rel="noopener noreferrer"
                                              className="inline-flex items-center gap-2 text-sm font-medium text-amber-700 hover:text-amber-900 break-all pr-2"
                                          >
                                              <ExternalLink className="w-4 h-4" />
                                              Visit {company.state} Secretary of State Website
                                          </a>
                                          <div className="relative">
                                              <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse pointer-events-none"></div>
                                          </div>
                                      </div>
                                  </div>
                                  <ArrowLeft className="w-6 h-6 text-amber-500 mt-10 flex-shrink-0 animate-bounce" />
                              </div>
                            </div>
                        )}
                        
                        {step.previewContent && (
                          <div className="my-6 p-4 bg-gradient-to-br from-yellow-50 to-amber-50 border-2 border-yellow-200 rounded-lg shadow-lg">
                            <p className="text-sm font-semibold text-amber-800 mb-3 border-b border-yellow-300 pb-2">🎯 Preview of the official state website form:</p>
                            <h5 className="text-sm font-bold text-amber-700 mb-4">{step.previewContent.title}</h5>
                            <div className="space-y-4">
                              {step.previewContent.fields && step.previewContent.fields.map((field, idx) => (
                                <div key={idx} className="flex items-start gap-3">
                                  <div className="flex-1">
                                    <div className="text-xs font-semibold text-amber-600 mb-2 uppercase tracking-wider">{field.label}</div>
                                    <div className="relative flex items-center justify-between p-3 bg-white rounded-lg border-2 border-amber-300 shadow-md animate-enhanced-glow transform hover:scale-105 transition-transform duration-300">
                                      <span className="text-sm font-medium text-gray-800 break-all pr-2">{field.value}</span>
                                      <div className="relative">
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="w-8 h-8 flex-shrink-0 bg-amber-100 hover:bg-amber-200 border border-amber-300 animate-click-hint"
                                          onClick={() => handleCopyToClipboardTimeline(field.value, `${step.id}-${idx}`)}
                                        >
                                          {copiedFieldTimeline === `${step.id}-${idx}` ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                                        </Button>
                                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse pointer-events-none"></div>
                                      </div>
                                    </div>
                                  </div>
                                  <ArrowLeft className="w-6 h-6 text-amber-500 mt-10 flex-shrink-0 animate-bounce" />
                                </div>
                              ))}
                              {step.previewContent.sections && step.previewContent.sections.map((section, sIdx) => (
                                  <div key={sIdx} className="pt-3">
                                      <h6 className="text-xs font-semibold text-amber-600 mb-3 uppercase tracking-wider">{section.title}</h6>
                                      <div className="space-y-4">
                                      {section.fields.map((field, fIdx) => (
                                          <div key={fIdx} className="flex items-start gap-3">
                                              <div className="flex-1">
                                                <div className="text-xs font-semibold text-amber-600 mb-2 uppercase tracking-wider">{field.label}</div>
                                                <div className="relative flex items-center justify-between p-3 bg-white rounded-lg border-2 border-amber-300 shadow-md animate-enhanced-glow transform hover:scale-105 transition-transform duration-300">
                                                    <span className="text-sm font-medium text-gray-800 break-all pr-2">{field.value}</span>
                                                    <div className="relative">
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            className="w-8 h-8 flex-shrink-0 bg-amber-100 hover:bg-amber-200 border border-amber-300 animate-click-hint"
                                                            onClick={() => handleCopyToClipboardTimeline(field.value, `${step.id}-${sIdx}-${fIdx}`)}
                                                        >
                                                            {copiedFieldTimeline === `${step.id}-${sIdx}-${fIdx}` ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                                                        </Button>
                                                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse pointer-events-none"></div>
                                                    </div>
                                                </div>
                                              </div>
                                              <ArrowLeft className="w-6 h-6 text-amber-500 mt-10 flex-shrink-0 animate-bounce" />
                                          </div>
                                      ))}
                                      </div>
                                  </div>
                              ))}
                            </div>
                          </div>
                        )}

                          <div className="flex justify-between items-center gap-4 mt-4">
                            <Button 
                              onClick={handlePreviousStep}
                              disabled={currentStep === 0}
                              variant="outline"
                              className="bg-gray-100 border-gray-300 text-gray-700 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              <ArrowLeft className="w-4 h-4 mr-2" />
                              Previous
                            </Button>
                            <Button 
                              onClick={handleNextStep}
                              className="bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[var(--primary)]/90"
                            >
                              {currentStep === allSteps.length - 1 ? 'Finish' : 'Next Step'}
                              {currentStep !== allSteps.length - 1 && <ArrowRight className="w-4 h-4 ml-2" />}
                            </Button>
                          </div>
                      </>
                    )}
                      {step.showProAgentOffer && isCurrent && (
                        <div className="mb-4 mt-2 p-3 md:p-4 bg-green-50 border border-green-200 rounded-lg theme-dark:bg-green-900/20 theme-dark:border-green-800 theme-ai:bg-green-900/20 theme-ai:border-green-800">
                          <div className="flex items-start gap-3">
                              <UserCheck className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
                              <div className="flex-1 min-w-0">
                                  <h6 className="font-bold text-green-800 theme-dark:text-green-200 theme-ai:text-green-200 mb-2 text-sm">Our Professional Registered Agent Service - $99/year</h6>
                                  <ul className="text-green-700 theme-dark:text-green-300 theme-ai:text-green-300 text-xs md:text-sm space-y-1 list-disc list-inside">
                                      <li className="break-words">Complete Privacy: Your personal address stays private</li>
                                      <li className="break-words">Zero Risk: Professional address, not your home</li>
                                      <li className="break-words">100% Reliable: We never miss important legal documents</li>
                                      <li className="break-words">Full Compliance: Licensed and compliant in all 50 states</li>
                                  </ul>
                                  <div className="flex gap-2 mt-4">
                                      <Button 
                                          onClick={() => setShowProModal(true)}
                                          className="bg-green-600 hover:bg-green-700 text-white text-xs md:text-sm px-4 py-2 font-semibold"
                                      >
                                          <UserCheck className="w-4 h-4 mr-2" />
                                          Get Professional Agent Service
                                      </Button>
                                      <Button 
                                          onClick={handleNextStep}
                                          variant="outline"
                                          className="border-[var(--border)] text-[var(--text-primary)] hover:bg-[var(--accent)] text-xs md:text-sm px-4 py-2 font-semibold"
                                      >
                                          Continue DIY
                                      </Button>
                                  </div>
                              </div>
                          </div>
                        </div>
                      )}

                      {step.showAgentWarning && isCurrent && (
                        <div className="mb-4 p-3 md:p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                          <div className="flex items-start gap-2">
                            <AlertTriangle className="w-5 h-5 text-yellow-600 mt-1 flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <h6 className="font-bold text-yellow-800 mb-2 text-sm">Warning: Being Your Own Agent</h6>
                              <ul className="text-yellow-700 text-xs md:text-sm space-y-1 list-disc list-inside">
                                <li className="break-words">Your home address becomes public record</li>
                                <li className="break-words">Anyone can find your personal address online</li>
                                <li className="break-words">Missing legal documents can result in penalties</li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      )}

                  </div>
                </motion.div>
              </React.Fragment>
            );
        })}
      </div>
    );
  };

  const completedCount = completedSteps.has(currentStep) ? completedSteps.size : completedSteps.size + 1;
  const progressPercentage = allSteps.length > 0 ? Math.round((completedCount / (allSteps.length + 1)) * 100) : 0;

  return (
    <div className="fixed inset-0 bg-[var(--background)] flex flex-col z-50">
      <style jsx global>{`
        @property --angle {
          syntax: '<angle>';
          initial-value: 0deg;
          inherits: false;
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: hsl(var(--border) / 0.5);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: hsl(var(--primary) / 0.7);
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: hsl(var(--primary));
        }
        .custom-scrollbar {
          scrollbar-width: thin;
          scrollbar-color: hsl(var(--primary) / 0.7) hsl(var(--border) / 0.5);
        }
        .step-glow {
          position: relative;
          background: var(--accent);
          z-index: 1;
          /* The border is animated using border-image */
          border: 2px solid transparent;
          border-image: conic-gradient(from var(--angle), transparent 25%, hsl(var(--primary)), hsl(var(--primary)/0.8) 75%, transparent) 1;
          animation: rotate-border 4s linear infinite;
        }
        
        @keyframes rotate-border {
          to {
            --angle: 360deg;
          }
        }
        @keyframes sound-wave {
          0%, 100% { height: 2px; }
          50% { height: 16px; }
        }
        .animate-sound-wave {
          display: inline-block;
          animation: sound-wave 1.2s ease-in-out infinite;
        }
        @keyframes enhanced-glow {
          0%, 100% { 
            box-shadow: 0 0 20px 7px rgba(251, 191, 36, 0.7);
            transform: scale(1.02);
          }
          50% { 
            box-shadow: 0 0 35px 12px rgba(251, 191, 36, 1);
            transform: scale(1.05);
          }
        }
        @keyframes click-hint {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.1); }
        }
        .animate-click-hint {
          animation: click-hint 1.5s ease-in-out infinite;
        }
        @keyframes bounce {
            0%, 100% {
                transform: translateX(0);
            }
            50% {
                transform: translateX(-10px);
            }
        }
        .animate-bounce {
            animation: bounce 1s infinite;
        }
      `}</style>
      {/* Header */}
      <div className="flex-shrink-0 p-4 border-b border-[var(--border)] flex items-center justify-between">
          <h2 className="text-lg font-bold flex items-center gap-2 text-[var(--text-primary)]">
              <Logo className="w-6 h-6 text-[var(--primary)]" />
              <span>🚀Launch {company.company_name}, {company.legal_ending}</span>
          </h2>
          <Button variant="ghost" size="icon" onClick={() => {
            localStorage.removeItem(`frinc-progress-${company.id}`);
            handlePauseAudio(); // Stop audio on close
            onClose();
          }} className="text-[var(--text-secondary)] hover:bg-[var(--secondary)] rounded-full h-10 w-10">
              <X className="w-5 h-5" />
          </Button>
      </div>

      {/* Content */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-[1fr_280px] lg:grid-cols-[1fr_320px] overflow-hidden">
          {/* Main Content - Left Side */}
          <div className="flex-1 flex flex-col overflow-hidden">
              <div className="p-4 md:p-6 border-b border-[var(--border)]">
                  <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-[var(--text-primary)]">Filing Progress</h3>
                      <span className="text-sm text-[var(--text-secondary)]">{progressPercentage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <motion.div 
                      className="bg-[var(--primary)] h-2 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${progressPercentage}%` }}
                      transition={{ duration: 0.5, ease: "easeInOut" }}
                    />
                  </div>
              </div>
              <div ref={timelineContainerRef} className="flex-1 overflow-y-auto p-3 md:p-4 pb-24 md:pb-4" style={{ scrollbarWidth: 'thin', scrollbarColor: 'hsl(var(--primary) / 0.7) hsl(var(--border) / 0.5)' }}>
                <div className="w-full max-w-3xl mx-auto">
                  <Timeline />
                </div>
              </div>
          </div>
          <div className="hidden md:block w-full border-l border-[var(--border)] min-h-0">
              <DetailsPanel />
          </div>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showProModal && <ProModal />}
        {showCompletionAnimation && (
          <CompletionAnimation onComplete={() => {
            setShowCompletionAnimation(false);
            setShowInitialReview(true);
          }} />
        )}
        {showInitialReview && (
          <InitialReviewModal 
            onYes={() => {
              setShowInitialReview(false);
              setShowReviewModal(true);
            }}
            onNo={() => {
              localStorage.removeItem(`frinc-progress-${company.id}`);
              setShowInitialReview(false);
              onClose();
            }}
          />
        )}
        {showReviewModal && (
          <ReviewModal 
            onNextSection={() => {
              localStorage.removeItem(`frinc-progress-${company.id}`);
              setShowReviewModal(false);
              onClose();
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
