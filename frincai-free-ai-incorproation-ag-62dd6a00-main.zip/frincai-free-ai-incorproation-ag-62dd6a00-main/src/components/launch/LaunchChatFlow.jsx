
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { InvokeLLM } from '@/api/integrations';
import Logo from '../Logo';
import { X, ExternalLink, Copy, ClipboardCheck, Check } from 'lucide-react';
import { stateInfo as allStateInfo } from './stateInfo';
import ChatMessage from '../chat/ChatMessage';
import SuggestedReplies from '../chat/SuggestedReplies';
import TextInput from '../chat/TextInput';
import StateFilingSimulation from './StateFilingSimulation';

export default function LaunchChatFlow({ company, onComplete, onClose }) {
  const [messages, setMessages] = useState([]);
  const [suggestedReplies, setSuggestedReplies] = useState([]);
  const [isAiTyping, setIsAiTyping] = useState(false);
  const [stage, setStage] = useState('START');
  const [nameSearchResults, setNameSearchResults] = useState('');
  const [isCheckingName, setIsCheckingName] = useState(false);
  const [nameCheckResult, setNameCheckResult] = useState(null);
  const [copiedStates, setCopiedStates] = useState({});
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [showFilingSimulation, setShowFilingSimulation] = useState(false);
  const chatContainerRef = useRef(null);

  const stateInfo = allStateInfo[company.state] || allStateInfo['Default'];

  const allSteps = [
    // Name Search
    { id: 'name_1', group: 'Name Availability', title: 'Visit State Website', description: `First, let's head over to the official ${stateInfo.name} Secretary of State website to use their name search tool.`, websiteUrl: stateInfo.sos_url },
    { id: 'name_2', group: 'Name Availability', title: 'Copy Company Name', description: 'Click the button below to copy your full proposed company name to your clipboard.', copyText: `${company.company_name}, ${company.legal_ending}` },
    { id: 'name_3', group: 'Name Availability', title: 'Search for Your Name', description: `On the state's website, find the business name search tool and paste your copied name into the field.` },
    { id: 'name_4', group: 'Name Availability', title: 'Analyze Results', description: 'Look at the search results. If you see another business with the exact same name or a very similar name, your name may be rejected.' },
    { id: 'name_5', group: 'Name Availability', title: 'Submit for AI Review', description: 'For peace of mind, paste the full text of the search results below. Our AI will perform a final check for you.', hasNameCheck: true },

    // Registered Agent
    { id: 'agent_1', group: 'Registered Agent', title: 'What is a Registered Agent?', description: `Every LLC and Corporation must have a Registered Agent. This is a person or service with a physical address in ${company.state} who can receive official mail.` },
    { id: 'agent_2', group: 'Registered Agent', title: 'Your Options', description: 'You can be your own agent if you have an address in the state, use a friend, or hire a professional service (recommended for privacy and reliability).' },
    { id: 'agent_3', group: 'Registered Agent', title: 'Find a Service', description: 'If you need a service, you can find many online. Search for "Registered Agent service in ' + company.state + '".' },
    { id: 'agent_4', group: 'Registered Agent', title: 'Gather Agent Info', description: "You'll need the Registered Agent's full name and physical address for your filing documents. Make sure you have it ready." },
    
    // Filing Documents
    { id: 'file_1', group: 'File Formation Documents', title: 'Document Needed', description: `For an LLC, you'll file the "Articles of Organization." For a Corporation, it's the "Articles of Incorporation."` },
    { id: 'file_2', group: 'File Formation Documents', title: 'Find Online Portal', description: `Most states, including ${company.state}, offer an online portal for filings. Navigate to this section on the Secretary of State website.` },
    { id: 'file_3', group: 'File Formation Documents', title: 'Company Name & Address', description: 'Enter your company name exactly as we checked it, along with your principal business address.' },
    { id: 'file_4', group: 'File Formation Documents', title: 'Enter Registered Agent', description: "Enter the full name and physical address of your chosen Registered Agent." },
    { id: 'file_5', group: 'File Formation Documents', title: 'Owners / Members', description: "List the names and addresses of all company owners (also called Members or Incorporators)." },
    { id: 'file_6', group: 'File Formation Documents', title: 'Management Structure', description: "Indicate how the company will be managed (e.g., by members, managers, or a board of directors)." },
    { id: 'file_7', group: 'File Formation Documents', title: 'Review Your Application', description: 'Carefully review all the information you have entered for accuracy. Typos can cause delays or rejections.' },
    { id: 'file_8', group: 'File Formation Documents', title: 'Sign and Submit', description: 'Electronically sign the document as the organizer or incorporator.' },
    { id: 'file_9', group: 'File Formation Documents', title: 'Pay State Filing Fee', description: `Pay the state's mandatory filing fee. For ${company.state}, this is typically around $${stateInfo.fee}.` },
    { id: 'file_10', group: 'File Formation Documents', title: 'Await Confirmation', description: 'After submitting, you will receive a confirmation. It may take several days for the state to officially approve your company.' },

    // Post-Registration
    { id: 'post_1', group: 'Post-Registration Setup', title: 'Obtain an EIN', description: 'After your company is approved, get an Employer Identification Number (EIN) from the IRS. It\'s free and needed for banking and taxes.' },
    { id: 'post_2', group: 'Post-Registration Setup', title: 'Operating Agreement', description: 'For LLCs, draft an Operating Agreement. This internal document outlines ownership and operating procedures.' },
    { id: 'post_3', group: 'Post-Registration Setup', title: 'Open a Business Bank Account', description: 'Use your formation documents and EIN to open a dedicated bank account for your business.' },
    { id: 'post_4', group: 'Post-Registration Setup', title: 'Business Licenses', description: 'Check for any local, state, or federal licenses and permits required for your industry.' },
  ];

  useEffect(() => {
    startLaunchConversation();
  }, []);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const addMessage = (sender, text) => {
    setMessages(prev => [...prev, { sender, text }]);
  };

  const startLaunchConversation = () => {
    setMessages([]);
    addMessage('ai', `Great! Let's register **${company.company_name}, ${company.legal_ending}** in ${company.state}.`);
    addMessage('ai', 'I\'ll guide you through every step of the official registration process. Ready to begin?');
    setSuggestedReplies(["Let's start!", "Get Pro Launch ($99)"]);
    setStage('START');
    setIsAiTyping(false);
  };

  const handleReply = (reply) => {
    addMessage('user', typeof reply === 'string' ? reply : reply.label);
    setSuggestedReplies([]);
    setIsAiTyping(true);

    setTimeout(() => {
      processReply(reply);
    }, 1000);
  };

  const processReply = (reply) => {
    switch (stage) {
      case 'START':
        if (reply === "Let's start!") {
          addMessage('ai', "Perfect! Let me show you exactly how to file your formation documents. I'll simulate the real state website and guide you through each field.");
          addMessage('ai', "Ready to see the actual filing process?");
          setSuggestedReplies(['Show me the filing process', 'Get Pro Launch ($99)']);
          setStage('FILING_INTRO');
        } else if (reply === "Get Pro Launch ($99)") {
          showProLaunchOffer();
        }
        break;

      case 'FILING_INTRO':
        if (reply === 'Show me the filing process') {
          addMessage('ai', "Great! Opening the state filing simulation now...");
          setIsAiTyping(true);
          setTimeout(() => {
            setShowFilingSimulation(true);
            setIsAiTyping(false);
          }, 1500);
        } else if (reply === 'Get Pro Launch ($99)') {
          showProLaunchOffer();
        }
        break;

      case 'FILING_COMPLETE':
        if (reply === 'Continue Guide') {
          addMessage('ai', "Excellent! You now know exactly how to file your formation documents.");
          addMessage('ai', "🎉 You're ready to officially register your company! You can close this guide and manage your company from the dashboard.");
          setSuggestedReplies(['Complete Registration']);
          setStage('COMPLETE');
        }
        break;

      case 'STEP':
        if (reply === 'Continue to Next Step') {
          if (currentStepIndex < allSteps.length - 1) {
            setCurrentStepIndex(prev => prev + 1);
            showCurrentStep();
          } else {
            addMessage('ai', "🎉 Congratulations! You've completed all the steps to register your company!");
            addMessage('ai', "Your company should now be officially registered. You can close this guide and return to your dashboard.");
            setSuggestedReplies(['Complete Registration']);
            setStage('COMPLETE');
          }
        } else if (reply === 'Get Pro Launch ($99)') {
          showProLaunchOffer();
        } else if (reply === 'Previous Step') {
          if (currentStepIndex > 0) {
            setCurrentStepIndex(prev => prev - 1);
            showCurrentStep();
          }
        }
        break;

      case 'NAME_CHECK':
        if (reply === 'Check Name Availability') {
          handleNameCheck();
        } else if (reply === 'Continue to Next Step') {
          if (currentStepIndex < allSteps.length - 1) {
            setCurrentStepIndex(prev => prev + 1);
            showCurrentStep();
          }
        }
        break;

      case 'COMPLETE':
        onComplete();
        break;

      case 'PRO_LAUNCH':
        if (reply === 'Get Pro Launch') {
          addMessage('ai', "Great choice! Pro Launch checkout is not yet implemented, but you'll be redirected to our payment page.");
          setSuggestedReplies(['Back to Guide']);
          setStage('PRO_LAUNCH_CHECKOUT');
        } else if (reply === 'Continue with Guide') {
          setCurrentStepIndex(0);
          showCurrentStep();
        }
        break;

      case 'PRO_LAUNCH_CHECKOUT':
        setCurrentStepIndex(0);
        showCurrentStep();
        break;
    }
    setIsAiTyping(false);
  };

  const showCurrentStep = () => {
    const step = allSteps[currentStepIndex];
    if (!step) return;

    addMessage('ai', `**Step ${currentStepIndex + 1}: ${step.title}**`);
    addMessage('ai', step.description);

    const replies = ['Continue to Next Step'];
    if (currentStepIndex > 0) replies.unshift('Previous Step');
    replies.push('Get Pro Launch ($99)');

    if (step.hasNameCheck) {
      setSuggestedReplies(['Check Name Availability', 'Continue to Next Step', 'Get Pro Launch ($99)']);
      setStage('NAME_CHECK');
    } else {
      setSuggestedReplies(replies);
      setStage('STEP');
    }

    // Add action buttons for specific steps
    if (step.websiteUrl) {
      setTimeout(() => {
        addMessage('ai', `[Click here to visit the official website](${step.websiteUrl})`);
      }, 500);
    }

    if (step.copyText) {
      setTimeout(() => {
        addMessage('ai', `**Copy this text:** ${step.copyText}`);
      }, 500);
    }
  };

  const showProLaunchOffer = () => {
    addMessage('ai', "**Pro Launch - $99**");
    addMessage('ai', "Let us handle everything for you. Save time, avoid mistakes, and get peace of mind.");
    addMessage('ai', "✅ **Save Time & Effort** - We handle all the paperwork and filing\n✅ **Ensure Accuracy** - Our experts ensure your filing is done correctly\n✅ **Total Peace of Mind** - We navigate the state bureaucracy for you");
    setSuggestedReplies(['Get Pro Launch', 'Continue with Guide']);
    setStage('PRO_LAUNCH');
  };

  const handleNameCheck = async () => {
    if (!nameSearchResults.trim()) {
      addMessage('ai', "Please paste the search results first, then I can check them for you.");
      return;
    }

    setIsCheckingName(true);
    addMessage('ai', "Let me analyze those search results for you...");
    
    try {
      const prompt = `Based on these user-provided search results from the ${stateInfo.name} Secretary of State website, is the company name "${company.company_name}, ${company.legal_ending}" available? Search results: "${nameSearchResults}"`;
      const result = await InvokeLLM({ prompt });
      addMessage('ai', `**AI Analysis:** ${result}`);
    } catch (error) {
      console.error("Name check failed:", error);
      addMessage('ai', "Sorry, the AI check failed. Please manually review the results.");
    } finally {
      setIsCheckingName(false);
      setSuggestedReplies(['Continue to Next Step', 'Get Pro Launch ($99)']);
      setStage('STEP');
    }
  };

  if (showFilingSimulation) {
    return (
      <StateFilingSimulation
        company={company}
        onComplete={() => {
          setShowFilingSimulation(false);
          addMessage('ai', "Perfect! You've seen exactly how to fill out the state forms with your company information.");
          setSuggestedReplies(['Continue Guide']);
          setStage('FILING_COMPLETE');
        }}
        onClose={() => {
          setShowFilingSimulation(false);
          addMessage('ai', "No problem. Would you like to continue with other parts of the registration process?");
          setSuggestedReplies(['Show filing process again', 'Get Pro Launch ($99)']);
          setStage('FILING_INTRO');
        }}
      />
    );
  }

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="w-full max-w-2xl h-[85vh] flex flex-col bg-[var(--background)] rounded-2xl shadow-2xl border border-[var(--border)] relative overflow-hidden"
      >
        <div className="flex-shrink-0 p-4 border-b border-[var(--border)] flex items-center justify-between">
          <h2 className="text-lg font-bold flex items-center justify-center gap-2">
            <Logo className="w-6 h-6 text-[var(--primary)]" />
            <span>Company Registration Guide</span>
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-[var(--text-secondary)] hover:bg-[var(--secondary)] rounded-full h-10 w-10">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div ref={chatContainerRef} className="flex-1 p-4 overflow-y-auto custom-scrollbar">
          <AnimatePresence>
            {messages.map((msg, index) => (
              <ChatMessage key={index} message={msg} />
            ))}
          </AnimatePresence>
          {isAiTyping && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="flex items-end gap-2 my-2 justify-start"
            >
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[var(--primary)] text-[var(--primary-foreground)] flex items-center justify-center border-2 border-[var(--background)] shadow-md">
                <Logo className="w-5 h-5" />
              </div>
              <div className="px-4 py-3 rounded-2xl bg-[var(--secondary)] text-[var(--text-primary)] rounded-bl-none">
                <div className="flex items-center justify-center gap-1">
                  <span className="w-2 h-2 bg-current rounded-full animate-bounce" />
                  <span className="w-2 h-2 bg-current rounded-full animate-bounce" style={{animationDelay: '0.2s'}} />
                  <span className="w-2 h-2 bg-current rounded-full animate-bounce" style={{animationDelay: '0.4s'}} />
                </div>
              </div>
            </motion.div>
          )}
        </div>

        <div className="flex-shrink-0 border-t border-[var(--border)] bg-[var(--background)] rounded-b-2xl">
          {stage === 'NAME_CHECK' && !nameSearchResults ? (
            <TextInput
              onSubmit={(text) => {
                setNameSearchResults(text);
                handleReply('Check Name Availability');
              }}
              placeholder="Paste the name search results here..."
              disabled={isAiTyping || isCheckingName}
            />
          ) : (
            <SuggestedReplies replies={suggestedReplies} onSelect={handleReply} disabled={isAiTyping || isCheckingName} />
          )}
        </div>
      </motion.div>
    </div>
  );
}
