
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { InvokeLLM } from '@/api/integrations';
import Logo from '../Logo';
import { Rocket, ExternalLink, ArrowRight, ChevronLeft, ShieldCheck, Zap, Clock, Copy, ClipboardCheck, X, Check, MapPin, FileText, Banknote, Briefcase } from 'lucide-react';
import { stateInfo as allStateInfo } from './stateInfo';

export default function LaunchFlow({ company, onComplete, onClose }) {
  const [currentView, setCurrentView] = useState('overview'); // overview, steps, navigation, proLaunch
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [nameSearchResults, setNameSearchResults] = useState('');
  const [isCheckingName, setIsCheckingName] = useState(false);
  const [nameCheckResult, setNameCheckResult] = useState(null);
  const [copiedStates, setCopiedStates] = useState({});

  const stateInfo = allStateInfo[company.state] || allStateInfo['Default'];

  const allSteps = [
    // Name Search
    { id: 'name_1', group: 'Name Availability', title: 'Visit State Website', icon: ExternalLink, description: `First, let's head over to the official ${stateInfo.name} Secretary of State website to use their name search tool.`, websiteUrl: stateInfo.sos_url },
    { id: 'name_2', group: 'Name Availability', title: 'Copy Company Name', icon: Copy, description: 'Click the button below to copy your full proposed company name to your clipboard.', copyText: `${company.company_name}, ${company.legal_ending}` },
    { id: 'name_3', group: 'Name Availability', title: 'Search for Your Name', icon: FileText, description: `On the state's website, find the business name search tool and paste your copied name into the field.` },
    { id: 'name_4', group: 'Name Availability', title: 'Analyze Results', icon: ShieldCheck, description: 'Look at the search results. If you see another business with the exact same name or a very similar name, your name may be rejected.' },
    { id: 'name_5', group: 'Name Availability', title: 'Submit for AI Review', icon: Zap, description: 'For peace of mind, paste the full text of the search results below. Our AI will perform a final check for you.', hasNameCheck: true },

    // Registered Agent
    { id: 'agent_1', group: 'Registered Agent', title: 'What is a Registered Agent?', icon: MapPin, description: `Every LLC and Corporation must have a Registered Agent. This is a person or service with a physical address in ${company.state} who can receive official mail.` },
    { id: 'agent_2', group: 'Registered Agent', title: 'Your Options', icon: MapPin, description: 'You can be your own agent if you have an address in the state, use a friend, or hire a professional service (recommended for privacy and reliability).' },
    { id: 'agent_3', group: 'Registered Agent', title: 'Find a Service', icon: MapPin, description: 'If you need a service, you can find many online. Search for "Registered Agent service in ' + company.state + '".' },
    { id: 'agent_4', group: 'Registered Agent', title: 'Gather Agent Info', icon: MapPin, description: "You'll need the Registered Agent's full name and physical address for your filing documents. Make sure you have it ready." },
    
    // Filing Documents
    { id: 'file_1', group: 'File Formation Documents', title: 'Document Needed', icon: FileText, description: `For an LLC, you'll file the "Articles of Organization." For a Corporation, it's the "Articles of Incorporation."` },
    { id: 'file_2', group: 'File Formation Documents', title: 'Find Online Portal', icon: FileText, description: `Most states, including ${company.state}, offer an online portal for filings. Navigate to this section on the Secretary of State website.` },
    { id: 'file_3', group: 'File Formation Documents', title: 'Company Name & Address', icon: FileText, description: 'Enter your company name exactly as we checked it, along with your principal business address.' },
    { id: 'file_4', group: 'File Formation Documents', title: 'Enter Registered Agent', icon: FileText, description: "Enter the full name and physical address of your chosen Registered Agent." },
    { id: 'file_5', group: 'File Formation Documents', title: 'Owners / Members', icon: FileText, description: "List the names and addresses of all company owners (also called Members or Incorporators)." },
    { id: 'file_6', group: 'File Formation Documents', title: 'Management Structure', icon: FileText, description: "Indicate how the company will be managed (e.g., by members, managers, or a board of directors)." },
    { id: 'file_7', group: 'File Formation Documents', title: 'Review Your Application', icon: FileText, description: 'Carefully review all the information you have entered for accuracy. Typos can cause delays or rejections.' },
    { id: 'file_8', group: 'File Formation Documents', title: 'Sign and Submit', icon: FileText, description: 'Electronically sign the document as the organizer or incorporator.' },
    { id: 'file_9', group: 'File Formation Documents', title: 'Pay State Filing Fee', icon: FileText, description: `Pay the state's mandatory filing fee. For ${company.state}, this is typically around $${stateInfo.fee}.` },
    { id: 'file_10', group: 'File Formation Documents', title: 'Await Confirmation', icon: FileText, description: 'After submitting, you will receive a confirmation. It may take several days for the state to officially approve your company.' },

    // Post-Registration
    { id: 'post_1', group: 'Post-Registration Setup', title: 'Obtain an EIN', icon: Banknote, description: 'After your company is approved, get an Employer Identification Number (EIN) from the IRS. It\'s free and needed for banking and taxes.' },
    { id: 'post_2', group: 'Post-Registration Setup', title: 'Operating Agreement', icon: Briefcase, description: 'For LLCs, draft an Operating Agreement. This internal document outlines ownership and operating procedures.' },
    { id: 'post_3', group: 'Post-Registration Setup', title: 'Open a Business Bank Account', icon: Banknote, description: 'Use your formation documents and EIN to open a dedicated bank account for your business.' },
    { id: 'post_4', group: 'Post-Registration Setup', title: 'Business Licenses', icon: Briefcase, description: 'Check for any local, state, or federal licenses and permits required for your industry.' },
  ];

  const handleNext = () => {
    if (currentStepIndex < allSteps.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
      setNameCheckResult(null);
    } else {
      onComplete();
    }
  };

  const handleBack = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
      setNameCheckResult(null);
    }
  };
  
  const handleCopyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedStates(prev => ({ ...prev, [id]: true }));
    setTimeout(() => {
        setCopiedStates(prev => ({ ...prev, [id]: false }));
    }, 2000);
  };

  const handleNameCheck = async () => {
    setIsCheckingName(true);
    setNameCheckResult(null);
    try {
      const prompt = `Based on these user-provided search results from the ${stateInfo.name} Secretary of State website, is the company name "${company.company_name}, ${company.legal_ending}" available? Search results: "${nameSearchResults}"`;
      const result = await InvokeLLM({ prompt });
      setNameCheckResult(result);
    } catch (error) {
      console.error("Name check failed:", error);
      setNameCheckResult("Sorry, the AI check failed. Please manually review the results.");
    } finally {
      setIsCheckingName(false);
    }
  };

  const renderCurrentView = () => {
    switch(currentView) {
      case 'overview':
        return <OverviewScreen />;
      case 'steps':
        return <StepsScreen />;
      case 'navigation':
        return <NavigationScreen />;
      case 'proLaunch':
        return <ProLaunchScreen />;
      default:
        return <OverviewScreen />;
    }
  };

  const OverviewScreen = () => (
    <motion.div
      key="overview"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="h-full flex flex-col items-center justify-center p-6 text-center bg-[var(--background)]"
    >
      <Logo className="w-16 h-16 text-[var(--primary)] mb-4" />
      <h2 className="text-2xl font-bold text-[var(--text-primary)] mb-2">Registration Guide</h2>
      <p className="text-[var(--text-secondary)] mb-6">
        You're about to start the incorporation process for <strong className="text-[var(--text-primary)]">{company.company_name}, {company.legal_ending}</strong> in <strong className="text-[var(--text-primary)]">{company.state}</strong>.
      </p>
      <p className="text-sm text-[var(--text-secondary)] mb-8">
        This interactive guide will walk you through every official step required by the state.
      </p>
      <Button onClick={() => setCurrentView('steps')} size="lg" className="group relative overflow-hidden w-full bg-[var(--primary)] text-[var(--primary-foreground)]">
        <span className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity duration-200"></span>
        <span className="relative flex items-center justify-center">
          Let's Begin <ArrowRight className="w-5 h-5 ml-2" />
        </span>
      </Button>
    </motion.div>
  );

  const ProLaunchScreen = () => (
    <motion.div
      key="proLaunch"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="h-full flex flex-col p-6 text-center bg-[var(--background)] custom-scrollbar overflow-y-auto"
    >
      <div className="flex-1">
        <ShieldCheck className="w-12 h-12 text-green-400 mb-4 mx-auto" />
        <h2 className="text-xl font-bold text-[var(--text-primary)] mb-2">Launch with a Pro</h2>
        <p className="text-[var(--text-primary)] font-bold text-3xl mb-4">$99</p>
        <p className="text-[var(--text-secondary)] text-sm mb-6">
          Let us handle everything for you. Save time, avoid mistakes, and get peace of mind.
        </p>

        <div className="space-y-3 text-left mb-8">
            <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-green-400 mt-1 flex-shrink-0" />
                <div>
                    <h4 className="font-semibold text-[var(--text-primary)]">Save Time & Effort</h4>
                    <p className="text-xs text-[var(--text-secondary)]">We handle all the paperwork and filing so you can focus on your business.</p>
                </div>
            </div>
            <div className="flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-green-400 mt-1 flex-shrink-0" />
                <div>
                    <h4 className="font-semibold text-[var(--text-primary)]">Ensure Accuracy</h4>
                    <p className="text-xs text-[var(--text-secondary)]">Our experts ensure your filing is done correctly, avoiding costly delays.</p>
                </div>
            </div>
             <div className="flex items-start gap-3">
                <Zap className="w-5 h-5 text-green-400 mt-1 flex-shrink-0" />
                <div>
                    <h4 className="font-semibold text-[var(--text-primary)]">Total Peace of Mind</h4>
                    <p className="text-xs text-[var(--text-secondary)]">We'll navigate the state bureaucracy and confirm when your company is officially registered.</p>
                </div>
            </div>
        </div>
      </div>

      <div className="flex-shrink-0 space-y-3">
        <Button onClick={() => alert('Pro Launch checkout is not yet implemented.')} className="group relative overflow-hidden w-full bg-green-500 hover:bg-green-600 text-white font-bold">
            <span className="absolute inset-0 bg-black opacity-0 group-hover:opacity-20 transition-opacity duration-200"></span>
            <span className="relative">Get ProLaunch for $99</span>
        </Button>
        <Button onClick={() => setCurrentView('steps')} variant="ghost" className="text-[var(--text-secondary)]">
            No thanks, I'll do it myself
        </Button>
      </div>
    </motion.div>
  );

  const NavigationScreen = () => {
      const groupedSteps = allSteps.reduce((acc, step) => {
          (acc[step.group] = acc[step.group] || []).push(step);
          return acc;
      }, {});

      return (
          <motion.div
              key="navigation"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="h-full flex flex-col p-4 bg-[var(--background)]"
          >
              <div className="flex items-center justify-between mb-4 flex-shrink-0">
                <h3 className="font-bold text-[var(--text-primary)]">All Steps</h3>
                <Button variant="ghost" size="icon" onClick={() => setCurrentView('steps')} className="text-[var(--text-secondary)]">
                    <X className="w-5 h-5" />
                </Button>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar">
                {Object.entries(groupedSteps).map(([group, stepsInGroup]) => (
                    <div key={group} className="mb-4">
                        <h4 className="font-semibold text-[var(--primary)] text-sm mb-2 px-2">{group}</h4>
                        <div className="space-y-1">
                          {stepsInGroup.map(step => {
                              const stepIndex = allSteps.findIndex(s => s.id === step.id);
                              return (
                                  <button
                                      key={step.id}
                                      onClick={() => {
                                          setCurrentStepIndex(stepIndex);
                                          setCurrentView('steps');
                                      }}
                                      className={`w-full text-left p-2 rounded-md flex items-center gap-3 text-sm transition-colors ${
                                          currentStepIndex === stepIndex ? 'bg-[var(--accent)] text-[var(--text-primary)]' : 'text-[var(--text-secondary)] hover:bg-[var(--secondary)]'
                                      }`}
                                  >
                                    <span className={`flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold flex-shrink-0 ${currentStepIndex > stepIndex ? 'bg-green-500 text-white' : 'bg-[var(--secondary)]'}`}>
                                      {currentStepIndex > stepIndex ? <Check className="w-4 h-4" /> : stepIndex + 1}
                                    </span>
                                    <span>{step.title}</span>
                                  </button>
                              );
                          })}
                        </div>
                    </div>
                ))}
              </div>
          </motion.div>
      )
  };

  const StepsScreen = () => {
    const currentStep = allSteps[currentStepIndex];
    if (!currentStep) return null;

    return (
      <motion.div
        key={currentStepIndex}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="h-full flex flex-col bg-[var(--background)]"
      >
        {/* Sticky Header */}
        <div className="flex-shrink-0 p-3 border-b border-[var(--border)]">
          <Button onClick={() => setCurrentView('navigation')} variant="outline" className="w-full bg-[var(--secondary)] hover:bg-[var(--accent)] border-[var(--border)]">
            Navigate ({currentStepIndex + 1}/{allSteps.length})
          </Button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
          <div className="text-center mb-4">
            <div className="w-10 h-10 bg-[hsl(var(--primary)/0.1)] text-[var(--primary)] rounded-full flex items-center justify-center mx-auto mb-3">
              <currentStep.icon className="w-5 h-5" />
            </div>
            <p className="text-xs text-[var(--text-secondary)] uppercase font-semibold tracking-wider">{currentStep.group}</p>
            <h2 className="text-lg font-bold text-[var(--text-primary)] mt-1">{currentStep.title}</h2>
          </div>
          <div className="bg-[var(--secondary)] border border-[var(--border)] rounded-lg p-4">
            <p className="text-[var(--text-secondary)] text-sm text-center leading-relaxed">{currentStep.description}</p>
            
            {currentStep.websiteUrl && (
              <a href={currentStep.websiteUrl} target="_blank" rel="noopener noreferrer" className="mt-4 block">
                <Button className="group relative overflow-hidden w-full bg-[var(--primary)] text-[var(--primary-foreground)]">
                    <span className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity duration-200"></span>
                    <span className="relative flex items-center justify-center">
                      <ExternalLink className="w-4 h-4 mr-2" /> Visit Official Website
                    </span>
                </Button>
              </a>
            )}
            
            {currentStep.copyText && (
              <Button 
                onClick={() => handleCopyToClipboard(currentStep.copyText, currentStep.id)}
                className="group relative overflow-hidden w-full mt-4 bg-[var(--primary)] text-[var(--primary-foreground)]"
              >
                <span className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity duration-200"></span>
                <span className="relative flex items-center justify-center">
                  {copiedStates[currentStep.id] ? <ClipboardCheck className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                  {copiedStates[currentStep.id] ? 'Copied!' : 'Copy to Clipboard'}
                </span>
              </Button>
            )}

            {currentStep.hasNameCheck && (
              <div className="mt-4">
                <Textarea
                  placeholder="Paste name search results here..."
                  value={nameSearchResults}
                  onChange={(e) => setNameSearchResults(e.target.value)}
                  className="bg-[var(--background)] border-[var(--border)] text-sm mb-2"
                  rows={5}
                />
                <Button onClick={handleNameCheck} disabled={!nameSearchResults.trim() || isCheckingName} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                  {isCheckingName ? 'AI is Checking...' : 'Check Availability'}
                </Button>
                {nameCheckResult && (
                  <div className="mt-3 text-xs text-left p-3 bg-[var(--background)] rounded-md">
                    <p className="font-bold text-blue-400 mb-1">AI Analysis:</p>
                    <p className="text-[var(--text-secondary)]">{nameCheckResult}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Fixed Footer */}
        <div className="flex-shrink-0 p-3 border-t border-[var(--border)] space-y-2">
           <Button onClick={() => setCurrentView('proLaunch')} className="group relative overflow-hidden w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold text-sm py-3">
             <span className="absolute inset-0 bg-black opacity-0 group-hover:opacity-20 transition-opacity duration-200"></span>
             <span className="relative">Launch with a Pro ($99)</span>
           </Button>
           <div className="grid grid-cols-2 gap-2">
                <Button onClick={handleBack} variant="outline" className="w-full border-[var(--border)]" disabled={currentStepIndex === 0}>
                    <ChevronLeft className="w-4 h-4 mr-1" /> Back
                </Button>
                <Button onClick={handleNext} variant="outline" className="w-full border-[var(--border)]">
                    {currentStepIndex === allSteps.length - 1 ? 'Finish' : 'Next Step'} <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
           </div>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="relative w-full max-w-7xl h-full max-h-[90vh] flex items-center justify-center"
      >
        <div 
          className="relative mx-auto border-[var(--border)] bg-[var(--card)] border-[14px] rounded-[2.5rem] h-full w-[380px] shadow-2xl"
          style={{boxShadow: '0 0 80px -20px hsl(var(--primary)/0.5)'}}
        >
          <button 
            onClick={onClose} 
            className="absolute -top-4 -right-4 z-10 bg-[var(--card)] border border-[var(--border)] rounded-full h-10 w-10 flex items-center justify-center text-[var(--text-secondary)] hover:bg-[var(--accent)] hover:text-[var(--text-primary)] transition-colors"
          >
            <X className="w-5 h-5"/>
          </button>
          <div className="w-[148px] h-[18px] bg-[var(--card)] top-0 rounded-b-[1rem] left-1/2 -translate-x-1/2 absolute"></div>
          <div className="h-[46px] w-[3px] bg-[var(--border)] absolute -left-[17px] top-[72px] rounded-l-lg"></div>
          <div className="h-[46px] w-[3px] bg-[var(--border)] absolute -left-[17px] top-[124px] rounded-l-lg"></div>
          <div className="h-[64px] w-[3px] bg-[var(--border)] absolute -right-[17px] top-[142px] rounded-r-lg"></div>
          <div className="rounded-[2rem] overflow-hidden w-full h-full bg-[var(--card)]">
            <div className="w-full h-full bg-[var(--background)] overflow-hidden flex flex-col text-[var(--text-primary)]">
              <AnimatePresence mode="wait">
                {renderCurrentView()}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
