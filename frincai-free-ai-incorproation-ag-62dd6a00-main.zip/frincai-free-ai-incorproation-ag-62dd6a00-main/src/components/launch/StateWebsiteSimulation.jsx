import React from 'react';
import { motion } from 'framer-motion';

export default function StateWebsiteSimulation({ company, step }) {
  if (!company) {
    return (
      <div className="flex items-center justify-center h-full text-slate-800 p-8">
        Loading simulation...
      </div>
    );
  }

  return (
    <div className="bg-slate-200 rounded-lg p-4 h-full min-h-[400px] overflow-hidden border border-slate-300">
      {/* Fake Browser Chrome */}
      <div className="flex items-center gap-2 mb-3">
        <div className="w-3 h-3 rounded-full bg-red-400"></div>
        <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
        <div className="w-3 h-3 rounded-full bg-green-400"></div>
        <div className="flex-1 bg-white rounded px-3 py-1 text-xs text-slate-600 ml-2">
          https://{company.state.toLowerCase().replace(' ', '')}.gov/business
        </div>
      </div>

      <div className="bg-white rounded-md shadow-inner h-[calc(100%-40px)] overflow-y-auto p-6">
        {/* State Website Header */}
        <header className="pb-4 mb-6 border-b-4 border-blue-700">
          <h1 className="text-2xl font-bold text-blue-800">State of {company.state}</h1>
          <p className="text-sm text-slate-600">Secretary of State - Business Services</p>
        </header>

        {step?.title.includes('Name') ? (
          // Name Search Simulation
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-slate-800 mb-4">Business Name Search</h2>
            
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-md">
              <div className="flex items-center gap-2 text-blue-700 mb-2">
                <div className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-bold">AI</div>
                <span className="font-semibold">AI Assistant is searching for you...</span>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Business Name to Search</label>
                <div className="relative">
                  <input 
                    type="text" 
                    value={`${company.company_name}, ${company.legal_ending}`} 
                    className="w-full p-3 border-2 border-yellow-400 rounded-md text-sm bg-yellow-50 shadow-lg" 
                    readOnly 
                  />
                  <motion.div
                    className="absolute inset-0 border-2 border-yellow-400 rounded-md pointer-events-none"
                    animate={{
                      scale: [1, 1.02, 1],
                      opacity: [0.7, 1, 0.7],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: 'easeInOut'
                    }}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Entity Type</label>
                <select className="w-full p-3 border border-slate-300 rounded-md text-sm bg-slate-50" value={company.company_type.toUpperCase()}>
                  <option>{company.company_type.toUpperCase()}</option>
                </select>
              </div>

              <motion.button 
                className="w-full bg-blue-600 text-white py-3 rounded-md hover:bg-blue-700 font-semibold text-sm relative overflow-hidden"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <motion.div
                  className="absolute inset-0 bg-blue-400"
                  animate={{
                    x: ['-100%', '100%'],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: 'easeInOut'
                  }}
                  style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)' }}
                />
                🔍 AI Agent is Searching...
              </motion.button>
            </div>

            <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-md">
              <h3 className="font-semibold text-green-800 mb-2">Search Results</h3>
              <p className="text-sm text-green-700">
                Great news! "{company.company_name}, {company.legal_ending}" appears to be available for registration.
              </p>
            </div>
          </div>
        ) : step?.title.includes('Agent') ? (
          // Registered Agent Simulation
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-slate-800 mb-4">Registered Agent Information</h2>
            
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-md">
              <div className="flex items-center gap-2 text-blue-700 mb-2">
                <div className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-bold">AI</div>
                <span className="font-semibold">AI Assistant is filling out the form...</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Agent Name</label>
                <input type="text" value={company.owners?.[0]?.firstName + ' ' + company.owners?.[0]?.lastName || 'Business Owner'} className="w-full p-3 border border-slate-300 rounded-md text-sm bg-slate-50" readOnly />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Agent Type</label>
                <select className="w-full p-3 border border-slate-300 rounded-md text-sm bg-slate-50">
                  <option>Individual</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Physical Address in {company.state}</label>
              <input type="text" value={company.owners?.[0]?.streetAddress || '123 Business St'} className="w-full p-3 border border-slate-300 rounded-md text-sm bg-slate-50" readOnly />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">City</label>
                <input type="text" value={company.owners?.[0]?.city || 'Business City'} className="w-full p-3 border border-slate-300 rounded-md text-sm bg-slate-50" readOnly />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">ZIP Code</label>
                <input type="text" value={company.owners?.[0]?.zipCode || '12345'} className="w-full p-3 border border-slate-300 rounded-md text-sm bg-slate-50" readOnly />
              </div>
            </div>
          </div>
        ) : step?.title.includes('File') ? (
          // Filing Simulation
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-slate-800 mb-4">Articles of {company.company_type === 'llc' ? 'Organization' : 'Incorporation'}</h2>
            
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-md">
              <div className="flex items-center gap-2 text-blue-700 mb-2">
                <div className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-bold">AI</div>
                <span className="font-semibold">AI Assistant is preparing your filing...</span>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Company Name</label>
                <input type="text" value={`${company.company_name}, ${company.legal_ending}`} className="w-full p-3 border border-slate-300 rounded-md text-sm bg-slate-50" readOnly />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Business Purpose</label>
                <textarea className="w-full p-3 border border-slate-300 rounded-md text-sm bg-slate-50 h-20" value="To engage in any lawful business activity permitted under state law" readOnly />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Management Structure</label>
                  <select className="w-full p-3 border border-slate-300 rounded-md text-sm bg-slate-50">
                    <option>{company.company_type === 'llc' ? 'Member-Managed' : 'Board of Directors'}</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Filing Fee</label>
                  <input type="text" value="$100.00" className="w-full p-3 border border-slate-300 rounded-md text-sm bg-slate-50" readOnly />
                </div>
              </div>

              <motion.button 
                className="w-full bg-green-600 text-white py-3 rounded-md hover:bg-green-700 font-semibold text-sm relative overflow-hidden"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <motion.div
                  className="absolute inset-0"
                  animate={{
                    x: ['-100%', '100%'],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: 'easeInOut'
                  }}
                  style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)' }}
                />
                📋 AI Agent is Filing Documents...
              </motion.button>
            </div>
          </div>
        ) : (
          // Post-Registration
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-slate-800 mb-4">Post-Registration Checklist</h2>
            
            <div className="space-y-3">
              {[
                '✅ Obtain EIN from IRS',
                '✅ Create Operating Agreement',
                '✅ Open Business Bank Account', 
                '✅ Get Business Licenses',
                '⏳ Set up Annual Report Reminders'
              ].map((item, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-md">
                  <span className="text-sm">{item}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}