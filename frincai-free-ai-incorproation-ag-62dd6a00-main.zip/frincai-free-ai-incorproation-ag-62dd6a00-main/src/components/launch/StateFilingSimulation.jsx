import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { StateData } from '@/api/entities';
import { User } from '@/api/entities';
import Logo from '../Logo';
import { X, Maximize2, Minimize2 } from 'lucide-react'; // Changed from Copy, Check icons
import { Button } from '@/components/ui/button';
import ChatMessage from '../chat/ChatMessage';
import SuggestedReplies from '../chat/SuggestedReplies';
import SimulatedWebsiteFrame from './SimulatedWebsiteFrame';

// High-fidelity Wyoming LLC simulation data based on user screenshots
// UPDATED with scripts for guiding arrows and copy buttons
const wyomingLlcHardcodedData = [
  // Step 1: Form or Register a New Business
  {
    step_number: 1,
    step_title: 'Select Business Type',
    step_description: 'This is the first screen on the Wyoming business portal. The first step is to choose your business entity type from the dropdown menu.',
    html_content: `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Wyoming Business Registration</title>
          <style>
              body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f0f0; color: #333; }
              .header { background-color: #0d2c4e; padding: 10px 20px; }
              .header-content { max-width: 1200px; margin: 0 auto; }
              .nav-bar { background-color: #333; color: white; padding: 10px 0; }
              .nav-bar .container { display: flex; justify-content: space-around; max-width: 1200px; margin: 0 auto; font-size: 14px; }
              .container-flex { display: flex; max-width: 1200px; margin: 20px auto; gap: 20px; }
              .sidebar { width: 250px; background: #fff; padding: 15px; font-size: 13px; }
              .sidebar h3 { margin-top: 0; color: #555; font-size: 14px; }
              .sidebar ul { list-style: none; padding: 0; }
              .sidebar li a { color: #007bff; text-decoration: none; display: block; padding: 5px 0; }
              .main-content { flex: 1; background: #fff; padding: 20px; }
              .main-content h1 { font-size: 18px; color: #555; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
              .form-section { border: 1px solid #ccc; padding: 20px; background-color: #f7f7f7; }
              .form-section h2 { margin-top: 0; font-size: 16px; color: #333; }
              .form-group { margin-bottom: 15px; }
              .form-group label { display: block; font-weight: bold; margin-bottom: 5px; font-size: 14px; }
              .form-group select, .form-group input { width: 100%; padding: 8px; border: 1px solid #ccc; box-sizing: border-box; }
              .important-text { font-size: 12px; color: #d9534f; margin: 15px 0; }
              .notice-text { font-size: 12px; color: #555; margin: 15px 0; }
              .attest-box { font-size: 12px; display: flex; align-items: flex-start; }
              .attest-box input { margin-right: 10px; margin-top: 2px; }
              .button-container { text-align: right; margin-top: 20px; }
              .btn { padding: 8px 15px; border: 1px solid #ccc; background-color: #e6e6e6; cursor: pointer; font-size: 14px; }
              .btn-primary { background-color: #007bff; color: white; border-color: #007bff; }
              .footer { background-color: #333; color: white; padding: 30px 20px; margin-top: 20px; }
              .footer-content { display: flex; justify-content: space-between; max-width: 1200px; margin: 0 auto; font-size: 12px; }
              .footer-col h4 { margin-top: 0; }

              .highlight-arrow {
                  position: absolute;
                  width: 40px;
                  height: 40px;
                  pointer-events: none;
                  z-index: 9999;
                  animation: bounce-arrow 2s ease-in-out infinite;
                  transform: rotate(180deg); /* Arrow points down */
              }
              @keyframes bounce-arrow {
                  0%, 20%, 50%, 80%, 100% { transform: translateY(0) rotate(180deg); }
                  40% { transform: translateY(-10px) rotate(180deg); }
                  60% { transform: translateY(-5px) rotate(180deg); }
              }
              .copy-btn {
                  display: none; /* Not used in this step, but included for consistency */
              }
          </style>
      </head>
      <body>
          <div class="header"><div class="header-content"><img src="https://wyobiz.wyo.gov/Business/Content/images/wyosec_of_state_logo.png" alt="Wyoming Secretary of State"></div></div>
          <div class="nav-bar"><div class="container"><span>Home</span><span>About Us</span><span>Business/E-Filing</span><span>Business/UCC</span><span>Elections</span><span>Forms</span><span>Invoicing</span><span>Services & Information</span><span>Contact</span></div></div>
          <div class="container-flex">
              <div class="sidebar"><h3>Business & UCC Home</h3><ul><li><a href="#">Annual Report Online Filing</a></li><li><a href="#">FAQs</a></li><li><a href="#">Commercial Registered Agents</a></li><li><a href="#">FinCEN / CTA Information</a></li><li><a href="#">Forms</a><li><a href="#">Good Standing Certificates Online</a></li><li><a href="#">Maintaining Your Business</a></li><li><a href="#">Media Releases</a></li><li><a href="#">Online Business Services</a></li><li><a href="#">Questions and Answers</a></li><li><a href="#">Reinstate Online</a></li><li><a href="#">Start a Business</a></li><li><a href="#">Search for Business Name/Filings</a></li><li><a href="#">Statistics</a></li><li><a href="#">UCC / EFS / Notaries</a></li></ul></div>
              <div class="main-content">
                  <h1>Business Center</h1>
                  <div style="text-align: right; font-size: 12px; margin-bottom: 10px;"><a href="#">Online Services</a> > <a href="#">Instructions</a> > <span>Business Type</span></div>
                  <div class="form-section">
                      <h2>FORM OR REGISTER A NEW BUSINESS</h2>
                      <div class="form-group">
                          <label for="entityTypeSelect">Choose a Business Entity Type: *</label>
                          <select id="entityTypeSelect" readonly><option>Limited Liability Company (Domestic)</option></select>
                      </div>
                      <div class="form-group">
                          <label>Additional Designation:</label>
                          <select readonly><option>(none)</option></select>
                      </div>
                      <div style="font-size: 12px; margin-left: 20px;">
                          <p><input type="checkbox" checked disabled> Limited Liability Company Statutes & Rules</p>
                          <p><input type="checkbox" disabled> W.S. 17-29</p>
                          <p><input type="checkbox" disabled> Limited Liability Company Act</p>
                          <p><input type="checkbox" disabled> W.S. 17-15</p>
                          <p><input type="checkbox" disabled> Decentralized Autonomous Organization Supplement</p>
                      </div>
                      <p class="important-text"><strong>IMPORTANT:</strong> If you are forming a Decentralized Autonomous Organization (DAO) as a Series LLC, you <u>must make the appropriate declaration in the "Additional Designation" field above.</u></p>
                      <p class="notice-text">The Wizard is not available for all business entity types. If the type of business entity you wish to form or register is not available in the top above, <u>click here</u> to obtain the appropriate form.</p>
                      <p class="notice-text"><strong>Notice:</strong><br>Any information provided in the online system is public information and will appear online and on requests exactly as it is entered into the online system. By law, the Wyoming Secretary of State's Office may not redact any personal information (including but not limited to Social Security Numbers, Phone Numbers, Email Addresses, etc.).<br>Once you begin this wizard, you will have 30 minutes to complete your filing due to server availability considerations.</p>
                      <div class="attest-box">
                          <input type="checkbox" id="attest" disabled>
                          <label for="attest">I Attest That: *<br>Pursuant to W.S. 16-4-202 et. seq. (Wyoming Public Records Act), I understand that the information I enter into the online system is public information and will appear online and on requests exactly as I key it into the system.</label>
                      </div>
                  </div>
                  <div class="button-container"><button class="btn" disabled>&laquo; PREVIOUS</button> <button class="btn btn-primary" id="nextButton" disabled>NEXT &raquo;</button></div>
              </div>
          </div>
          <div class="footer"><div class="footer-content"><div class="footer-col"><h4>Office Information</h4></div><div class="footer-col"><h4>Office Hours</h4></div><div class="footer-col"><h4>About Our Office</h4></div></div></div>
          <script>
              document.addEventListener('DOMContentLoaded', function() {
                  const createArrow = (targetElement, rotation = '180deg') => {
                      const rect = targetElement.getBoundingClientRect();
                      const arrow = document.createElement('div');
                      arrow.className = 'highlight-arrow';
                      arrow.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14m0-14l-4 4m4-4l4 4" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                      document.body.appendChild(arrow);
                      const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                      arrow.style.position = 'absolute';
                      arrow.style.left = (rect.left + rect.width / 2 - 20) + 'px';
                      arrow.style.top = (rect.top + scrollY - 45) + 'px';
                      arrow.style.transform = 'rotate(' + rotation + ')';
                  };
                  setTimeout(() => createArrow(document.querySelector('#entityTypeSelect')), 300);
              });
          </script>
      </body>
      </html>`
  },
  // Step 2: Business Entity Name
  {
    step_number: 2,
    step_title: 'Enter Business Name',
    step_description: "Now, enter your chosen company name. The form requires you to enter it twice to confirm it's correct.",
    html_content: `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Business Entity Name</title>
          <style>
              body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f0f0; color: #333; }
              .header { background-color: #0d2c4e; padding: 10px 20px; }
              .header-content { max-width: 1200px; margin: 0 auto; }
              .nav-bar { background-color: #333; color: white; padding: 10px 0; }
              .nav-bar .container { display: flex; justify-content: space-around; max-width: 1200px; margin: 0 auto; font-size: 14px; }
              .container-flex { display: flex; max-width: 1200px; margin: 20px auto; gap: 20px; }
              .sidebar { width: 250px; background: #fff; padding: 15px; font-size: 13px; }
              .sidebar h3 { margin-top: 0; color: #555; font-size: 14px; }
              .sidebar ul { list-style: none; padding: 0; }
              .sidebar li a { color: #007bff; text-decoration: none; display: block; padding: 5px 0; }
              .main-content { flex: 1; background: #fff; padding: 20px; }
              .breadcrumb { margin-bottom: 20px; font-size: 13px; }
              .breadcrumb span { font-weight: bold; }
              .main-content h2 { font-size: 18px; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
              .form-section { border: 1px solid #ccc; padding: 20px; background-color: #f7f7f7; }
              .warning { font-size: 12px; margin-bottom: 15px; }
              .form-group { margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
              .form-group label { width: 150px; font-weight: bold; font-size: 14px; flex-shrink: 0;}
              .form-group input { flex-grow: 1; padding: 8px; border: 1px solid #ccc; }

              .highlight-arrow {
                  position: absolute;
                  width: 40px;
                  height: 40px;
                  pointer-events: none;
                  z-index: 9999;
                  animation: bounce-arrow 2s ease-in-out infinite;
                  transform: rotate(90deg); /* Arrow points right */
              }
              @keyframes bounce-arrow {
                  0%, 20%, 50%, 80%, 100% { transform: translateX(0) rotate(90deg); }
                  40% { transform: translateX(-10px) rotate(90deg); }
                  60% { transform: translateX(-5px) rotate(90deg); }
              }
              .copy-btn {
                  padding: 4px 8px;
                  font-size: 10px;
                  background-color: #007bff;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  flex-shrink: 0;
              }
              .footer-links { margin-top: 20px; font-size: 12px; display: flex; justify-content: space-between; border-top: 1px solid #ddd; padding-top: 10px; }
              .button-container { text-align: right; margin-top: 20px; }
              .btn { padding: 8px 15px; border: 1px solid #ccc; background-color: #e6e6e6; cursor: pointer; font-size: 14px; }
              .btn-primary { background-color: #007bff; color: white; border-color: #007bff; }
          </style>
      </head>
      <body>
          <div class="header"><div class="header-content"><img src="https://wyobiz.wyo.gov/Business/Content/images/wyosec_of_state_logo.png" alt="Wyoming Secretary of State"></div></div>
          <div class="nav-bar"><div class="container"><span>Home</span><span>About Us</span><span>Business/E-Filing</span><span>Business/UCC</span><span>Elections</span><span>Forms</span><span>Invoicing</span><span>Services & Information</span><span>Contact</span></div></div>
          <div class="container-flex">
              <div class="sidebar"><h3>Business & UCC Home</h3><ul><li><a href="#">Annual Report Online Filing</a></li><li><a href="#">FAQs</a></li><li><a href="#">Commercial Registered Agents</a></li><li><a href="#">FinCEN / CTA Information</a></li><li><a href="#">Forms</a></li><li><a href="#">Good Standing Certificates Online</a></li><li><a href="#">Maintaining Your Business</a></li><li><a href="#">Media Releases</a></li><li><a href="#">Online Business Services</a></li><li><a href="#">Questions and Answers</a></li><li><a href="#">Reinstate Online</a></li><li><a href="#">Start a Business</a></li><li><a href="#">Search for Business Name/Filings</a></li><li><a href="#">Statistics</a></li><li><a href="#">UCC / EFS / Notaries</a></li></ul></div>
              <div class="main-content">
                  <div class="breadcrumb"><span>1. BUSINESS NAME</span> > 2. DETAIL > 3. AGENT > 4. ADDRESSES > 5. ORGANIZERS > 6. ADDITIONAL ARTICLES > 7. CONFIRMATION > 8. SIGNATURE > 9. PAYMENT</div>
                  <h2>BUSINESS ENTITY NAME</h2>
                  <div class="form-section">
                      <p class="warning"><strong>Warning:</strong> If you have not conducted a search for your business entity name (<u>Business Entity Name Statutory Requirements</u>), to ensure that there are no entities on record which contain the singular or plural form of the name you wish to register, please visit the <u>Search Tool</u> before proceeding.<br><br>Please be advised that subtype designations (DAO, LAO, LAC) are not considered distinguishable. Please visit <u>How To Choose a Company Name</u> for information.</p>
                      <div class="form-group">
                          <label for="name">Business Entity Name: *</label>
                          <input type="text" id="name" value="{company_name}, {legal_ending}" readonly>
                      </div>
                      <div class="form-group">
                          <label for="confirmName">Confirm Name: *</label>
                          <input type="text" id="confirmName" value="{company_name}, {legal_ending}" readonly>
                      </div>
                  </div>
                  <div class="footer-links"><span>Refund Policy</span><span>Customer Service</span></div>
                  <div class="button-container"><button class="btn" disabled>&laquo; PREVIOUS</button> <button class="btn btn-primary" id="nextButton" disabled>NEXT &raquo;</button></div>
              </div>
          </div>
          <div class="footer"><div class="footer-content"><div class="footer-col"><h4>Office Information</h4></div><div class="footer-col"><h4>Office Hours</h4></div><div class="footer-col"><h4>About Our Office</h4></div></div></div>
          <script>
            document.addEventListener('DOMContentLoaded', function() {
                const createArrow = (targetElement, rotation = '90deg') => {
                    const rect = targetElement.getBoundingClientRect();
                    const arrow = document.createElement('div');
                    arrow.className = 'highlight-arrow';
                    arrow.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14m0-14l-4 4m4-4l4 4" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                    document.body.appendChild(arrow);
                    const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                    arrow.style.position = 'absolute';
                    arrow.style.left = (rect.left - 45) + 'px'; /* Position to the left of the element */
                    arrow.style.top = (rect.top + scrollY + rect.height / 2 - 20) + 'px'; /* Center vertically */
                    arrow.style.transform = 'rotate(' + rotation + ')';
                };

                const addInteractiveElements = (selector) => {
                    const targetElement = document.querySelector(selector);
                    if (!targetElement) return;

                    createArrow(targetElement);

                    const copyBtn = document.createElement('button');
                    copyBtn.innerText = 'Copy';
                    copyBtn.className = 'copy-btn';
                    copyBtn.onclick = () => {
                        navigator.clipboard.writeText(targetElement.value).then(() => {
                            copyBtn.innerText = 'Copied!';
                            setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                        }).catch(err => {
                            console.error('Failed to copy text: ', err);
                            copyBtn.innerText = 'Error';
                            setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                        });
                    };
                    targetElement.parentNode.appendChild(copyBtn);
                    targetElement.setAttribute('readonly', 'true'); // Ensure it's readonly
                };

                setTimeout(() => addInteractiveElements('#name'), 300);
                setTimeout(() => addInteractiveElements('#confirmName'), 600);
            });
          </script>
      </body>
      </html>`
  },
  // Step 3: Detail
  {
    step_number: 3,
    step_title: 'Set Effective Date',
    step_description: 'On this screen, you can specify if you want the LLC formation to be effective at a later date. Most people leave this blank to have it be effective immediately.',
    html_content: `
      <!DOCTYPE html>
      <html>
      <head>
          <title>Detail</title>
          <style>
              body { margin: 0; font-family: Arial, sans-serif; background-color: #f0f0f0; }
              .main-content { flex: 1; background: #fff; padding: 20px; max-width: 900px; margin: 20px auto; }
              .breadcrumb { margin-bottom: 20px; font-size: 13px; }
              .breadcrumb span { font-weight: bold; }
              h2 { font-size: 18px; color: #333; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
              .form-section { border: 1px solid #ccc; padding: 20px; background-color: #f7f7f7; }
              .form-group { margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
              .form-group label { font-weight: bold; font-size: 14px; flex-shrink: 0; }
              .form-group input { flex-grow: 1; padding: 8px; border: 1px solid #ccc; }
              .info-box { font-size: 12px; margin-top: 5px; }
              .button-container { text-align: right; margin-top: 20px; }
              .btn { padding: 8px 15px; border: 1px solid #ccc; background-color: #e6e6e6; cursor: pointer; font-size: 14px; }
              .btn-primary { background-color: #007bff; color: white; border-color: #007bff; }

              .highlight-arrow {
                  position: absolute;
                  width: 40px;
                  height: 40px;
                  pointer-events: none;
                  z-index: 9999;
                  animation: bounce-arrow 2s ease-in-out infinite;
                  transform: rotate(180deg); /* Arrow points down */
              }
              @keyframes bounce-arrow {
                  0%, 20%, 50%, 80%, 100% { transform: translateY(0) rotate(180deg); }
                  40% { transform: translateY(-10px) rotate(180deg); }
                  60% { transform: translateY(-5px) rotate(180deg); }
              }
              .copy-btn {
                  padding: 4px 8px;
                  font-size: 10px;
                  background-color: #007bff;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  flex-shrink: 0;
              }
          </style>
      </head>
      <body>
          <div class="main-content">
              <div class="breadcrumb">1. BUSINESS NAME > <span>2. DETAIL</span> > 3. AGENT > ...</div>
              <h2>DETAIL</h2>
              <div class="form-section">
                  <div class="form-group">
                      <label>Delayed Effective Date:</label>
                      <input type="text" placeholder="MM/DD/YYYY" id="effectiveDate" readonly>
                  </div>
                  <div class="info-box">(If the filing is NOT to be effective immediately, enter the effective date within the next 90 calendar days.)</div>
              </div>
              <div class="button-container"><button class="btn" disabled>&laquo; PREVIOUS</button> <button class="btn btn-primary" id="nextButton" disabled>NEXT &raquo;</button></div>
          </div>
          <script>
              document.addEventListener('DOMContentLoaded', function() {
                  const createArrow = (targetElement, rotation = '180deg') => {
                      const rect = targetElement.getBoundingClientRect();
                      const arrow = document.createElement('div');
                      arrow.className = 'highlight-arrow';
                      arrow.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14m0-14l-4 4m4-4l4 4" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                      document.body.appendChild(arrow);
                      const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                      arrow.style.position = 'absolute';
                      arrow.style.left = (rect.left + rect.width / 2 - 20) + 'px';
                      arrow.style.top = (rect.top + scrollY - 45) + 'px';
                      arrow.style.transform = 'rotate(' + rotation + ')';
                  };

                  const addInteractiveElements = (selector) => {
                      const targetElement = document.querySelector(selector);
                      if (!targetElement) return;

                      createArrow(targetElement);

                      const copyBtn = document.createElement('button');
                      copyBtn.innerText = 'Copy';
                      copyBtn.className = 'copy-btn';
                      copyBtn.onclick = () => {
                          navigator.clipboard.writeText(targetElement.value).then(() => {
                              copyBtn.innerText = 'Copied!';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          }).catch(err => {
                              console.error('Failed to copy text: ', err);
                              copyBtn.innerText = 'Error';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          });
                      };
                      targetElement.parentNode.appendChild(copyBtn);
                      targetElement.setAttribute('readonly', 'true');
                  };
                  setTimeout(() => addInteractiveElements('#effectiveDate'), 300);
              });
          </script>
      </body>
      </html>`
  },
  // Step 4: Agent
  {
    step_number: 4,
    step_title: 'Appoint Registered Agent',
    step_description: 'Every company needs a Registered Agent. You can search for one or enter their details directly if you already have one.',
    html_content: `
      <!DOCTYPE html>
      <html>
      <head>
          <title>Agent</title>
          <style>
              body { font-family: Arial, sans-serif; background-color: #f0f0f0; }
              .main-content { background: #fff; padding: 20px; max-width: 900px; margin: 20px auto; }
              .breadcrumb { margin-bottom: 20px; font-size: 13px; }
              h2 { font-size: 18px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
              .section { border: 1px solid #ccc; padding: 15px; margin-bottom: 20px; }
              .section h3 { margin-top: 0; font-size: 14px; }
              .form-grid { display: grid; grid-template-columns: 150px 1fr auto; /* Added auto for button */ gap: 10px; align-items: center; }
              label { font-weight: bold; font-size: 14px; }
              input { padding: 8px; border: 1px solid #ccc; width: 100%; box-sizing: border-box; }

              .highlight-arrow {
                  position: absolute;
                  width: 40px;
                  height: 40px;
                  pointer-events: none;
                  z-index: 9999;
                  animation: bounce-arrow 2s ease-in-out infinite;
                  transform: rotate(90deg); /* Arrow points right */
              }
              @keyframes bounce-arrow {
                  0%, 20%, 50%, 80%, 100% { transform: translateX(0) rotate(90deg); }
                  40% { transform: translateX(-10px) rotate(90deg); }
                  60% { transform: translateX(-5px) rotate(90deg); }
              }
              .copy-btn {
                  padding: 4px 8px;
                  font-size: 10px;
                  background-color: #007bff;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  flex-shrink: 0;
              }
              /* For the specific form-grid in "Enter Agent Information" */
              .form-grid.agent-info { grid-template-columns: 100px 1fr auto 100px 1fr auto; } /* Adjusted for copy buttons */
              .form-grid.agent-info label { grid-column: auto; }
              .form-grid.agent-info input { grid-column: span 1; }
              .form-grid.agent-info .full-width-input { grid-column: 2 / 7; } /* Spanning across inputs and copy buttons */
          </style>
      </head>
      <body>
          <div class="main-content">
              <div class="breadcrumb">... > 2. DETAIL > <span>3. AGENT</span> > 4. ADDRESSES > ...</div>
              <h2>AGENT</h2>
              <div class="section">
                  <h3>Search for a Registered Agent</h3>
                  <p style="font-size:12px;">This is an optional feature. Search for a name of an agent to add as the registered agent...</p>
                  <div class="form-grid">
                      <label>Name:</label> <input type="text" id="agentSearchName" readonly> <button disabled>Search</button>
                      <label>City:</label> <input type="text" id="agentSearchCity" readonly> <button disabled>Search</button>
                  </div>
              </div>
              <div class="section">
                  <h3>Enter Agent Information</h3>
                  <div class="form-grid agent-info">
                      <label>First Name:</label><input type="text" id="agentFirstName" value="{agent_firstname}" readonly>
                      <label>Last Name:</label><input type="text" id="agentLastName" value="{agent_lastname}" readonly>
                      <label>Organization:</label><input type="text" class="full-width-input" id="agentOrganization" value="{agent_organization}" readonly>
                      <label>Address Line 1:</label><input type="text" class="full-width-input" id="agentAddress1" value="{agent_address1}" readonly>
                      <label>Address Line 2:</label><input type="text" class="full-width-input" id="agentAddress2" value="{agent_address2}" readonly>
                      <label>City:</label><input type="text" id="agentCity" value="{agent_city}" readonly>
                      <label>State:</label><input type="text" id="agentState" value="{agent_state}" readonly>
                      <label>Zip Code:</label><input type="text" id="agentZip" value="{agent_zip}" readonly>
                      <label></label><button id="saveAgent" disabled>Save</button>
                  </div>
              </div>
          </div>
          <script>
              document.addEventListener('DOMContentLoaded', function() {
                  const createArrow = (targetElement, rotation = '90deg') => {
                      const rect = targetElement.getBoundingClientRect();
                      const arrow = document.createElement('div');
                      arrow.className = 'highlight-arrow';
                      arrow.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14m0-14l-4 4m4-4l4 4" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                      document.body.appendChild(arrow);
                      const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                      arrow.style.position = 'absolute';
                      arrow.style.left = (rect.left - 45) + 'px';
                      arrow.style.top = (rect.top + scrollY + rect.height / 2 - 20) + 'px';
                      arrow.style.transform = 'rotate(' + rotation + ')';
                  };

                  const addInteractiveElements = (selector) => {
                      const targetElement = document.querySelector(selector);
                      if (!targetElement) return;

                      createArrow(targetElement);

                      const copyBtn = document.createElement('button');
                      copyBtn.innerText = 'Copy';
                      copyBtn.className = 'copy-btn';
                      copyBtn.onclick = () => {
                          navigator.clipboard.writeText(targetElement.value).then(() => {
                              copyBtn.innerText = 'Copied!';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          }).catch(err => {
                              console.error('Failed to copy text: ', err);
                              copyBtn.innerText = 'Error';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          });
                      };
                      targetElement.parentNode.appendChild(copyBtn);
                      targetElement.setAttribute('readonly', 'true');
                  };

                  setTimeout(() => addInteractiveElements('#agentFirstName'), 300);
                  setTimeout(() => addInteractiveElements('#agentLastName'), 600);
                  setTimeout(() => addInteractiveElements('#agentOrganization'), 900);
                  setTimeout(() => addInteractiveElements('#agentAddress1'), 1200);
                  setTimeout(() => addInteractiveElements('#agentAddress2'), 1500);
                  setTimeout(() => addInteractiveElements('#agentCity'), 1800);
                  setTimeout(() => addInteractiveElements('#agentState'), 2100);
                  setTimeout(() => addInteractiveElements('#agentZip'), 2400);
              });
          </script>
      </body>
      </html>`
  },
  // Step 5: Addresses
  {
    step_number: 5,
    step_title: 'Provide Addresses',
    step_description: "Enter the LLC's Principal Address (where business is conducted) and a Mailing Address.",
    html_content: `
      <!DOCTYPE html>
      <html>
      <head><title>Addresses</title>
          <style>
              body { font-family: Arial, sans-serif; background-color: #f0f0f0; }
              .main-content { background: #fff; padding: 20px; max-width: 900px; margin: 20px auto; }
              .breadcrumb { margin-bottom: 20px; font-size: 13px; }
              h2 { font-size: 18px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
              .section { border: 1px solid #ccc; padding: 15px; margin-bottom: 20px; }
              .section h3 { margin-top: 0; font-size: 14px; }
              .form-grid { display: grid; grid-template-columns: 120px 1fr auto; /* Added auto for button */ gap: 10px; align-items: center; }
              label { font-weight: bold; }
              input, select { padding: 8px; border: 1px solid #ccc; width: 100%; box-sizing: border-box; }
              .info-text { font-size: 12px; margin-top: 15px; }

              .highlight-arrow {
                  position: absolute;
                  width: 40px;
                  height: 40px;
                  pointer-events: none;
                  z-index: 9999;
                  animation: bounce-arrow 2s ease-in-out infinite;
                  transform: rotate(90deg); /* Arrow points right */
              }
              @keyframes bounce-arrow {
                  0%, 20%, 50%, 80%, 100% { transform: translateX(0) rotate(90deg); }
                  40% { transform: translateX(-10px) rotate(90deg); }
                  60% { transform: translateX(-5px) rotate(90deg); }
              }
              .copy-btn {
                  padding: 4px 8px;
                  font-size: 10px;
                  background-color: #007bff;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  flex-shrink: 0;
              }
          </style>
      </head>
      <body>
          <div class="main-content">
              <div class="breadcrumb">... > <span>4. ADDRESSES</span> > 5. ORGANIZERS > ...</div>
              <h2>ADDRESSES</h2>
              <div class="section">
                  <h3>Principal Address</h3>
                  <p style="font-size:12px;">Please specify the principal office address for this entity and press Save.</p>
                  <div class="form-grid">
                      <label>Country:</label> <select id="principalCountry" readonly disabled><option>United States</option></select><div></div>
                      <label>Address Line 1:</label> <input type="text" id="principalAddress1" value="{principal_address1}" readonly>
                      <label>Address Line 2:</label> <input type="text" id="principalAddress2" value="{principal_address2}" readonly>
                      <label>City:</label> <input type="text" id="principalCity" value="{principal_city}" readonly>
                      <label>State:</label> <input type="text" id="principalState" value="{principal_state}" readonly>
                      <label>Postal Code:</label> <input type="text" id="principalPostalCode" value="{principal_zip}" readonly>
                      <label>Email:</label> <input type="email" id="principalEmail" value="{principal_email}" readonly>
                  </div>
                  <p class="info-text">Please provide your email address in order to receive electronic notification of future annual report due dates...</p>
              </div>
              <div class="section">
                  <h3>Mailing Address</h3>
                  <p style="font-size:12px;">Please update the mailing address for this entity and press Save.</p>
                  <div class="form-grid">
                      <label>Country:</label> <select id="mailingCountry" readonly disabled><option>United States</option></select><div></div>
                      <label>Address Line 1:</label> <input type="text" id="mailingAddress1" value="{mailing_address1}" readonly>
                      <label>Address Line 2:</label> <input type="text" id="mailingAddress2" value="{mailing_address2}" readonly>
                      <label>City:</label> <input type="text" id="mailingCity" value="{mailing_city}" readonly>
                      <label>State:</label> <input type="text" id="mailingState" value="{mailing_state}" readonly>
                      <label>Postal Code:</label> <input type="text" id="mailingPostalCode" value="{mailing_zip}" readonly>
                      <label>Email:</label> <input type="email" id="mailingEmail" value="{mailing_email}" readonly>
                  </div>
              </div>
          </div>
          <script>
              document.addEventListener('DOMContentLoaded', function() {
                  const createArrow = (targetElement, rotation = '90deg') => {
                      const rect = targetElement.getBoundingClientRect();
                      const arrow = document.createElement('div');
                      arrow.className = 'highlight-arrow';
                      arrow.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14m0-14l-4 4m4-4l4 4" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                      document.body.appendChild(arrow);
                      const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                      arrow.style.position = 'absolute';
                      arrow.style.left = (rect.left - 45) + 'px';
                      arrow.style.top = (rect.top + scrollY + rect.height / 2 - 20) + 'px';
                      arrow.style.transform = 'rotate(' + rotation + ')';
                  };

                  const addInteractiveElements = (selector) => {
                      const targetElement = document.querySelector(selector);
                      if (!targetElement) return;

                      createArrow(targetElement);

                      const copyBtn = document.createElement('button');
                      copyBtn.innerText = 'Copy';
                      copyBtn.className = 'copy-btn';
                      copyBtn.onclick = () => {
                          navigator.clipboard.writeText(targetElement.value).then(() => {
                              copyBtn.innerText = 'Copied!';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          }).catch(err => {
                              console.error('Failed to copy text: ', err);
                              copyBtn.innerText = 'Error';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          });
                      };
                      targetElement.parentNode.appendChild(copyBtn);
                      targetElement.setAttribute('readonly', 'true');
                  };

                  setTimeout(() => addInteractiveElements('#principalAddress1'), 300);
                  setTimeout(() => addInteractiveElements('#principalAddress2'), 600);
                  setTimeout(() => addInteractiveElements('#principalCity'), 900);
                  setTimeout(() => addInteractiveElements('#principalState'), 1200);
                  setTimeout(() => addInteractiveElements('#principalPostalCode'), 1500);
                  setTimeout(() => addInteractiveElements('#principalEmail'), 1800);
                  setTimeout(() => addInteractiveElements('#mailingAddress1'), 2100);
                  setTimeout(() => addInteractiveElements('#mailingAddress2'), 2400);
                  setTimeout(() => addInteractiveElements('#mailingCity'), 2700);
                  setTimeout(() => addInteractiveElements('#mailingState'), 3000);
                  setTimeout(() => addInteractiveElements('#mailingPostalCode'), 3300);
                  setTimeout(() => addInteractiveElements('#mailingEmail'), 3600);
              });
          </script>
      </body>
      </html>`
  },
  // Step 6: Organizers
  {
    step_number: 6,
    step_title: 'List Organizers',
    step_description: "The organizer is the person or entity filing this document. Enter their information here.",
    html_content: `
      <!DOCTYPE html>
      <html>
      <head><title>Organizers</title>
          <style>
              body { font-family: Arial, sans-serif; background-color: #f0f0f0; }
              .main-content { background: #fff; padding: 20px; max-width: 900px; margin: 20px auto; }
              .breadcrumb { margin-bottom: 20px; font-size: 13px; }
              h2 { font-size: 18px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
              .section { border: 1px solid #ccc; padding: 15px; }
              .form-grid { display: grid; grid-template-columns: 100px 1fr auto 100px 1fr auto; /* Adjusted for copy buttons */ gap: 10px; align-items: center; }
              label { font-weight: bold; }
              input { padding: 8px; border: 1px solid #ccc; width: 100%; box-sizing: border-box; }
              .form-grid .full-width-input { grid-column: 2 / 7; } /* Spanning across inputs and copy buttons */

              .highlight-arrow {
                  position: absolute;
                  width: 40px;
                  height: 40px;
                  pointer-events: none;
                  z-index: 9999;
                  animation: bounce-arrow 2s ease-in-out infinite;
                  transform: rotate(90deg); /* Arrow points right */
              }
              @keyframes bounce-arrow {
                  0%, 20%, 50%, 80%, 100% { transform: translateX(0) rotate(90deg); }
                  40% { transform: translateX(-10px) rotate(90deg); }
                  60% { transform: translateX(-5px) rotate(90deg); }
              }
              .copy-btn {
                  padding: 4px 8px;
                  font-size: 10px;
                  background-color: #007bff;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  flex-shrink: 0;
              }
          </style>
      </head>
      <body>
          <div class="main-content">
              <div class="breadcrumb">... > <span>5. ORGANIZERS</span> > 6. ADDITIONAL ARTICLES > ...</div>
              <h2>ORGANIZERS</h2>
              <div class="section">
                  <p style="font-size:12px;">Please use the form below to add and review all addresses of the organizers. Press 'Add' after entering information for each officer.</p>
                  <div class="form-grid">
                      <label>First Name:*</label><input type="text" id="organizerFirstName" value="{organizer_firstname}" readonly>
                      <label>Middle Name:</label><input type="text" id="organizerMiddleName" value="{organizer_middlename}" readonly>
                      <label>Last Name:*</label><input type="text" id="organizerLastName" value="{organizer_lastname}" readonly>
                      <label>Suffix:</label><input type="text" id="organizerSuffix" value="{organizer_suffix}" readonly>
                      <label>Address:*</label><input type="text" class="full-width-input" id="organizerAddress" value="{organizer_address}" readonly>
                      <label>City, State, Zip:*</label><input type="text" class="full-width-input" id="organizerCityStateZip" value="{organizer_city}, {organizer_state}, {organizer_zip}" readonly>
                      <label>Officer Type:</label><input type="text" id="officerType" value="Organizer" readonly><div></div>
                  </div>
              </div>
          </div>
          <script>
              document.addEventListener('DOMContentLoaded', function() {
                  const createArrow = (targetElement, rotation = '90deg') => {
                      const rect = targetElement.getBoundingClientRect();
                      const arrow = document.createElement('div');
                      arrow.className = 'highlight-arrow';
                      arrow.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14m0-14l-4 4m4-4l4 4" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                      document.body.appendChild(arrow);
                      const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                      arrow.style.position = 'absolute';
                      arrow.style.left = (rect.left - 45) + 'px';
                      arrow.style.top = (rect.top + scrollY + rect.height / 2 - 20) + 'px';
                      arrow.style.transform = 'rotate(' + rotation + ')';
                  };

                  const addInteractiveElements = (selector) => {
                      const targetElement = document.querySelector(selector);
                      if (!targetElement) return;

                      createArrow(targetElement);

                      const copyBtn = document.createElement('button');
                      copyBtn.innerText = 'Copy';
                      copyBtn.className = 'copy-btn';
                      copyBtn.onclick = () => {
                          navigator.clipboard.writeText(targetElement.value).then(() => {
                              copyBtn.innerText = 'Copied!';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          }).catch(err => {
                              console.error('Failed to copy text: ', err);
                              copyBtn.innerText = 'Error';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          });
                      };
                      targetElement.parentNode.appendChild(copyBtn);
                      targetElement.setAttribute('readonly', 'true');
                  };

                  setTimeout(() => addInteractiveElements('#organizerFirstName'), 300);
                  setTimeout(() => addInteractiveElements('#organizerMiddleName'), 600);
                  setTimeout(() => addInteractiveElements('#organizerLastName'), 900);
                  setTimeout(() => addInteractiveElements('#organizerSuffix'), 1200);
                  setTimeout(() => addInteractiveElements('#organizerAddress'), 1500);
                  setTimeout(() => addInteractiveElements('#organizerCityStateZip'), 1800);
                  setTimeout(() => addInteractiveElements('#officerType'), 2100);
              });
          </script>
      </body>
      </html>`
  },
  // Step 7: Additional Articles
  {
    step_number: 7,
    step_title: 'Additional Articles',
    step_description: 'This is an optional section where you can include any additional rules or provisions for your LLC.',
    html_content: `
      <!DOCTYPE html>
      <html>
      <head><title>Additional Articles</title>
          <style>
              body { font-family: Arial, sans-serif; background-color: #f0f0f0; }
              .main-content { background: #fff; padding: 20px; max-width: 900px; margin: 20px auto; }
              .breadcrumb { margin-bottom: 20px; font-size: 13px; }
              h2 { font-size: 18px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
              .section { border: 1px solid #ccc; padding: 15px; }
              textarea { width: 100%; height: 100px; border: 1px solid #ccc; }
              .form-group { margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
              .form-group label { display: block; font-weight: bold; margin-bottom: 5px; font-size: 14px; flex-shrink: 0; }
              .form-group textarea { flex-grow: 1; padding: 8px; border: 1px solid #ccc; box-sizing: border-box; }

              .highlight-arrow {
                  position: absolute;
                  width: 40px;
                  height: 40px;
                  pointer-events: none;
                  z-index: 9999;
                  animation: bounce-arrow 2s ease-in-out infinite;
                  transform: rotate(180deg); /* Arrow points down */
              }
              @keyframes bounce-arrow {
                  0%, 20%, 50%, 80%, 100% { transform: translateY(0) rotate(180deg); }
                  40% { transform: translateY(-10px) rotate(180deg); }
                  60% { transform: translateY(-5px) rotate(180deg); }
              }
              .copy-btn {
                  padding: 4px 8px;
                  font-size: 10px;
                  background-color: #007bff;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  flex-shrink: 0;
                  align-self: flex-start; /* Align with textarea */
                  margin-top: 5px;
              }
          </style>
      </head>
      <body>
          <div class="main-content">
              <div class="breadcrumb">... > <span>6. ADDITIONAL ARTICLES</span> > 7. CONFIRMATION > ...</div>
              <h2>ADDITIONAL ARTICLES</h2>
              <div class="section">
                  <p style="font-size:12px;">The form can be used below to add additional article provisions. Press 'Add' after entering the information for each article.</p>
                  <div class="form-group">
                      <label>Article #1:</label>
                      <textarea placeholder="Article Details" id="additionalArticle" readonly>{additional_articles}</textarea>
                  </div>
              </div>
          </div>
          <script>
              document.addEventListener('DOMContentLoaded', function() {
                  const createArrow = (targetElement, rotation = '180deg') => {
                      const rect = targetElement.getBoundingClientRect();
                      const arrow = document.createElement('div');
                      arrow.className = 'highlight-arrow';
                      arrow.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14m0-14l-4 4m4-4l4 4" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                      document.body.appendChild(arrow);
                      const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                      arrow.style.position = 'absolute';
                      arrow.style.left = (rect.left + rect.width / 2 - 20) + 'px';
                      arrow.style.top = (rect.top + scrollY - 45) + 'px';
                      arrow.style.transform = 'rotate(' + rotation + ')';
                  };

                  const addInteractiveElements = (selector) => {
                      const targetElement = document.querySelector(selector);
                      if (!targetElement) return;

                      createArrow(targetElement);

                      const copyBtn = document.createElement('button');
                      copyBtn.innerText = 'Copy';
                      copyBtn.className = 'copy-btn';
                      copyBtn.onclick = () => {
                          navigator.clipboard.writeText(targetElement.value).then(() => {
                              copyBtn.innerText = 'Copied!';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          }).catch(err => {
                              console.error('Failed to copy text: ', err);
                              copyBtn.innerText = 'Error';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          });
                      };
                      targetElement.parentNode.appendChild(copyBtn);
                      targetElement.setAttribute('readonly', 'true');
                  };
                  setTimeout(() => addInteractiveElements('#additionalArticle'), 300);
              });
          </script>
      </body>
      </html>`
  },
  // Step 8: Confirmation
  {
    step_number: 8,
    step_title: 'Confirmation',
    step_description: 'This is the final review. Carefully check all the information you have entered to ensure it is accurate before proceeding.',
    html_content: `
      <!DOCTYPE html>
      <html>
      <head><title>Confirmation</title>
          <style>
              body { font-family: Arial, sans-serif; background-color: #f0f0f0; }
              .main-content { background: #fff; padding: 20px; max-width: 900px; margin: 20px auto; }
              .breadcrumb { margin-bottom: 20px; font-size: 13px; }
              h2 { font-size: 18px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
              .section { border: 1px solid #ccc; padding: 15px; }
              .data-grid { display: grid; grid-template-columns: 200px 1fr; gap: 5px 15px; font-size: 14px; }
              .data-grid dt { font-weight: bold; }

              .highlight-arrow {
                  position: absolute;
                  width: 40px;
                  height: 40px;
                  pointer-events: none;
                  z-index: 9999;
                  animation: bounce-arrow 2s ease-in-out infinite;
                  transform: rotate(180deg); /* Arrow points down */
              }
              @keyframes bounce-arrow {
                  0%, 20%, 50%, 80%, 100% { transform: translateY(0) rotate(180deg); }
                  40% { transform: translateY(-10px) rotate(180deg); }
                  60% { transform: translateY(-5px) rotate(180deg); }
              }
              .copy-btn {
                  display: none; /* Not used in this step */
              }
          </style>
      </head>
      <body>
          <div class="main-content">
              <div class="breadcrumb">... > <span>7. CONFIRMATION</span> > 8. SIGNATURE > ...</div>
              <h2 id="confirmationTitle">CONFIRMATION</h2>
              <div class="section" id="confirmationSection">
                  <p style="font-size:12px;">Please confirm the business information is correct and press Continue. Press 'Back' after reviewing the information to make changes.</p>
                  <dl class="data-grid">
                      <dt>Business Name:</dt><dd>{company_name}, {legal_ending}</dd>
                      <dt>Limited Liability Company:</dt><dd>W.S. 17-29</dd>
                      <dt>Principal Address:</dt><dd>{principal_address1}, {principal_city}, {principal_state}, {principal_zip}</dd>
                      <dt>Mailing Address:</dt><dd>{mailing_address1}, {mailing_city}, {mailing_state}, {mailing_zip}</dd>
                      <dt>Registered Agent:</dt><dd>{agent_firstname} {agent_lastname}, {agent_organization}</dd>
                      <dt>Filing Fee:</dt><dd>$100.00</dd>
                  </dl>
              </div>
          </div>
          <script>
              document.addEventListener('DOMContentLoaded', function() {
                  const createArrow = (targetElement, rotation = '180deg') => {
                      const rect = targetElement.getBoundingClientRect();
                      const arrow = document.createElement('div');
                      arrow.className = 'highlight-arrow';
                      arrow.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14m0-14l-4 4m4-4l4 4" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                      document.body.appendChild(arrow);
                      const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                      arrow.style.position = 'absolute';
                      arrow.style.left = (rect.left + rect.width / 2 - 20) + 'px';
                      arrow.style.top = (rect.top + scrollY - 45) + 'px';
                      arrow.style.transform = 'rotate(' + rotation + ')';
                  };
                  setTimeout(() => createArrow(document.querySelector('#confirmationSection')), 300);
              });
          </script>
      </body>
      </html>`
  },
  // Step 9: Signature
  {
    step_number: 9,
    step_title: 'Signature',
    step_description: 'Finally, provide your electronic signature to legally certify the information and authorize the filing.',
    html_content: `
      <!DOCTYPE html>
      <html>
      <head><title>Signature</title>
          <style>
              body { font-family: Arial, sans-serif; background-color: #f0f0f0; }
              .main-content { background: #fff; padding: 20px; max-width: 900px; margin: 20px auto; }
              .breadcrumb { margin-bottom: 20px; font-size: 13px; }
              h2 { font-size: 18px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
              .section { border: 1px solid #ccc; padding: 15px; }
              .legal-text { font-size: 12px; margin-bottom: 20px; }
              .form-grid { display: grid; grid-template-columns: 120px 1fr auto; /* Adjusted for copy button */ gap: 10px; }
              label { font-weight: bold; }
              input { padding: 8px; border: 1px solid #ccc; }

              .highlight-arrow {
                  position: absolute;
                  width: 40px;
                  height: 40px;
                  pointer-events: none;
                  z-index: 9999;
                  animation: bounce-arrow 2s ease-in-out infinite;
                  transform: rotate(90deg); /* Arrow points right */
              }
              @keyframes bounce-arrow {
                  0%, 20%, 50%, 80%, 100% { transform: translateX(0) rotate(90deg); }
                  40% { transform: translateX(-10px) rotate(90deg); }
                  60% { transform: translateX(-5px) rotate(90deg); }
              }
              .copy-btn {
                  padding: 4px 8px;
                  font-size: 10px;
                  background-color: #007bff;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  flex-shrink: 0;
              }
          </style>
      </head>
      <body>
          <div class="main-content">
              <div class="breadcrumb">... > <span>8. SIGNATURE</span> > 9. PAYMENT</div>
              <h2>SIGNATURE</h2>
              <div class="section">
                  <div class="legal-text">By submitting this document for filing, I certify that all information contained herein is true and correct, and that I am authorized to sign this document on behalf of the entity being formed. I understand that false statements may be subject to penalties under Wyoming law.</div>
                  <div class="form-grid">
                      <label>Filer Information:</label> <div>Filer is an Individual</div><div></div>
                      <label>First Name:*</label> <input type="text" id="filerFirstName" value="{organizer_firstname}" readonly>
                      <label>Last Name:*</label> <input type="text" id="filerLastName" value="{organizer_lastname}" readonly>
                      <label>Email Address:*</label> <input type="email" id="filerEmail" value="{principal_email}" readonly>
                  </div>
              </div>
          </div>
          <script>
              document.addEventListener('DOMContentLoaded', function() {
                  const createArrow = (targetElement, rotation = '90deg') => {
                      const rect = targetElement.getBoundingClientRect();
                      const arrow = document.createElement('div');
                      arrow.className = 'highlight-arrow';
                      arrow.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14m0-14l-4 4m4-4l4 4" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                      document.body.appendChild(arrow);
                      const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                      arrow.style.position = 'absolute';
                      arrow.style.left = (rect.left - 45) + 'px';
                      arrow.style.top = (rect.top + scrollY + rect.height / 2 - 20) + 'px';
                      arrow.style.transform = 'rotate(' + rotation + ')';
                  };

                  const addInteractiveElements = (selector) => {
                      const targetElement = document.querySelector(selector);
                      if (!targetElement) return;

                      createArrow(targetElement);

                      const copyBtn = document.createElement('button');
                      copyBtn.innerText = 'Copy';
                      copyBtn.className = 'copy-btn';
                      copyBtn.onclick = () => {
                          navigator.clipboard.writeText(targetElement.value).then(() => {
                              copyBtn.innerText = 'Copied!';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          }).catch(err => {
                              console.error('Failed to copy text: ', err);
                              copyBtn.innerText = 'Error';
                              setTimeout(() => { copyBtn.innerText = 'Copy'; }, 2000);
                          });
                      };
                      targetElement.parentNode.appendChild(copyBtn);
                      targetElement.setAttribute('readonly', 'true');
                  };
                  setTimeout(() => addInteractiveElements('#filerFirstName'), 300);
                  setTimeout(() => addInteractiveElements('#filerLastName'), 600);
                  setTimeout(() => addInteractiveElements('#filerEmail'), 900);
              });
          </script>
      </body>
      </html>`
  },
  // Step 10: Payment
  {
    step_number: 10,
    step_title: 'Payment',
    step_description: 'The final step is to pay the state filing fee. This screen shows the total amount due and directs you to the payment processor.',
    html_content: `
      <!DOCTYPE html>
      <html>
      <head><title>Payment</title>
          <style>
              body { font-family: Arial, sans-serif; background-color: #f0f0f0; }
              .main-content { background: #fff; padding: 20px; max-width: 900px; margin: 20px auto; }
              .breadcrumb { margin-bottom: 20px; font-size: 13px; }
              h2 { font-size: 18px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
              .section { border: 1px solid #ccc; padding: 15px; }
              .fee-summary { display: grid; grid-template-columns: 1fr 100px; font-size: 14px; gap: 5px; margin-bottom: 20px; }
              .total { font-weight: bold; border-top: 1px solid #333; padding-top: 5px; }
              .payment-btn { padding: 10px 20px; font-size: 16px; background-color: #007bff; color: white; border: none; cursor: pointer; }

              .highlight-arrow {
                  position: absolute;
                  width: 40px;
                  height: 40px;
                  pointer-events: none;
                  z-index: 9999;
                  animation: bounce-arrow 2s ease-in-out infinite;
                  transform: rotate(180deg); /* Arrow points down */
              }
              @keyframes bounce-arrow {
                  0%, 20%, 50%, 80%, 100% { transform: translateY(0) rotate(180deg); }
                  40% { transform: translateY(-10px) rotate(180deg); }
                  60% { transform: translateY(-5px) rotate(180deg); }
              }
              .copy-btn {
                  display: none; /* Not used in this step */
              }
          </style>
      </head>
      <body>
          <div class="main-content">
              <div class="breadcrumb">... > <span>9. PAYMENT</span></div>
              <h2 id="paymentTitle">PAYMENT</h2>
              <div class="section" id="paymentSection">
                  <p style="font-size:14px;">YOU WILL BE DIRECTED TO THE BUSINESS DIVISION PAYMENT PROCESSING SITE TO COLLECT YOUR PAYMENT INFORMATION AND TO COMPLETE THE REGISTRATION FILING.</p>
                  <div class="fee-summary">
                      <span>Registration Fee:</span><span>$100.00</span>
                      <span>Convenience Fee:</span><span>$3.75</span>
                      <span class="total">Total Online Payment:</span><span class="total">$103.75</span>
                  </div>
                  <button class="payment-btn" id="paymentButton" disabled>Start Payment Process</button>
                  <div style="font-size:12px; margin-top: 20px;">
                      <h4>Credit Card Payment Instructions:</h4>
                      <ul><li>We accept Visa and Mastercard as forms of credit card payment.</li><li>Payment is processed through a secure third-party payment gateway.</li><li>Ensure your billing address matches the address on file with your credit card provider.</li><li>A convenience fee of $3.75 is applied to all online credit card payments.</li></ul>
                  </div>
              </div>
          </div>
          <script>
              document.addEventListener('DOMContentLoaded', function() {
                  const createArrow = (targetElement, rotation = '180deg') => {
                      const rect = targetElement.getBoundingClientRect();
                      const arrow = document.createElement('div');
                      arrow.className = 'highlight-arrow';
                      arrow.innerHTML = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 5v14m0-14l-4 4m4-4l4 4" stroke="#ef4444" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                      document.body.appendChild(arrow);
                      const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                      arrow.style.position = 'absolute';
                      arrow.style.left = (rect.left + rect.width / 2 - 20) + 'px';
                      arrow.style.top = (rect.top + scrollY - 45) + 'px';
                      arrow.style.transform = 'rotate(' + rotation + ')';
                  };
                  setTimeout(() => createArrow(document.querySelector('#paymentButton')), 300);
              });
          </script>
      </body>
      </html>`
  },
];


export default function StateFilingSimulation({ company, onComplete, onClose }) {
  const [messages, setMessages] = useState([]);
  const [suggestedReplies, setSuggestedReplies] = useState([]);
  const [isAiTyping, setIsAiTyping] = useState(false);
  const [stage, setStage] = useState('LOADING');
  const [steps, setSteps] = useState([]);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [user, setUser] = useState(null);
  const [currentStep, setCurrentStep] = useState(null);
  const [animationDirection, setAnimationDirection] = useState(1);
  const [hasShownCurrentStep, setHasShownCurrentStep] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false); // New state for fullscreen

  const chatContainerRef = useRef(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    const loadData = async () => {
        try {
            const me = await User.me();
            setUser(me);
            
            // For Wyoming LLC, always use our high-fidelity hardcoded data
            if (company.state === 'Wyoming' && company.company_type === 'llc') {
                const updatedSteps = wyomingLlcHardcodedData.map(step => {
                    // Logic to inject interactive scripts into each step's HTML
                    // (This is a simplified representation; the full script is in the wyomingLlcHardcodedData constant)
                    return step;
                });
                setSteps(updatedSteps);
                setCurrentStepIndex(0);
                setStage('START');
                return;
            }
            
            // Fallback for other states (though currently not triggered from dashboard)
            const data = await StateData.filter({ state_name: company.state });
            if (data && data.length > 0) {
                const fetchedData = data[0];
                const registrationType = company.company_type === 'llc' ? 'llc_registration' : 'corporation_registration';
                const registrationSteps = fetchedData[registrationType]?.screenshots || [];
                
                if (registrationSteps.length > 0) {
                    const sortedSteps = [...registrationSteps].sort((a, b) => a.step_number - b.step_number);
                    setSteps(sortedSteps);
                    setCurrentStepIndex(0);
                    setStage('START');
                } else {
                    setStage('NO_STEPS');
                }
            } else {
                setStage('NO_STATE_DATA');
            }
        } catch (error) {
            console.error('Failed to load state data:', error);
            setStage('ERROR');
        }
    };
    loadData();
  }, [company]);

  const addMessage = useCallback((sender, text) => {
    const newMessage = { sender, text };
    setMessages(prev => [...prev, newMessage]);
  }, []);
  
  const showCurrentStepInfo = useCallback(() => {
    if (stage !== 'STEP_VIEW' || hasShownCurrentStep) return;

    setIsAiTyping(false);
    if (currentStepIndex >= steps.length) {
        addMessage('ai', "🎉 You've reached the end of the filing simulation! You now have a clear guide on how to register your company.");
        addMessage('ai', "You can close this window to return to your dashboard.");
        setSuggestedReplies([{ label: "Finish Simulation", value: "FINISH" }]);
        setStage('COMPLETE');
        setCurrentStep(null);
        return;
    }

    const step = steps[currentStepIndex];
    setCurrentStep(step);
    
    // Updated chat message format
    addMessage('ai', `**Step ${step.step_number}: ${step.step_title}**\n\n${step.step_description}`);
    
    const replies = [];
    if (currentStepIndex > 0) {
        replies.push({ label: 'Previous Step', value: 'PREVIOUS' });
    }
    if (currentStepIndex < steps.length - 1) {
        replies.push({ label: 'Next Step', value: 'NEXT' });
    } else {
        replies.push({ label: 'Finish Simulation', value: 'FINISH' });
    }

    setSuggestedReplies(replies);
    setHasShownCurrentStep(true);
  }, [currentStepIndex, steps, addMessage, stage, hasShownCurrentStep]);

  useEffect(() => {
    if (stage === 'START' && messages.length === 0) {
      addMessage('ai', `Alright, let's walk through the filing process for a ${company.company_type.toUpperCase()} in ${company.state}.`);
      addMessage('ai', "I will guide you step-by-step through the official state forms, showing you exactly what to fill in based on your company's information.");
      setSuggestedReplies([{ label: "Let's Begin", value: "BEGIN" }]);
      setIsAiTyping(false);
    } else if (stage === 'NO_STEPS') {
      addMessage('ai', `I couldn't find any specific filing steps for a ${company.company_type.toUpperCase()} in ${company.state} in my database. An admin may need to add this information.`);
      setSuggestedReplies([{ label: "Close", value: "FINISH" }]);
    } else if (stage === 'NO_STATE_DATA') {
      addMessage('ai', `I don't have any data for ${company.state} yet. An admin needs to configure this state first.`);
      setSuggestedReplies([{ label: "Close", value: "FINISH" }]);
    } else if (stage === 'ERROR') {
      addMessage('ai', "Sorry, I encountered an error while trying to load the simulation data.");
      setSuggestedReplies([{ label: "Close", value: "FINISH" }]);
    }
  }, [stage, addMessage, company.state, company.company_type, messages.length]);

  const handleReply = useCallback(({value, label}) => {
    if (value !== 'PREVIOUS' && value !== 'NEXT') {
      addMessage('user', label);
    }
    setIsAiTyping(true);
    setSuggestedReplies([]);
    setHasShownCurrentStep(false);

    setTimeout(() => {
        if (value === 'BEGIN') {
            setAnimationDirection(1);
            setCurrentStepIndex(0);
            setStage('STEP_VIEW');
        } else if (value === 'NEXT') {
            setAnimationDirection(1);
            setCurrentStepIndex(prev => prev + 1);
            setStage('STEP_VIEW');
        } else if (value === 'PREVIOUS') {
            setAnimationDirection(-1);
            setCurrentStepIndex(prev => prev - 1);
            setStage('STEP_VIEW');
        } else if (value === 'FINISH') {
            onComplete();
        }
    }, 500);
  }, [addMessage, onComplete]);

  useEffect(() => {
    showCurrentStepInfo();
  }, [currentStepIndex, showCurrentStepInfo]);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className={`${isFullScreen ? 'w-full h-full' : 'w-full max-w-7xl h-[90vh]'} flex flex-col bg-[var(--background)] rounded-2xl shadow-2xl border border-[var(--border)] relative overflow-hidden`}
      >
        <div className="flex-shrink-0 p-4 border-b border-[var(--border)] flex items-center justify-between">
          <h2 className="text-lg font-bold flex items-center justify-center gap-2">
            <Logo className="w-6 h-6 text-[var(--primary)]" />
            <span>Filing Simulation</span>
          </h2>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsFullScreen(!isFullScreen)}
              className="text-[var(--text-secondary)] hover:bg-[var(--secondary)] rounded-full h-10 w-10"
            >
              {isFullScreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
            </Button>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-[var(--text-secondary)] hover:bg-[var(--secondary)] rounded-full h-10 w-10">
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        <div className="flex-1 flex overflow-hidden">
          {/* Chat Guide - Left Side */}
          <div className="w-80 flex flex-col bg-[var(--background)] border-r border-[var(--border)]">
            <div ref={chatContainerRef} className="flex-1 p-4 overflow-y-auto custom-scrollbar">
              <AnimatePresence>
                {messages.map((msg, index) => (
                  <ChatMessage key={index} message={msg} user={user} />
                ))}
              </AnimatePresence>
              {isAiTyping && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-end gap-2 my-2 justify-start"
                >
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[var(--primary)] text-[var(--primary-foreground)] flex items-center justify-center shadow-md">
                    <Logo className="w-5 h-5" />
                  </div>
                  <div className="px-4 py-3 rounded-2xl bg-[var(--secondary)] text-[var(--text-primary)] rounded-bl-none">
                    <div className="flex items-center justify-center gap-1">
                      <span className="w-2 h-2 bg-current rounded-full animate-bounce" />
                      <span className="w-2 h-2 bg-current rounded-full animate-bounce" style={{animationDelay: '0.2s'}} />
                      <span className="w-2 h-2 bg-current rounded-full animate-bounce" style={{animationDelay: '0.4s'}} />
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
            <div className="flex-shrink-0 border-t border-[var(--border)]">
              <SuggestedReplies replies={suggestedReplies} onSelect={handleReply} disabled={isAiTyping} />
            </div>
          </div>

          {/* Website Simulation - Right Side */}
          <div className="flex-1 overflow-y-auto custom-scrollbar">
            <AnimatePresence mode="wait">
              {currentStep && (
                <motion.div
                  key={currentStep.step_number}
                  initial={{ opacity: 0, x: animationDirection * 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -animationDirection * 50 }}
                  transition={{ duration: 0.3 }}
                  className="h-full w-full"
                >
                  <SimulatedWebsiteFrame step={currentStep} company={company} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </motion.div>
    </div>
  );
}