import React from 'react';

export default function Logo({ className }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      <g>
        {/* Left eye - outer circle */}
        <circle cx="7" cy="8" r="3" fill="none" stroke="currentColor" strokeWidth="1.5" />
        {/* Left eye - inner filled circle */}
        <circle cx="7" cy="8" r="1.5" fill="currentColor" />
        
        {/* Right eye - outer circle */}
        <circle cx="17" cy="8" r="3" fill="none" stroke="currentColor" strokeWidth="1.5" />
        {/* Right eye - inner filled circle */}
        <circle cx="17" cy="8" r="1.5" fill="currentColor" />
        
        {/* Smile - curved path */}
        <path 
          d="M 8 15 Q 12 19 16 15" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="1.5" 
          strokeLinecap="round"
        />
      </g>
    </svg>
  );
}